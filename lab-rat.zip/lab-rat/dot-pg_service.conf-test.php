<?php
  $curr_date = time();
  $display_curr_date = date('l', $curr_date) . ' ' . date('F', $curr_date) . ' ' . date('jS', $curr_date) . ', ' . date('Y', $curr_date);
  $display_curr_time = (date('h', $curr_date)) . ':' . date('i', $curr_date) . ':' . date('s', $curr_date) . ':' . date('A', $curr_date) . ' ' . date('e', $curr_date);
?>
<!doctype html />
<html>
  <head>
    <meta content="7200" http-equiv="refresh">
    <title>my .pg_service.conf</title>
    <style type="text/css">
      body > div.listing:first-child {margin-bottom: 10px;}
      body > div[class~=end] {margin-top: 10px;}
      div.listing,td {font-family: monospace; font-size: 10pt;}
      curr_time {display: block; text-align: center; margin: 10px; color: #c00000; font-size: small; line-height: 1pt; font-style: italic;}
    </style>
  </head>
  <body>
    <div class="listing">ccapuser@tom_h-c-ubuntu:~$ grep &quot;\[&quot; .pg_service.conf</div>
<?php
  $myfile = fopen("/home/ccapuser/.pg_service.conf", "r") or die("Unable to open file!");
?>
    <table>
<?php
  // Output one line until end-of-file
  while(!feof($myfile)) {
    $line = fgets($myfile);
    if (strstr($line, "[") != null) {
      echo "      <tr>\n";
      echo "        <td>" . rtrim($line) . "</td>\n";
    }
    
    if (strstr($line, "host") != null) {
      echo "        <td>" . rtrim(substr($line,5)) . ":";
    }
    if ((strstr($line, "port") != null) and !(strstr($line, "#"))) {
      echo rtrim(substr($line,5)) . "</td>\n";
      echo "      </tr>\n";
    }
  }
  fclose($myfile);
?>
    </table>
    <div class="listing end">ccapuser@tom_h-c-ubuntu:~$ psql &quot;service = kenosha-trunk&quot;</div>
    <curr_time><?php echo $display_curr_date ?> @ <?php echo $display_curr_time ?></curr_time>
  <body>
</html>

