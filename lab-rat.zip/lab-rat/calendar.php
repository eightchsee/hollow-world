<?php 
  $days_counts = array(0=>31,1=>28,2=>31,3=>30,4=>31,5=>30,6=>31,7=>31,8=>30,9=>31,10=>30,11=>31);
  $day_labels = array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
  $mo = date('m');
  $yr = date('Y');
  if ( isset($_GET['mth']) ) {
    $mo = $_GET['mth'];
  }
  if ( isset($_GET['yyyy']) ) {
    $yr = $_GET['yyyy'];
  }
  function link2today ($mm, $yy) {
    $curr_date = time();
    $display_curr_date = date('l', $curr_date) . ' ' . date('F', $curr_date) . ' ' . date('jS', $curr_date) . ', ' . date('Y', $curr_date);
    $m = date('m', $curr_date);
    $y = date('Y', $curr_date);
    if($m == $mm && $y == $yy) {
      echo '<span style="color: #c00000;">' . $display_curr_date . '</span>';
    }
    else {
      echo '<a href="calendar.php">' . $display_curr_date . '</a>';
    }
  }
  function prev_month($mnth) {
    if($mnth == 1) echo 12;
    else echo $mnth - 1;
  }
  function next_month($mnth) {
    if($mnth == 12) echo 1;
    else echo $mnth + 1;
  }
  function get_year_left($mnth, $yy) {
    switch ($mnth) {
      case  1: echo $yy - 1; break;
      default: echo $yy;
    }
  }
  function get_year_rght($mnth, $yy) {
    switch ($mnth) {
      case 12: echo $yy + 1; break;
      default: echo $yy;
    }
  }
  function check_leap_year($d) {
    if(date('L', $d) == 1) {return 'yes';}
    else {return 'no';}
  }

  $date = mktime(0,0,0, $mo, 1, $yr);

  if (check_leap_year($date) == 'yes') {
    $days_counts[1] = 29;
  }

  //This puts the day, month, and year in seperate variables 
  $day = date('d', $date) ; 
  $month = date('m', $date) ; 
  $year = date('Y', $date) ;

  //Here we generate the first day of the month 
  $first_day = mktime(0,0,0,$month, 1, $year) ; 

  //This gets us the month name 
  $month_name = date('F', $first_day) ;

  //Here we find out what day of the week the first day of the month falls on 
  $day_of_week = date('D', $first_day) ;

  //Once we know what day of the week it falls on, we know how many blank days occure before it. If the first day of the week is a Sunday then it would be zero
  $blank = date('w', $first_day);
  //We then determine how many days are in the current month
  $days_in_month = cal_days_in_month(0, $month, $year) ;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta content="7200" http-equiv="refresh">
    <title><?php echo $month_name . ' - ' . $year; ?></title>
    <link href="css/php-cal.css" type="text/css" rel="stylesheet" />
    <script src="script/datestuff.js" type="text/javascript"></script>
    <style type="text/css">
    </style>
  </head>
<?php
  $file = $yr . "/state-holidays.txt";
  $stateholidays = file_get_contents($file);
  // echo '<p>' . $stateholidays . '</p>';
  $holidays = explode("\r\n", $stateholidays);
  //$days = array();
  //$days_txt = array();
  $dayz = array();
  $idx = 0;
  foreach ($holidays as $holiday) {
    $holiday_mnth = explode('-', substr($holiday, 0, 10))[1];
// echo $month . ' = '. $holiday_mnth .'? : ';
    if ($holiday_mnth == $month) {
//      echo '  <!-- holiday_mnth: ' . $holiday_mnth . '; idx: '. $idx . '; holiday: ' . substr($holiday, strpos($holiday, "=")+1) . ' -->'; echo "\n";
      $dayz[$idx] = explode('-', substr($holiday, 0, 10))[2];
      $dayz_txt[$idx] = substr($holiday, strpos($holiday, "=")+1);
      echo '  <!-- holiday_mnth: ' . $holiday_mnth . '; holiday_day: ' . $dayz[$idx] . '; idx: '. $idx . '; holiday: ' . substr($holiday, strpos($holiday, "=")+1) . ' -->'; echo "\n";
      $idx++;
    }

//    echo '<!-- holiday: ' . substr($holiday, strpos($holiday, "=")+1) . ' -->';
//    echo "\n";
  }
?>
<?php
  if(count($dayz) > 0) {
?>
  <body onload='st_holiday(<?php echo json_encode($dayz) . ', ' . $month . ', ' . $year . ', ' . json_encode($dayz_txt); ?>)'>

<?php
  }
  else {
?>
  <body onload="setit(<?php echo $mo . ', ' . $yr ?>)">
<?php
  }
?>
    <!-- div align="center"><//?php echo date('w', $first_day) . ' - ' . date('D', $first_day); ?></div -->
    <div id="page-head"><?php echo $year; ?></div>
    <div id="today_date">Today&apos;s Date: <?php link2today($mo, $yr); ?></div>
    <table>
      <tr id="month-heading">
        <th><a href="calendar.php?mth=<?php prev_month($mo); ?>&amp;yyyy=<?php get_year_left($mo, $yr); ?>" class="prev_next">&lt;</a></th>
        <th colspan="5"><?php echo $month_name; ?></th>
        <th><a href="calendar.php?mth=<?php next_month($mo); ?>&amp;yyyy=<?php get_year_rght($mo, $yr); ?>" class="prev_next">&gt;</a></th>
      </tr>
      <tr class="day-label">
<?php
  foreach ($day_labels as $day_label) {
?>
        <th><?php echo $day_label ?></th>
<?php
  }
?>
      </tr>
<?php //This counts the days in the week, up to 7
  $day_count = 1;
?>
      <tr class="curr-month-days">
<?php //first we take care of those blank days
  $prev_mo = $mo - 1;
  if ($prev_mo == 0) {$prev_mo = 12;}
  $left_over_prev_days_start = ($days_counts[$prev_mo - 1] - $blank) +1;

  while ( $blank > 0 ) {
  $blank--;
  $day_count++;
?>
        <td class="pre-post"><?php echo $left_over_prev_days_start; ?></td>
<?php 
   $left_over_prev_days_start++;
  } 
  //sets the first day of the month to 1 
  $day_num = 1;

  //count up the days, until we've done all of them in the month
  while ( $day_num <= $days_in_month ) {
    if ($day_count == 7) {
?>
        <td id="<?php echo $day_num; ?>" class="weekend"><?php echo $day_num; ?></td>
<?php 
  } // if ($day_count == 7)
  else {
?>
        <td id="<?php echo $day_num; ?>"><?php echo $day_num; ?></td>
<?php 
  }
  $day_num++; 
  $day_count++;
  //Make sure we start a new row every week
  if ($day_count > 7) {
    $day_count = 1;
?>
      </tr>
<?php 
//  if ( !$day_num > $days_in_month ) {
?>
      <tr class="curr-month-days" key="<?php echo $days_in_month; ?>" key2="<?php echo $day_num; ?>">
<?php
//     }
   } // if ($day_count > 7)
 } // while ( $day_num <= $days_in_month )

  //Finaly we finish out the table with some blank details if needed
  $next_month_day = 1;
  while ( $day_count > 1 && $day_count <= 7 ) {
 ?>
        <td class="pre-post<?php if ($day_count == 7) {echo ' weekend';} ?>"><?php echo $next_month_day; ?></td>
<?php 
  $day_count++;
  $next_month_day++;
  }
//  if ( !$day_num > $days_in_month ) {
?>
      </tr>
<?php
//  }
?>
    </table>
<?php
  $curr_date = time();
  $display_curr_date = date('l', $curr_date) . ' ' . date('F', $curr_date) . ' ' . date('jS', $curr_date) . ', ' . date('Y', $curr_date);
  $display_curr_time = (date('h', $curr_date)) . ':' . date('i', $curr_date) . ':' . date('s', $curr_date) . ':' . date('A', $curr_date) . ' ' . date('e', $curr_date);
?>
    <curr_time style="display: block; text-align: center; margin: 10px; color: #c00000; font-size: smaller; line-height: 1pt; font-style: italic;"><?php echo $display_curr_date ?> @ <?php echo $display_curr_time ?></curr_time>
    <p>
      <a href="<?php echo $_SERVER['PHP_SELF'] ?>">home page</a> <?php echo ' [' . $_SERVER['QUERY_STRING'] . '] - [' . $_SERVER['SCRIPT_FILENAME'] . '] - [' . $_SERVER['SCRIPT_NAME'] . ']'; ?>
    </p>
  </body>
</html>
