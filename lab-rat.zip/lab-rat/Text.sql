-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 03, 2015 at 02:33 PM
-- Server version: 5.5.40-36.1-log
-- PHP Version: 5.4.23

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `redhotra_rattlers`
--

-- --------------------------------------------------------

--
-- Table structure for table `Text`
--

DROP TABLE IF EXISTS `Text`;
CREATE TABLE IF NOT EXISTS `Text` (
  `ID` bigint(16) NOT NULL AUTO_INCREMENT,
  `SectionName` varchar(255) DEFAULT NULL,
  `Text` text,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `Text`
--

INSERT INTO `Text` (`ID`, `SectionName`, `Text`) VALUES
(1, 'Band', NULL),
(2, 'Music', '<a href="http://www.msplinks.com/MDFodHRwOi8vbXlzcGFjZXR2LmNvbS9pbmRleC5jZm0/ZnVzZWFjdGlvbj12aWRzLmluZGl2aWR1YWwmdmlkZW9pZD0xNDAyMDgxOA==">Urban Theater - Boondocks</a><br><br><object type="application/x-shockwave-flash" allowScriptAccess="never" allowNetworking="all" height="386" width="480" data="http://lads.myspace.com/videos/myspacetv_vplayer0005.swf">\n  <param name="allowScriptAccess" value="never" />\n  <param name="allowNetworking" value="all" />\n  <param name="movie" value="http://lads.myspace.com/videos/myspacetv_vplayer0005.swf" />\n  <param name="flashvars" value="m=14020818&type=video" />\n</object><br><br><a href="http://www.msplinks.com/MDFodHRwOi8vbXlzcGFjZXR2LmNvbS9pbmRleC5jZm0/ZnVzZWFjdGlvbj12aWRzLmFkZFRvUHJvZmlsZUNvbmZpcm0mdmlkZW9pZD0xNDAyMDgxOCZ0aXRsZT1DaGVjayBvdXQgdGhpcyB2aWRlbzogVXJiYW4gVGhlYXRlciAtIEJvb25kb2Nrcw==">Add to My Profile</a> | <a href="http://www.msplinks.com/MDFodHRwOi8vbXlzcGFjZXR2LmNvbS9pbmRleC5jZm0/ZnVzZWFjdGlvbj12aWRzLmhvbWU=">More Videos</a><br>\n<br>\n<a href="http://www.msplinks.com/MDFodHRwOi8vbXlzcGFjZXR2LmNvbS9pbmRleC5jZm0/ZnVzZWFjdGlvbj12aWRzLmluZGl2aWR1YWwmdmlkZW9pZD0xNDAzNTIwMg==">Urban Theater - Before He Cheats</a><br><br><object type="application/x-shockwave-flash" allowScriptAccess="never" allowNetworking="all" height="386" width="480" data="http://lads.myspace.com/videos/myspacetv_vplayer0005.swf">\n  <param name="allowScriptAccess" value="never" />\n  <param name="allowNetworking" value="all" />\n  <param name="movie" value="http://lads.myspace.com/videos/myspacetv_vplayer0005.swf" />\n  <param name="flashvars" value="m=14035202&type=video" />\n</object><br><br><a href="http://www.msplinks.com/MDFodHRwOi8vbXlzcGFjZXR2LmNvbS9pbmRleC5jZm0/ZnVzZWFjdGlvbj12aWRzLmFkZFRvUHJvZmlsZUNvbmZpcm0mdmlkZW9pZD0xNDAzNTIwMiZ0aXRsZT1DaGVjayBvdXQgdGhpcyB2aWRlbzogVXJiYW4gVGhlYXRlciAtIEJlZm9yZSBIZSBDaGVhdHM=">Add to My Profile</a> | <a href="http://www.msplinks.com/MDFodHRwOi8vbXlzcGFjZXR2LmNvbS9pbmRleC5jZm0/ZnVzZWFjdGlvbj12aWRzLmhvbWU=">More Videos</a>');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
