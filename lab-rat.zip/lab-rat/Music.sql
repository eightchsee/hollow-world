-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 03, 2015 at 02:36 PM
-- Server version: 5.5.40-36.1-log
-- PHP Version: 5.4.23

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `redhotra_rattlers`
--

-- --------------------------------------------------------

--
-- Table structure for table `Music`
--

DROP TABLE IF EXISTS `Music`;
CREATE TABLE IF NOT EXISTS `Music` (
  `ID` bigint(16) NOT NULL AUTO_INCREMENT,
  `Track` varchar(255) DEFAULT NULL,
  `Album` varchar(255) DEFAULT NULL,
  `AlbumNum` int(11) DEFAULT NULL,
  `TrackLength` time DEFAULT NULL,
  `Lyrics` text,
  `Description` text,
  `Author` varchar(255) DEFAULT NULL,
  `MediaLink` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `Music`
--

INSERT INTO `Music` (`ID`, `Track`, `Album`, `AlbumNum`, `TrackLength`, `Lyrics`, `Description`, `Author`, `MediaLink`) VALUES
(7, 'Q106 Interview Part I', NULL, NULL, NULL, NULL, NULL, 'R&RHR', 'http://www.q106.com/audio/Rachelle%20and%20Red%20Hot%20Rattlers%20seg%201%20-%20w%20leave%20the%20pieces.mp3'),
(8, 'Q106 Interview Part II', NULL, NULL, NULL, NULL, NULL, 'R&RHR', 'http://www.q106.com/audio/Rachelle%20and%20Red%20Hot%20Rattlers%20seg%202%20-%20w%20bring%20it%20on%20home%20and%20seven%20bridges%20rd.mp3'),
(9, 'Q106 Session - Leave the Pieces', NULL, NULL, NULL, NULL, NULL, 'R&RHR', 'Q106_LeaveThePieces.mp3'),
(10, 'Q106 Session - 7 Bridges Road', NULL, NULL, NULL, NULL, NULL, 'R&RHR', 'Q106_7Bridges.mp3'),
(11, 'Q106 Session - Bring It On Home', NULL, NULL, NULL, NULL, NULL, 'R&RHR', 'Q106_BringItOnHome.mp3');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
