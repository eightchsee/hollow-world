<html>
  <head>
   <title>Test</title>
  </head>
  <body bgcolor="white">

  <?
  $psql_conn = pg_connect("host=dev2-db port=5452 dbname=cc user=cc password=ICHHAV8 connect_timeout=5");
  
  // $link = pg_Connect("dbname=simple user=rose_ro password=obscured");
  // $result = pg_exec($link, "select * from person");
  $result = pg_exec($psql_conn, "SELECT * FROM \"County\"");
  $numrows = pg_numrows($result);
  echo "<p>link = $link<br>
  result = $result<br>
  numrows = $numrows</p>
  ";
  ?>

  <table border="1">
  <tr>
   <th>County Name</th>
   <th>County Number</th>
   <th>District Number</th>
  </tr>
  <?

   // Loop on rows in the result set.

   for($ri = 0; $ri < $numrows; $ri++) {
    echo "<tr>\n";
    $row = pg_fetch_array($result, $ri);
    echo " <td>", $row["countyNo"], "</td>
   <td>", $row["countyName"], "</td>
   <td>", $row["districtNo"], "</td>
  </tr>
  ";
   }
   pg_close($link);
  ?>
  </table>

  </body>

  </html>

