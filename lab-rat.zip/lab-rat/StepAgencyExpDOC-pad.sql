-- Wed 26 Jun 2019 09:49:40 AM CDT 

\set interval_back "2 days"
\set tbl StepAgencyExpDOC

SELECT :'tbl' AS tbl, "countyNo", "docSeqNo", "docId" AS doc_id, length(xml) AS xml_zize, "caseNo" AS case_no, (COALESCE("nameF" || ' ', '') || "nameL") AS full_name,
       to_char("dateInserted", 'MM-DD-YYYY') AS "dtInserted", "docSource" AS "docSrc", "isReportedToDOC"::VARCHAR(5) AS "isRptToDOC", "sectionNo" AS "sectNo", "docName", "jocType"
FROM   :"tbl"
WHERE  "dateInserted" >= CURRENT_DATE - INTERVAL :'interval_back';
 countyNo | docSeqNo | doc_id  |   case_no    |  nameF  |  nameL  | dateInserted | docSource | isReportedToDOC | sectionNo |                    docName                     | jocType 
----------+----------+---------+--------------+---------+---------+--------------+-----------+-----------------+-----------+------------------------------------------------+---------
       18 |    15876 | 1697077 | 2017CF001377 | Natasha | Henning | 2019-06-25   | S         | f               |         1 | Guilty plea questionnaire/plea advisement form | N
(1 row)

\gset
SELECT * FROM "StepAgencyExpDOCAttach" WHERE "docId" = :doc_id;
 countyNo | docSeqNo | docId | sectionNo | caseNo | isReportedToDOC | docName 
----------+----------+-------+-----------+--------+-----------------+---------
(0 rows)

SELECT * FROM "StepAgencyExpDOCAttach" WHERE "caseNo" = :'case_no';
 countyNo | docSeqNo |  docId  | sectionNo |    caseNo    | isReportedToDOC |          docName           
----------+----------+---------+-----------+--------------+-----------------+----------------------------
       18 |    13798 | 1404630 |         1 | 2017CF001377 | t               | Criminal Complaint_1 - Alf
       18 |    13798 | 1693155 |         1 | 2017CF001377 | t               | Information_2 - Henning
       18 |    13798 | 1697043 |         1 | 2017CF001377 | t               | CCAP-154 Assessment Report
(3 rows)

SELECT :'tbl' AS tbl, "countyNo", "docSeqNo", "docId" AS doc_id, "caseNo" AS case_no, "nameF", "nameL", "dateInserted", "docSource", "isReportedToDOC"::VARCHAR(5), "sectionNo", "docName", "jocType" FROM :"tbl" WHERE "dateInserted" >= CURRENT_DATE - INTERVAL :'interval_back';
 countyNo | docSeqNo | doc_id  |   case_no    |  nameF  |  nameL  | dateInserted | docSource | isReportedToDOC | sectionNo |                    docName                     | jocType 
----------+----------+---------+--------------+---------+---------+--------------+-----------+-----------------+-----------+------------------------------------------------+---------
       18 |    15876 | 1697077 | 2017CF001377 | Natasha | Henning | 2019-06-25   | S         | false           |         1 | Guilty plea questionnaire/plea advisement form | N
(1 row)

SELECT :'tbl' AS tbl, "countyNo", "docSeqNo", "docId" AS doc_id, length(xml) AS xml_zize, "caseNo" AS case_no, (COALESCE("nameF" || ' ', '') || "nameL") AS full_name,
       to_char("dateInserted", 'MM-DD-YYYY') AS "dtInserted", "docSource" AS "docSrc", "isReportedToDOC"::VARCHAR(5) AS "isRptToDOC", "sectionNo" AS "sectNo", "docName", "jocType"
FROM   :"tbl"
WHERE  "caseNo" = :'case_no';
 countyNo | docSeqNo | doc_id  |   case_no    |  nameF  |  nameL  | dateInserted | docSource | isReportedToDOC | sectionNo |                    docName                     | jocType 
----------+----------+---------+--------------+---------+---------+--------------+-----------+-----------------+-----------+------------------------------------------------+---------
       18 |    13798 | 1697042 | 2017CF001377 | Natasha | Henning | 2018-09-26   | E         | true            |         1 | CR-212 Judgment of Conviction                  | J
       18 |    15876 | 1697077 | 2017CF001377 | Natasha | Henning | 2019-06-25   | S         | false           |         1 | Guilty plea questionnaire/plea advisement form | N


\o /tmp/xml_files/StepAgencyExpDOC-1697077.out.xml
\qecho '<!-- '`date`' -->'
SELECT xml FROM :"tbl" WHERE "docId" = :doc_id;
\o

       tbl        | countyNo | docSeqNo | doc_id  | xml_zize |   case_no    |    full_name    | dtInserted | docSrc | isRptToDOC | sectNo |                    docName                     | jocType 
------------------+----------+----------+---------+----------+--------------+-----------------+------------+--------+------------+--------+------------------------------------------------+---------
 StepAgencyExpDOC |       18 |    15876 | 1697077 |   943711 | 2017CF001377 | Natasha Henning | 06-25-2019 | S      | false      |      1 | Guilty plea questionnaire/plea advisement form | N
(1 row)
       tbl        | countyNo | docSeqNo | doc_id  | xml_zize |   case_no    |    full_name    | dtInserted | docSrc | isRptToDOC | sectNo |                    docName                     | jocType 
------------------+----------+----------+---------+----------+--------------+-----------------+------------+--------+------------+--------+------------------------------------------------+---------
 StepAgencyExpDOC |       18 |    13798 | 1697042 |     6209 | 2017CF001377 | Natasha Henning | 09-26-2018 | E      | true       |      1 | CR-212 Judgment of Conviction                  | J
 StepAgencyExpDOC |       18 |    15876 | 1697077 |   943711 | 2017CF001377 | Natasha Henning | 06-25-2019 | S      | false      |      1 | Guilty plea questionnaire/plea advisement form | N
(2 rows)


replace(SUBSTRING(xml FROM 1 FOR (position('<data>' IN xml)-1)) || SUBSTRING(xml FROM position('</data>' IN xml)),'\012','')

SELECT SUBSTRING(xml FROM 1 FOR (position('<data>' IN xml)+25)) || ' ... ' || SUBSTRING(xml FROM position('</data>' IN xml)-25) AS non_doc_xml FROM :"tbl" WHERE "docId" = :doc_id;
 <docJoc xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://stepmom.wicourts.gov/xsd/docjoc0_04.xsd">\r+
   <docSource>SCANNED</docSource>\r                                                                                                             +
   <countyNumber>18</countyNumber>\r                                                                                                            +
   <caseNumber>2017CF001377</caseNumber>\r                                                                                                      +
   <branchId>1</branchId>\r                                                                                                                     +
   <prosAttyId>1046197</prosAttyId>\r                                                                                                           +
   <prosAttyName>BENJAMIN JAMES WEBSTER</prosAttyName>\r                                                                                        +
   <jocFormType />\r                                                                                                                            +
   <clerkOfCourtName>SUSAN SCHAFFER</clerkOfCourtName>\r                                                                                        +
   <signingCtofcNo />\r                                                                                                                         +
   <signingCtofcName />\r                                                                                                                       +
   <signatureDate />\r                                                                                                                          +
   <party>\r                                                                                                                                    +
     <lastName>HENNING</lastName>\r                                                                                                             +
     <firstName>NATASHA</firstName>\r                                                                                                           +
     <middleName>J</middleName>\r                                                                                                               +
     <nameSuffix />\r                                                                                                                           +
     <dateOfBirth>01-08-1988</dateOfBirth>\r                                                                                                    +
     <stateId>1207048</stateId>\r                                                                                                               +
     <alias>\r                                                                                                                                  +
       <aliasType>AKA</aliasType>\r                                                                                                             +
       <aliasLastName>HENNING</aliasLastName>\r                                                                                                 +
       <aliasFirstName>NATASHA</aliasFirstName>\r                                                                                               +
       <aliasMiddleName>JEAN</aliasMiddleName>\r                                                                                                +
       <aliasSuffix></aliasSuffix>\r                                                                                                            +
       <aliasEffDate />\r                                                                                                                       +
     </alias>\r                                                                                                                                 +
     <attorney>\r                                                                                                                               +
       <attyNumber>1032141</attyNumber>\r                                                                                                       +
       <attyName>DAVID W FIELD</attyName>\r                                                                                                     +
     </attorney>\r                                                                                                                              +
   </party>\r                                                                                                                                   +
   <attachment>\r                                                                                                                               +
     <attachmentDescription>Guilty plea questionnaire/plea advisement form</attachmentDescription>\r                                            +
     <contentType>application/pdf</contentType>\r                                                                                               +
     <data>JVBERi0xLjcKJeLjz9MK ... yZWYKNzA0MjQwCiUlRU9GCg==</data>\r                                                                          +
   </attachment>\r                                                                                                                              +
 </docJoc>


\t
\o /tmp/xml_files/StepAgencyExpDOC-1697077.out.xml
\qecho '<!-- '`date`' - ':"tbl" '-->'
SELECT SUBSTRING(xml FROM 1 FOR (position('<data>' IN xml)+25)) || ' ... ' || SUBSTRING(xml FROM position('</data>' IN xml)-25) AS non_doc_xml FROM :"tbl" WHERE "docId" = :doc_id;
\o
\t


