<?php
  // prev last save date: Wed Dec 20 09:41:15 CST 2017
  // Tue 30 Jul 2019 09:53:13 AM CDT fixing issue with "portage" and looking for "port" and how it messes up that line for dev14 portage and for prod portage
  // Tue 30 Jul 2019 10:10:38 AM CDT trying to fix issue with presenting intclient_dev and intclient_dev_admin
  $curr_date = time();
  $display_curr_date = date('l', $curr_date) . ' ' . date('F', $curr_date) . ' ' . date('jS', $curr_date) . ', ' . date('Y', $curr_date);
  $display_curr_time = (date('h', $curr_date)) . ':' . date('i', $curr_date) . ':' . date('s', $curr_date) . ':' . date('A', $curr_date) . ' ' . date('e', $curr_date);
?>
<!doctype html />
<html>
  <head>
    <meta content="7200" http-equiv="refresh">
    <title>my .pg_service.conf</title>
    <style type="text/css">
      body > div.listing:first-child {margin-bottom: 10px;}
      body > div[class~=end] {margin-top: 10px;}
      div.listing,td {font-family: monospace; font-size: 8pt;}
      tr > td + td {padding-left: 10px;}
      curr_time {display: block; text-align: center; margin: 10px; color: #c00000; font-size: small; line-height: 1pt; font-style: italic;}
    </style>
  </head>
  <body>
    <div class="listing">theiber@thcentre-m910t:~$ grep &quot;\[&quot; .pg_service.conf</div>
    <div class="listing">theiber@thcentre-m910t:~$ pushd ~/tmp/scripts</div>
<?php
  $myfile = fopen("/home/theiber/.pg_service.conf", "r") or die("Unable to open file!");
?>
    <table>
<?php
  // Output one line until end-of-file
  while(!feof($myfile)) {
    $line = fgets($myfile);
    if (strstr($line, "[") != null) {
?>
      <tr>
        <td>./psql_srv.sh <?php echo rtrim(str_replace("[","",str_replace("]","",$line))); ?></td>
<?php
    }

//    if ( ( strstr($line, "host") != null) and !(strpos($line, "#", 0)) ) {
    if ( ( strstr($line, "host") != null) and !(strstr($line, "#")) ) {
?>
        <td>
<?php echo rtrim(substr($line,5)) . ":";
    }
    if ((strstr($line, "port") != null) and !(strstr($line, "portage")) and !(strstr($line, "#"))) {
      echo rtrim(substr($line,5))
?>
        </td>
      </tr>
<?php
    }
  }
  fclose($myfile);
?>
    </table>
    <div class="listing end">theiber@thcentre-m910t:~$ psql &quot;service = kenosha-trunk&quot;</div>
    <curr_time><?php echo $display_curr_date ?> @ <?php echo $display_curr_time ?></curr_time>
  <body>
</html>

