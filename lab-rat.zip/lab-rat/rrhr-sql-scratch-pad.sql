SELECT ID, Track, COALESCE(TrackLength, '00:00:00') AS TrackLength, Description, Author, MediaLink
FROM   Music
WHERE  ID > 8
ORDER BY AlbumNum ASC

SELECT ID, Track, COALESCE(TrackLength, '00:00:00') AS TrackLength, Description, Author, MediaLink
FROM   Music
WHERE  ID > 8
ORDER BY ID

INSERT INTO Music (Track, TrackLength, Description, Author, MediaLink)
VALUES ('Taste of Madison, 2014; sampler #1', '00:06:00', 'The Rattlers sampler', 'R&RHR', 'Taste2014-Snippets24bit.mp3')

INSERT INTO Music (Track, TrackLength, Description, Author, MediaLink)
VALUES ('Taste of Madison, 2014 sampler #2', '00:03:25', 'The Rattlers LBT sampler', 'R&RHR', 'Taste-2014-LBT-Block-24bit.mp3')

INSERT INTO Music (Track, TrackLength, Description, Author, MediaLink)
VALUES ('Taste of Madison, 2014 sampler #3', '00:02:31', 'The Rattlers &quot;Acoustic&quot; sampler', 'R&RHR', 'Taste2014-Acoustic-24bit.mp3')


