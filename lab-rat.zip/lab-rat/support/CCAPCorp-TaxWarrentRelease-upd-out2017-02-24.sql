\set release_type partial
\o /tmp/2017-02-24ccap-corp-tax-warrant.out.sql
\i ~/work/qry-input/ccap-corp-taxwarrant-rel.sql
\set release_type full
\i ~/work/qry-input/ccap-corp-taxwarrant-rel.sql
\set release_type withdrawal
\i ~/work/qry-input/ccap-corp-taxwarrant-rel.sql
\o

BEGIN;
UPDATE "Message" SET status = 'D', "lastModified" = CURRENT_TIMESTAMP
WHERE  status = 'A' 
  AND  "messageId" IN (370857508,370857522,370857529,370857534,370857543,370857544,370857547,370857553,370857555,370857569,370857570,370857573,370857687,370857692,370857695,370857698,370857703,370857704,370857708,370857713,370857721);
UPDATE 21
COMMIT;
-- Fri 24 Feb 2017 07:56:05 AM CST 
