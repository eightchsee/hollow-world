step=> 
SELECT m."messageId", m."clientMessageId" AS "_clntMsgId", m."destQueue", m."status" AS _st,
       to_char(m."created", 'Dy, Mon DD, YYYY HH12:MI:SS AM TZ') AS "_created",
       to_char(m."lastModified", 'Dy, Mon DD, YYYY HH12:MI:SS AM TZ') AS "_lastModified",
       "formatXMLString"('@countyNumber', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_cN",
       "formatXMLString"('@releaseType', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_relType",
       "formatXMLString"('dorWarrantNumber/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_dorWrrntNo",
       "formatXMLString"('caseNumber/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_caseNo",
       "formatXMLString"('releaseDate/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_relDate",
       "formatXMLString"('namePartial/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_namePartial"
FROM   "Message" AS m
  JOIN "Body"    AS b ON (b."bodySeqNo" = m."bodySeqNo")
WHERE  ("destQueue" ~ 'CCAPCorp-TaxWarrantRelease' AND "destQueue" ~ '-f')
  AND  status = 'A'                                                                                                                  
ORDER BY created;

 messageId | _clntMsgId |           destQueue            | _st |             _created              |           _lastModified           | _cN | _relType | _dorWrrntNo |   _caseNo    |  _relDate  |    _namePartial    
-----------+------------+--------------------------------+-----+-----------------------------------+-----------------------------------+-----+----------+-------------+--------------+------------+--------------------
 369523829 | 112246     | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:29 PM CST | Mon, Feb 06, 2017 10:50:29 PM CST | 05  | partial  | 05-11971256 | 2010TW000122 | 02-06-2017 | RITA K LINDE
 369523830 | 124236     | CCAPCorp-TaxWarrantRelease-f13 | A   | Mon, Feb 06, 2017 10:50:29 PM CST | Mon, Feb 06, 2017 10:50:29 PM CST | 13  | partial  | 13-00238047 | 2004TW000447 | 02-06-2017 | SHAWN ROBINSON
 369523831 | 1694226    | CCAPCorp-TaxWarrantRelease-f67 | A   | Mon, Feb 06, 2017 10:50:29 PM CST | Mon, Feb 06, 2017 10:50:29 PM CST | 67  | partial  | 67-00234349 | 2005TW001435 | 02-06-2017 | ISABEL L TERLINDEN
 369523834 | 120318     | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:29 PM CST | Mon, Feb 06, 2017 10:50:29 PM CST | 51  | partial  | 51-00193427 | 02TW000075   | 02-06-2017 | ROBERT R KLINGBEIL
 369523839 | 124237     | CCAPCorp-TaxWarrantRelease-f67 | A   | Mon, Feb 06, 2017 10:50:29 PM CST | Mon, Feb 06, 2017 10:50:29 PM CST | 67  | full     | 67-11954694 | 2014TW000668 | 02-06-2017 | 
 369523844 | 1676225    | CCAPCorp-TaxWarrantRelease-f67 | A   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 67  | full     | 67-11939785 | 2014TW000665 | 02-06-2017 | 
 369523846 | 136437     | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 05  | full     | 05-12178163 | 2016TW000578 | 02-06-2017 | 
 369523847 | 148290     | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 51  | full     | 51-11936981 | 2016TW000048 | 02-06-2017 | 
 369523848 | 132297     | CCAPCorp-TaxWarrantRelease-f13 | A   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 13  | full     | 13-11973889 | 2016TW000870 | 02-06-2017 | 
 369523850 | 120319     | CCAPCorp-TaxWarrantRelease-f13 | A   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 13  | full     | 13-11787371 | 2012TW001435 | 02-06-2017 | 
 369523854 | 1694227    | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 51  | full     | 51-11925450 | 2014TW000384 | 02-06-2017 | 
 369523856 | 140319     | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 05  | full     | 05-11803564 | 2010TW000543 | 02-06-2017 | 
 369523859 | 120322     | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 51  | full     | 51-11924790 | 2013TW000182 | 02-06-2017 | 
 369523861 | 112249     | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 05  | full     | 05-12184105 | 2016TW000159 | 02-06-2017 | 
 369523862 | 1060995    | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 05  | full     | 05-11803564 | 2010TW000543 | 02-06-2017 | 
 369523864 | 128332     | CCAPCorp-TaxWarrantRelease-f18 | A   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 18  | partial  | 18-00164484 | 02TW000087   | 02-06-2017 | ERNEST N WACKWITZ
 369523866 | 1062994    | CCAPCorp-TaxWarrantRelease-f13 | A   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 13  | full     | 13-11980530 | 2014TW001306 | 02-06-2017 | 
 369523870 | 132299     | CCAPCorp-TaxWarrantRelease-f53 | A   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 53  | partial  | 53-00182276 | 2006TW000247 | 02-06-2017 | SHIRLEY BUTT
 369523873 | 120324     | CCAPCorp-TaxWarrantRelease-f13 | A   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 13  | full     | 13-11973768 | 2015TW001529 | 02-06-2017 | 
 369523874 | 120325     | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 05  | full     | 05-12091683 | 2016TW000567 | 02-06-2017 | 
 369523875 | 1052988    | CCAPCorp-TaxWarrantRelease-f13 | A   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 13  | full     | 13-12064064 | 2014TW000220 | 02-06-2017 | 
 369523876 | 1066972    | CCAPCorp-TaxWarrantRelease-f67 | A   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 67  | full     | 67-11978906 | 2016TW000960 | 02-06-2017 | 
 369523878 | 112251     | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 05  | full     | 05-11976819 | 2016TW000574 | 02-06-2017 | 
 369523880 | 1064988    | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 05  | full     | 05-11967971 | 2016TW000568 | 02-06-2017 | 
 369523881 | 1066973    | CCAPCorp-TaxWarrantRelease-f13 | A   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 13  | full     | 13-11941418 | 2014TW001588 | 02-06-2017 | 
 369523885 | 144294     | CCAPCorp-TaxWarrantRelease-f42 | A   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 42  | partial  | 42-11828763 | 2010TW000013 | 02-06-2017 | RITA WOOD
 369523886 | 1056953    | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 40  | partial  | 40-00462701 | 2004TW005488 | 02-06-2017 | SHERLENE K BOSSE
 369523888 | 136438     | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 40  | full     | 40-11925814 | 2017TW000024 | 02-06-2017 | 
 369523890 | 1052990    | CCAPCorp-TaxWarrantRelease-f53 | A   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 53  | full     | 53-11723986 | 2013TW000140 | 02-06-2017 | 
 369523891 | 132300     | CCAPCorp-TaxWarrantRelease-f13 | A   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 13  | full     | 13-11979770 | 2016TW000950 | 02-06-2017 | 
 369523892 | 136439     | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 05  | full     | 05-12185114 | 2016TW000311 | 02-06-2017 | 
 369523894 | 112252     | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 05  | full     | 05-12197040 | 2016TW000586 | 02-06-2017 | 
 369523895 | 1676227    | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 05  | full     | 05-11956788 | 2015TW000299 | 02-06-2017 | 
 369523901 | 1064989    | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 51  | partial  | 70-11602469 | 2014TW000030 | 02-06-2017 | RICK E JACOBSEN
 369523904 | 1062996    | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 40  | full     | 40-12003513 | 2014TW003326 | 02-06-2017 | 
 369523905 | 1058992    | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 51  | full     | 51-11949758 | 2014TW000496 | 02-06-2017 | 
 369523906 | 1060996    | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 40  | full     | 40-12163230 | 2016TW002348 | 02-06-2017 | 
 369523916 | 1062999    | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 40  | full     | 40-11951711 | 2015TW000555 | 02-06-2017 | 
 369523918 | 112257     | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 05  | full     | 05-12197041 | 2016TW000580 | 02-06-2017 | 
 369523920 | 112258     | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 51  | full     | 51-11976505 | 2014TW000414 | 02-06-2017 | 
 369523921 | 128334     | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 40  | full     | 40-11650329 | 2011TW002622 | 02-06-2017 | 
 369523924 | 124239     | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 51  | full     | 51-11923875 | 2014TW000026 | 02-06-2017 | 
 369523926 | 1676228    | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 40  | full     | 40-11999559 | 2015TW000754 | 02-06-2017 | 
 369523928 | 128335     | CCAPCorp-TaxWarrantRelease-f09 | A   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 09  | partial  | 09-00157850 | 01TW000144   | 02-06-2017 | WILLIAM WALMSLEY
 369523929 | 136440     | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 51  | full     | 51-11736909 | 2011TW000860 | 02-06-2017 | 
 369523933 | 1072867    | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 05  | partial  | 05-11999178 | 2010TW000121 | 02-06-2017 | RITA K LINDE
 369523934 | 1056957    | CCAPCorp-TaxWarrantRelease-f13 | A   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 13  | full     | 13-00222872 | 98TW000818   | 02-06-2017 | 
 369523936 | 1068898    | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 40  | full     | 40-11639880 | 2012TW001188 | 02-06-2017 | 
 369523938 | 136441     | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 51  | full     | 51-11963660 | 2014TW000534 | 02-06-2017 | 
 369523940 | 1064991    | CCAPCorp-TaxWarrantRelease-f13 | A   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 13  | full     | 13-11967715 | 2015TW000339 | 02-06-2017 | 
 369523942 | 136442     | CCAPCorp-TaxWarrantRelease-f53 | A   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 53  | full     | 53-11596660 | 2012TW000346 | 02-06-2017 | 
 369523948 | 1060999    | CCAPCorp-TaxWarrantRelease-f53 | A   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 53  | full     | 53-11975464 | 2014TW000207 | 02-06-2017 | 
 369523952 | 128337     | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 40  | full     | 40-11714892 | 2014TW000007 | 02-06-2017 | 
 369523954 | 1066974    | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 40  | full     | 40-11978916 | 2017TW000043 | 02-06-2017 | 
 369523958 | 124241     | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 40  | full     | 40-11933590 | 2012TW002524 | 02-06-2017 | 
 369523959 | 1064992    | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 05  | full     | 05-11956788 | 2015TW000299 | 02-06-2017 | 
 369523961 | 136445     | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 51  | partial  | 51-00191336 | 00TW001180   | 02-06-2017 | ROBERT R KLINGBEIL
 369523968 | 124242     | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 05  | full     | 05-12075505 | 2016TW000312 | 02-06-2017 | 
 369523969 | 1072869    | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 05  | full     | 05-12093701 | 2016TW000559 | 02-06-2017 | 
 369523974 | 1052998    | CCAPCorp-TaxWarrantRelease-f67 | A   | Mon, Feb 06, 2017 10:50:33 PM CST | Mon, Feb 06, 2017 10:50:33 PM CST | 67  | full     | 67-11828853 | 2010TW001743 | 02-06-2017 | 
 369523975 | 128339     | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:33 PM CST | Mon, Feb 06, 2017 10:50:33 PM CST | 51  | full     | 51-11829499 | 2013TW000505 | 02-06-2017 | 
 369523976 | 132301     | CCAPCorp-TaxWarrantRelease-f13 | A   | Mon, Feb 06, 2017 10:50:33 PM CST | Mon, Feb 06, 2017 10:50:33 PM CST | 13  | full     | 13-12099403 | 2014TW000219 | 02-06-2017 | 
 369523977 | 132302     | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:33 PM CST | Mon, Feb 06, 2017 10:50:33 PM CST | 51  | partial  | 51-00192768 | 01TW001026   | 02-06-2017 | FLOYD HOPKINS
 369523979 | 1072870    | CCAPCorp-TaxWarrantRelease-f13 | A   | Mon, Feb 06, 2017 10:50:33 PM CST | Mon, Feb 06, 2017 10:50:33 PM CST | 13  | full     | 13-11961963 | 2016TW000730 | 02-06-2017 | 
 369523980 | 1676234    | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:33 PM CST | Mon, Feb 06, 2017 10:50:33 PM CST | 51  | full     | 51-11812553 | 2009TW000896 | 02-06-2017 | 
 369523984 | 1676235    | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:33 PM CST | Mon, Feb 06, 2017 10:50:33 PM CST | 51  | full     | 51-11829496 | 2013TW000504 | 02-06-2017 | 
 369523985 | 1064994    | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:33 PM CST | Mon, Feb 06, 2017 10:50:33 PM CST | 05  | full     | 05-12093700 | 2016TW000579 | 02-06-2017 | 
 369523988 | 112260     | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:33 PM CST | Mon, Feb 06, 2017 10:50:33 PM CST | 05  | full     | 05-12195058 | 2016TW000585 | 02-06-2017 | 
 369523989 | 1074860    | CCAPCorp-TaxWarrantRelease-f67 | A   | Mon, Feb 06, 2017 10:50:33 PM CST | Mon, Feb 06, 2017 10:50:33 PM CST | 67  | full     | 67-12097042 | 2009TW000406 | 02-06-2017 | 
 369523991 | 1676236    | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:33 PM CST | Mon, Feb 06, 2017 10:50:33 PM CST | 40  | full     | 40-11714892 | 2014TW000007 | 02-06-2017 | 
 369523993 | 1688236    | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:33 PM CST | Mon, Feb 06, 2017 10:50:33 PM CST | 05  | full     | 05-11967970 | 2016TW000546 | 02-06-2017 | 
 369524000 | 1058997    | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:33 PM CST | Mon, Feb 06, 2017 10:50:33 PM CST | 40  | full     | 40-11967737 | 2015TW001198 | 02-06-2017 | 
 369524001 | 1694230    | CCAPCorp-TaxWarrantRelease-f67 | A   | Mon, Feb 06, 2017 10:50:33 PM CST | Mon, Feb 06, 2017 10:50:33 PM CST | 67  | partial  | 67-00225451 | 01TW002107   | 02-06-2017 | VIRGINIA CAMERON
 369524002 | 136448     | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:33 PM CST | Mon, Feb 06, 2017 10:50:33 PM CST | 05  | full     | 05-12003745 | 2016TW000571 | 02-06-2017 | 
 369524003 | 1056958    | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:33 PM CST | Mon, Feb 06, 2017 10:50:33 PM CST | 40  | full     | 40-11788681 | 2009TW006441 | 02-06-2017 | 
 369524005 | 1064997    | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:33 PM CST | Mon, Feb 06, 2017 10:50:33 PM CST | 40  | full     | 40-11975800 | 2016TW002408 | 02-06-2017 | 
 369524012 | 128340     | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:38 PM CST | Mon, Feb 06, 2017 10:50:38 PM CST | 40  | full     | 40-11780316 | 2008TW001521 | 02-06-2017 | 
 369524013 | 1078910    | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:38 PM CST | Mon, Feb 06, 2017 10:50:38 PM CST | 40  | partial  | 40-00455454 | 2003TW001761 | 02-06-2017 | SAMUEL JACKSON
 369524014 | 1676238    | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:38 PM CST | Mon, Feb 06, 2017 10:50:38 PM CST | 40  | full     | 40-12077273 | 2016TW001713 | 02-06-2017 | 
 369524035 | 1084805    | CCAPCorp-TaxWarrantRelease-f67 | A   | Mon, Feb 06, 2017 10:50:47 PM CST | Mon, Feb 06, 2017 10:50:47 PM CST | 67  | full     | 67-11969857 | 2016TW000968 | 02-06-2017 | 
 369524036 | 1090805    | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:47 PM CST | Mon, Feb 06, 2017 10:50:47 PM CST | 05  | full     | 05-12065396 | 2016TW000309 | 02-06-2017 | 
 369524040 | 1086732    | CCAPCorp-TaxWarrantRelease-f67 | A   | Mon, Feb 06, 2017 10:50:47 PM CST | Mon, Feb 06, 2017 10:50:47 PM CST | 67  | full     | 67-11941702 | 2016TW000969 | 02-06-2017 | 
 369524042 | 1092764    | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:47 PM CST | Mon, Feb 06, 2017 10:50:47 PM CST | 51  | full     | 51-12165194 | 2016TW000360 | 02-06-2017 | 
 369524043 | 148292     | CCAPCorp-TaxWarrantRelease-f67 | A   | Mon, Feb 06, 2017 10:50:47 PM CST | Mon, Feb 06, 2017 10:50:47 PM CST | 67  | partial  | 67-00235691 | 2006TW001078 | 02-06-2017 | LISA TEAYS
 369524044 | 1694231    | CCAPCorp-TaxWarrantRelease-f67 | A   | Mon, Feb 06, 2017 10:50:47 PM CST | Mon, Feb 06, 2017 10:50:47 PM CST | 67  | full     | 67-00237695 | 2007TW001762 | 02-06-2017 | 
 369524046 | 1100706    | CCAPCorp-TaxWarrantRelease-f67 | A   | Mon, Feb 06, 2017 10:50:47 PM CST | Mon, Feb 06, 2017 10:50:47 PM CST | 67  | full     | 67-11982650 | 2015TW000870 | 02-06-2017 | 
 369524048 | 1562736    | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:47 PM CST | Mon, Feb 06, 2017 10:50:47 PM CST | 05  | full     | 05-12195057 | 2016TW000581 | 02-06-2017 | 
 369524049 | 1626617    | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:47 PM CST | Mon, Feb 06, 2017 10:50:47 PM CST | 40  | partial  | 40-00462702 | 2004TW005489 | 02-06-2017 | SHERLENE K BOSSE
 369524051 | 1682270    | CCAPCorp-TaxWarrantRelease-f13 | A   | Mon, Feb 06, 2017 10:50:47 PM CST | Mon, Feb 06, 2017 10:50:47 PM CST | 13  | full     | 13-11752681 | 2010TW001696 | 02-06-2017 | 
 369524053 | 1638438    | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:47 PM CST | Mon, Feb 06, 2017 10:50:47 PM CST | 51  | full     | 51-11727549 | 2014TW000025 | 02-06-2017 | 
 369524075 | 112261     | CCAPCorp-TaxWarrantRelease-f13 | A   | Mon, Feb 06, 2017 10:51:05 PM CST | Mon, Feb 06, 2017 10:51:05 PM CST | 13  | full     | 13-11950609 | 2013TW000939 | 02-06-2017 | 
 369524077 | 1642443    | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:51:05 PM CST | Mon, Feb 06, 2017 10:51:05 PM CST | 05  | full     | 05-11913321 | 2010TW000301 | 02-06-2017 | 
 369524078 | 128341     | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:51:05 PM CST | Mon, Feb 06, 2017 10:51:05 PM CST | 51  | partial  | 51-00196138 | 2004TW000846 | 02-06-2017 | SCOTT KIPP
 369524079 | 1064998    | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:51:05 PM CST | Mon, Feb 06, 2017 10:51:05 PM CST | 40  | full     | 40-11976822 | 2016TW002708 | 02-06-2017 | 
 369524080 | 1642444    | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:51:05 PM CST | Mon, Feb 06, 2017 10:51:05 PM CST | 40  | full     | 40-11899545 | 2011TW002908 | 02-06-2017 | 
 369524083 | 1650388    | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:51:05 PM CST | Mon, Feb 06, 2017 10:51:05 PM CST | 05  | full     | 05-11608423 | 2011TW000722 | 02-06-2017 | 
 369524084 | 1100707    | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:51:05 PM CST | Mon, Feb 06, 2017 10:51:05 PM CST | 05  | full     | 05-11981527 | 2014TW000528 | 02-06-2017 | 
 369524085 | 1652349    | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:51:05 PM CST | Mon, Feb 06, 2017 10:51:05 PM CST | 40  | full     | 40-11948885 | 2016TW000130 | 02-06-2017 | 
 369524091 | 148293     | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:51:05 PM CST | Mon, Feb 06, 2017 10:51:05 PM CST | 05  | full     | 05-12131742 | 2016TW000310 | 02-06-2017 | 
 369524094 | 1068903    | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:51:05 PM CST | Mon, Feb 06, 2017 10:51:05 PM CST | 40  | full     | 40-11919958 | 2014TW000682 | 02-06-2017 | 
 369524095 | 1624623    | CCAPCorp-TaxWarrantRelease-f67 | A   | Mon, Feb 06, 2017 10:51:05 PM CST | Mon, Feb 06, 2017 10:51:05 PM CST | 67  | full     | 67-12173171 | 2016TW000801 | 02-06-2017 | 
(101 rows)

-- Tue 07 Feb 2017 12:46:51 PM CST <== about 45 minutes before that time
step=> 
SELECT m."messageId", m."clientMessageId" AS "_clntMsgId", m."destQueue", m."status" AS _st,
       to_char(m."created", 'Dy, Mon DD, YYYY HH12:MI:SS AM TZ') AS "_created",
       to_char(m."lastModified", 'Dy, Mon DD, YYYY HH12:MI:SS AM TZ') AS "_lastModified",
       "formatXMLString"('@countyNumber', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_cN",
       "formatXMLString"('@releaseType', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_relType",
       "formatXMLString"('dorWarrantNumber/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_dorWrrntNo",
       "formatXMLString"('caseNumber/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_caseNo",
       "formatXMLString"('releaseDate/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_relDate",
       "formatXMLString"('namePartial/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_namePartial"
FROM   "Message" AS m
  JOIN "Body"    AS b ON (b."bodySeqNo" = m."bodySeqNo")
WHERE  ("destQueue" ~ 'CCAPCorp-TaxWarrantRelease' AND "destQueue" ~ '-f')
  AND  status = 'A' AND "formatXMLString"('@releaseType', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) = 'partial'
ORDER BY created;
 messageId | _clntMsgId |           destQueue            | _st |             _created              |           _lastModified           | _cN | _relType | _dorWrrntNo |   _caseNo    |  _relDate  |    _namePartial    
-----------+------------+--------------------------------+-----+-----------------------------------+-----------------------------------+-----+----------+-------------+--------------+------------+--------------------
 369523829 | 112246     | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:29 PM CST | Mon, Feb 06, 2017 10:50:29 PM CST | 05  | partial  | 05-11971256 | 2010TW000122 | 02-06-2017 | RITA K LINDE
 369523830 | 124236     | CCAPCorp-TaxWarrantRelease-f13 | A   | Mon, Feb 06, 2017 10:50:29 PM CST | Mon, Feb 06, 2017 10:50:29 PM CST | 13  | partial  | 13-00238047 | 2004TW000447 | 02-06-2017 | SHAWN ROBINSON
 369523831 | 1694226    | CCAPCorp-TaxWarrantRelease-f67 | A   | Mon, Feb 06, 2017 10:50:29 PM CST | Mon, Feb 06, 2017 10:50:29 PM CST | 67  | partial  | 67-00234349 | 2005TW001435 | 02-06-2017 | ISABEL L TERLINDEN
 369523834 | 120318     | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:29 PM CST | Mon, Feb 06, 2017 10:50:29 PM CST | 51  | partial  | 51-00193427 | 02TW000075   | 02-06-2017 | ROBERT R KLINGBEIL
 369523864 | 128332     | CCAPCorp-TaxWarrantRelease-f18 | A   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 18  | partial  | 18-00164484 | 02TW000087   | 02-06-2017 | ERNEST N WACKWITZ
 369523870 | 132299     | CCAPCorp-TaxWarrantRelease-f53 | A   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 53  | partial  | 53-00182276 | 2006TW000247 | 02-06-2017 | SHIRLEY BUTT
 369523885 | 144294     | CCAPCorp-TaxWarrantRelease-f42 | A   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 42  | partial  | 42-11828763 | 2010TW000013 | 02-06-2017 | RITA WOOD
 369523886 | 1056953    | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 40  | partial  | 40-00462701 | 2004TW005488 | 02-06-2017 | SHERLENE K BOSSE
 369523901 | 1064989    | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 51  | partial  | 70-11602469 | 2014TW000030 | 02-06-2017 | RICK E JACOBSEN
 369523928 | 128335     | CCAPCorp-TaxWarrantRelease-f09 | A   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 09  | partial  | 09-00157850 | 01TW000144   | 02-06-2017 | WILLIAM WALMSLEY
 369523933 | 1072867    | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 05  | partial  | 05-11999178 | 2010TW000121 | 02-06-2017 | RITA K LINDE
 369523961 | 136445     | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 51  | partial  | 51-00191336 | 00TW001180   | 02-06-2017 | ROBERT R KLINGBEIL
 369523977 | 132302     | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:33 PM CST | Mon, Feb 06, 2017 10:50:33 PM CST | 51  | partial  | 51-00192768 | 01TW001026   | 02-06-2017 | FLOYD HOPKINS
 369524001 | 1694230    | CCAPCorp-TaxWarrantRelease-f67 | A   | Mon, Feb 06, 2017 10:50:33 PM CST | Mon, Feb 06, 2017 10:50:33 PM CST | 67  | partial  | 67-00225451 | 01TW002107   | 02-06-2017 | VIRGINIA CAMERON
 369524013 | 1078910    | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:38 PM CST | Mon, Feb 06, 2017 10:50:38 PM CST | 40  | partial  | 40-00455454 | 2003TW001761 | 02-06-2017 | SAMUEL JACKSON
 369524043 | 148292     | CCAPCorp-TaxWarrantRelease-f67 | A   | Mon, Feb 06, 2017 10:50:47 PM CST | Mon, Feb 06, 2017 10:50:47 PM CST | 67  | partial  | 67-00235691 | 2006TW001078 | 02-06-2017 | LISA TEAYS
 369524049 | 1626617    | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:47 PM CST | Mon, Feb 06, 2017 10:50:47 PM CST | 40  | partial  | 40-00462702 | 2004TW005489 | 02-06-2017 | SHERLENE K BOSSE
 369524078 | 128341     | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:51:05 PM CST | Mon, Feb 06, 2017 10:51:05 PM CST | 51  | partial  | 51-00196138 | 2004TW000846 | 02-06-2017 | SCOTT KIPP
(18 rows)

