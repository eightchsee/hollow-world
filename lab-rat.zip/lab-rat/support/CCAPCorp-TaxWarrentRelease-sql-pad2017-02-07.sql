-- Tue 07 Feb 2017 11:27:18 AM CST 

-- in: us.wi.state.courts.ccap.intclients.v70.dor.TaxWarrantRelease.insert(JadeCounty)

-- CivilJdgmtEQ
jdgmtLienType | dbtrNameL         | dbtrNameF | dbtrNameM | dbtrSuffix | hasMultipleDbtrs | totAmt  | satisfaction | dateDkted  | isDkted | jdgmtDate  | caseNo       | civilJdgmtSeqNo | countyNo | caption                                           | isElectronicFile | isVerifiedTax | lastCvJEventSeqNo | lastCvJMoneySeqNo | lastJdgmtPartyNo | dorAcctNo   | dorCountyNo | dorWarrantNo | fullSatisDate | interestCalcTo | pdOfYear   | propertyDescr | svcDateFrom | svcDateTo | timeDkted | typeOfTax | statusCode | maintCode | filingDate | dbtrSearchName             | interestEffDate | 
--------------|-------------------|-----------|-----------|------------|------------------|---------|--------------|------------|---------|------------|--------------|-----------------|----------|---------------------------------------------------|------------------|---------------|-------------------|-------------------|------------------|-------------|-------------|--------------|---------------|----------------|------------|---------------|-------------|-----------|-----------|-----------|------------|-----------|------------|----------------------------|-----------------|
TW            | BRANDENBURG TRUST | RALPH     | LEON      |            | false            | 2986.79 | F            | 02-09-2004 | Y       | 05-26-2003 | 2004TW000447 | 1               | 13       | Dept. of Revenue vs. RALPH LEON BRANDENBURG TRUST | true             | false         | 2                 | 3                 | 4                | C7KRZXZ9001 | 13          | 13-00238047  | 03-19-2007    | 02-19-2004     | VAR   1999 |               |             |           | 08:56 am  | INCOME    | FL         |           | 02-09-2004 | BRANDENBURGTRUST,RALPHLEON | 05-26-2003      | 


-- CvJdgmtEventRSQ
date       | caseNo       | civilJdgmtSeqNo | cvJEventSeqNo | civilEventType | descr                | additionalTxt                     | satisfactionAmt | countyNo | satisfaction | 
-----------|--------------|-----------------|---------------|----------------|----------------------|-----------------------------------|-----------------|----------|--------------|
03-19-2007 | 2004TW000447 | 1               | 1             | PS             | Partial satisfaction | SHAWN ROBINSON is fully satisfied | 0.00            | 13       | P            | 
03-19-2007 | 2004TW000447 | 1               | 2             | FS             | Full satisfaction    | Judgment is fully satisfied       | 0.00            | 13       | F            | 


SELECT m."messageId", m."clientMessageId" AS "_clntMsgId", m."destQueue", m."status" AS _st,
       to_char(m."created", 'Dy, Mon DD, YYYY HH12:MI:SS AM TZ') AS "_created",
       to_char(m."lastModified", 'Dy, Mon DD, YYYY HH12:MI:SS AM TZ') AS "_lastModified",
       "formatXMLString"('@countyNumber', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_cN",
       "formatXMLString"('@releaseType', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_relType",
       "formatXMLString"('dorWarrantNumber/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_dorWrrntNo",
       "formatXMLString"('caseNumber/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_caseNo",
       "formatXMLString"('releaseDate/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_relDate",
       "formatXMLString"('namePartial/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_namePartial"
FROM   "Message" AS m
  JOIN "Body"    AS b ON (b."bodySeqNo" = m."bodySeqNo")
WHERE  "messageId" = 369523829;

SELECT m."messageId", m."clientMessageId" AS "_clntMsgId", m."destQueue", m."status" AS _st,
       to_char(m."created", 'Dy, Mon DD, YYYY HH12:MI:SS AM TZ') AS "_created",
       to_char(m."lastModified", 'Dy, Mon DD, YYYY HH12:MI:SS AM TZ') AS "_lastModified",
       "formatXMLString"('@countyNumber', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_cN",
       "formatXMLString"('@releaseType', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_relType",
       "formatXMLString"('dorWarrantNumber/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_dorWrrntNo",
       "formatXMLString"('caseNumber/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_caseNo",
       "formatXMLString"('releaseDate/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_relDate",
       "formatXMLString"('namePartial/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_namePartial"
FROM   "Message" AS m
  JOIN "Body"    AS b ON (b."bodySeqNo" = m."bodySeqNo")
WHERE  ("destQueue" ~ 'CCAPCorp-TaxWarrantRelease' AND "destQueue" ~ '-f')
  AND  status = 'A'
ORDER BY created;
