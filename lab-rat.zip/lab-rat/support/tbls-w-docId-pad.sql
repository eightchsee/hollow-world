-- Mon 10 Dec 2018 12:09:55 PM CST 

-- 1.) Does the code reference DocImage rows that aren't referenced by DocImageMetaData, CaseDocImage, or ??(other tables that may join to DocImage).

-- DocRedaction


AppealsDocIndex
AppealsIndexCaseDoc
CaseDocImage             
CaseDocImage                   | unsignedDocId
CaseDocImageReview       
CaseOptInHist            
CoVDocImage                    | newDocId
CoVDocImage                    | sourceDocId
CtofcNotification        
Doc                      
DocAdvancedSignature     
DocAdvancedSignatureCtofc
DocAnnotation            
DocDraft                       | draftDocId
DocDraft                       | unsignedDocId
DocGroupDocument         
DocImage                 
DocImageMetaData         
DocImageMetaData               | newDocId
DocImageMetaDataReview   
DocImageOcrStatus        
DocIndexDocumentRow      
DocLink                  
DocNote                  
DocNoteTransfer          
DocNoticeAssocFiler      
DocNoticeAttyParty       
DocNoticeHist            
DocNoticeParty           
DocPurchQueue            
DocRedaction                   | redactedDocId
DocRedaction                   | unredactedDocId
DocSpecialAccess         
DotCitnXmlDocument       
EAccountNotification     
EFiledRejectedDoc        
GenericLetterTemplate          | genericLetterDocId
JuryDocMetadata          
LegacyDIMD               
NewFilingEAccountNotification  | docId
PageAnnotation           
PoolRequestResponseDocMetadata | docId
RedactionAttempt         
RejectEAccountNotification     | docId
ScannedDoc               
StepAgencyExpDOC         
StepAgencyExpDOCAttach   
StepChildWelDoc          
StepDocument             
StepEFileDocument        
SystemGeneratedDoc       
SystemGeneratedDoc             | redactedDocId
TagDoc                   
TranscriptAccess         
TranscriptUserAccess     
XMLDocuments             
XMLMetaData 
