
-- begin @: Fri Feb 10 10:39:15 CST 2017
 messageId | _clntMsgId |           destQueue            | _st |             _created              |           _lastModified           | _cN | _relType | _dorWrrntNo |   _caseNo    |  _relDate  |    _namePartial    |                                                               url                                                               
-----------+------------+--------------------------------+-----+-----------------------------------+-----------------------------------+-----+----------+-------------+--------------+------------+--------------------+---------------------------------------------------------------------------------------------------------------------------------
** 369833757 | 1690228    | CCAPCorp-TaxWarrantRelease-f51 | A   | Thu, Feb 09, 2017 09:37:25 PM CST | Thu, Feb 09, 2017 09:37:25 PM CST | 51  | partial  | 51-00193427 | 02TW000075   | 02-09-2017 | ROBERT R KLINGBEIL | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f51&messageId=369833757
** 369833762 | 1674242    | CCAPCorp-TaxWarrantRelease-f05 | A   | Thu, Feb 09, 2017 09:37:25 PM CST | Thu, Feb 09, 2017 09:37:25 PM CST | 05  | partial  | 05-11971256 | 2010TW000122 | 02-09-2017 | RITA K LINDE       | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f05&messageId=369833762
** 369833821 | 1726057    | CCAPCorp-TaxWarrantRelease-f42 | A   | Thu, Feb 09, 2017 09:37:51 PM CST | Thu, Feb 09, 2017 09:37:51 PM CST | 42  | partial  | 42-11828763 | 2010TW000013 | 02-09-2017 | RITA WOOD          | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f42&messageId=369833821
** 369833823 | 1728070    | CCAPCorp-TaxWarrantRelease-f40 | A   | Thu, Feb 09, 2017 09:37:51 PM CST | Thu, Feb 09, 2017 09:37:51 PM CST | 40  | partial  | 40-00473553 | 2007TW000945 | 02-09-2017 | SHARECA THOMPSON   | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f40&messageId=369833823
** 369833827 | 1730069    | CCAPCorp-TaxWarrantRelease-f13 | A   | Thu, Feb 09, 2017 09:37:51 PM CST | Thu, Feb 09, 2017 09:37:51 PM CST | 13  | partial  | 13-00238047 | 2004TW000447 | 02-09-2017 | SHAWN ROBINSON     | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f13&messageId=369833827
 369833828 | 1732050    | CCAPCorp-TaxWarrantRelease-f05 | A   | Thu, Feb 09, 2017 09:37:51 PM CST | Thu, Feb 09, 2017 09:37:51 PM CST | 05  | partial  | 05-11999178 | 2010TW000121 | 02-09-2017 | RITA K LINDE       | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f05&messageId=369833828
 369833836 | 1672222    | CCAPCorp-TaxWarrantRelease-f40 | A   | Thu, Feb 09, 2017 09:37:52 PM CST | Thu, Feb 09, 2017 09:37:52 PM CST | 40  | partial  | 40-00462701 | 2004TW005488 | 02-09-2017 | SHERLENE K BOSSE   | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f40&messageId=369833836
 369833846 | 1738058    | CCAPCorp-TaxWarrantRelease-f40 | A   | Thu, Feb 09, 2017 09:38:02 PM CST | Thu, Feb 09, 2017 09:38:02 PM CST | 40  | partial  | 40-00455454 | 2003TW001761 | 02-09-2017 | SAMUEL JACKSON     | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f40&messageId=369833846
** 369833848 | 1740033    | CCAPCorp-TaxWarrantRelease-f18 | A   | Thu, Feb 09, 2017 09:38:02 PM CST | Thu, Feb 09, 2017 09:38:02 PM CST | 18  | partial  | 18-00164484 | 02TW000087   | 02-09-2017 | ERNEST N WACKWITZ  | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f18&messageId=369833848
** 369833874 | 1668329    | CCAPCorp-TaxWarrantRelease-f10 | A   | Thu, Feb 09, 2017 09:38:21 PM CST | Thu, Feb 09, 2017 09:38:21 PM CST | 10  | partial  | 10-00154058 | 2006TW000012 | 02-09-2017 | EMIL UNTIEDT JR    | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f10&messageId=369833874
** 369833879 | 1702157    | CCAPCorp-TaxWarrantRelease-f67 | A   | Thu, Feb 09, 2017 09:38:22 PM CST | Thu, Feb 09, 2017 09:38:22 PM CST | 67  | partial  | 67-00234349 | 2005TW001435 | 02-09-2017 | ISABEL L TERLINDEN | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f67&messageId=369833879
 369833880 | 1738059    | CCAPCorp-TaxWarrantRelease-f40 | A   | Thu, Feb 09, 2017 09:38:22 PM CST | Thu, Feb 09, 2017 09:38:22 PM CST | 40  | partial  | 40-00462702 | 2004TW005489 | 02-09-2017 | SHERLENE K BOSSE   | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f40&messageId=369833880
 369833882 | 1742065    | CCAPCorp-TaxWarrantRelease-f51 | A   | Thu, Feb 09, 2017 09:38:22 PM CST | Thu, Feb 09, 2017 09:38:22 PM CST | 51  | partial  | 70-11602469 | 2014TW000030 | 02-09-2017 | RICK E JACOBSEN    | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f51&messageId=369833882
 369833883 | 1736037    | CCAPCorp-TaxWarrantRelease-f67 | A   | Thu, Feb 09, 2017 09:38:22 PM CST | Thu, Feb 09, 2017 09:38:22 PM CST | 67  | partial  | 67-00235691 | 2006TW001078 | 02-09-2017 | LISA TEAYS         | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f67&messageId=369833883
 369833888 | 1672224    | CCAPCorp-TaxWarrantRelease-f51 | A   | Thu, Feb 09, 2017 09:38:22 PM CST | Thu, Feb 09, 2017 09:38:22 PM CST | 51  | partial  | 51-00192768 | 01TW001026   | 02-09-2017 | FLOYD HOPKINS      | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f51&messageId=369833888
** 369833892 | 1686225    | CCAPCorp-TaxWarrantRelease-f09 | A   | Thu, Feb 09, 2017 09:38:22 PM CST | Thu, Feb 09, 2017 09:38:22 PM CST | 09  | partial  | 09-00157850 | 01TW000144   | 02-09-2017 | WILLIAM WALMSLEY   | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f09&messageId=369833892
** 369833894 | 1728074    | CCAPCorp-TaxWarrantRelease-f11 | A   | Thu, Feb 09, 2017 09:38:22 PM CST | Thu, Feb 09, 2017 09:38:22 PM CST | 11  | partial  | 11-00159228 | 99TW000454   | 02-09-2017 | FRANCIS R KIEFER   | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f11&messageId=369833894
 369833909 | 1690231    | CCAPCorp-TaxWarrantRelease-f11 | A   | Thu, Feb 09, 2017 09:38:57 PM CST | Thu, Feb 09, 2017 09:38:57 PM CST | 11  | partial  | 11-00005338 |              | 02-09-2017 | FRANCIS R KIEFER   | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f11&messageId=369833909
 369833912 | 1732051    | CCAPCorp-TaxWarrantRelease-f51 | A   | Thu, Feb 09, 2017 09:38:57 PM CST | Thu, Feb 09, 2017 09:38:57 PM CST | 51  | partial  | 51-00191336 | 00TW001180   | 02-09-2017 | ROBERT R KLINGBEIL | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f51&messageId=369833912
 369833915 | 1724108    | CCAPCorp-TaxWarrantRelease-f51 | A   | Thu, Feb 09, 2017 09:38:57 PM CST | Thu, Feb 09, 2017 09:38:57 PM CST | 51  | partial  | 51-00196138 | 2004TW000846 | 02-09-2017 | SCOTT KIPP         | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f51&messageId=369833915
** 369833917 | 1698190    | CCAPCorp-TaxWarrantRelease-f53 | A   | Thu, Feb 09, 2017 09:38:57 PM CST | Thu, Feb 09, 2017 09:38:57 PM CST | 53  | partial  | 53-00182276 | 2006TW000247 | 02-09-2017 | SHIRLEY BUTT       | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f53&messageId=369833917
** 369833919 | 1066978    | CCAPCorp-TaxWarrantRelease-f15 | A   | Thu, Feb 09, 2017 09:38:57 PM CST | Thu, Feb 09, 2017 09:38:57 PM CST | 15  | partial  | 15-00155756 | 01TW000018   | 02-09-2017 | LINDA LEROY        | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f15&messageId=369833919
(22 rows)
-- end   @: Fri Feb 10 10:39:58 CST 2017

\set case_no 2016CF002213
\set pros_atty 1069328
\i /tmp/chck-DaUpdate.sql


-- Wed 22 Feb 2017 04:51:43 PM CST 
-- the following was done earlier today
step=>
BEGIN;

UPDATE "Message" SET status = 'D', "lastModified" = CURRENT_TIMESTAMP
WHERE  status = 'A' 
  AND  "messageId" IN (370648709,370648712,370648715,370648716,370648718,370648719,370648720,370648721,370648722,370648726,370648727,370648729,370648732,370648733,370648735,370648737,370648738,370648741,370648742,370648743,370648745);

-- Wed 22 Feb 2017 05:06:44 PM CST 
BEGIN;

UPDATE "Message" SET status = 'A', "lastModified" = CURRENT_TIMESTAMP
WHERE  status = 'D' 
  AND  "messageId" IN (370648709,370648712,370648715,370648716,370648718,370648719,370648720,370648721,370648722,370648726,370648727,370648729,370648732,370648733,370648735,370648737,370648738,370648741,370648742,370648743,370648745);

\set msg_id 370648709,370648712,370648715,370648716,370648718,370648719,370648720,370648721,370648722,370648726,370648727,370648729,370648732,370648733,370648735,370648737,370648738,370648741,370648742,370648743,370648745
\i /tmp/ccap-corp-taxwarrant-rel-byMsgId.sql


); --,,,,,,,,,,,,,,,,,,,,);
370648716 370648741 370648745 370648715 370648738 370648737 370648709 370648729 370648733 370648719 370648712 370648722 370648718 370648732 370648727 370648726 370648721 370648742 370648735
370648743 370648720 
BEGIN;

UPDATE "Message" SET status = 'D', "lastModified" = CURRENT_TIMESTAMP
WHERE  status = 'A' 
  AND  "messageId" IN (370648716,370648741,370648745);

BEGIN;

UPDATE "Message" SET status = 'D', "lastModified" = CURRENT_TIMESTAMP
WHERE  status = 'A' 
  AND  "messageId" IN (370648715,370648738,370648737);

BEGIN;

UPDATE "Message" SET status = 'D', "lastModified" = CURRENT_TIMESTAMP
WHERE  status = 'A' 
  AND  "messageId" IN (370648709,370648729,370648733);

BEGIN;

UPDATE "Message" SET status = 'D', "lastModified" = CURRENT_TIMESTAMP
WHERE  status = 'A' 
  AND  "messageId" IN (370648719,370648712,370648722);

BEGIN;

UPDATE "Message" SET status = 'D', "lastModified" = CURRENT_TIMESTAMP
WHERE  status = 'A' 
  AND  "messageId" IN (370648718,370648743,370648732,370648720,370648727);
UPDATE 3

BEGIN;

UPDATE "Message" SET status = 'D', "lastModified" = CURRENT_TIMESTAMP
WHERE  status = 'A' 
  AND  "messageId" IN (370648726,370648721,370648742);

BEGIN;

UPDATE "Message" SET status = 'D', "lastModified" = CURRENT_TIMESTAMP
WHERE  status = 'A' 
  AND  "messageId" IN (370648735);
-- ====================================================================================================================

\echo `date`
\set release_type partial
\o /tmp/2017-02-23ccap-corp-tax-warrant.out.sql
\i ~/work/qry-input/ccap-corp-taxwarrant-rel.sql

\set release_type full
\i ~/work/qry-input/ccap-corp-taxwarrant-rel.sql

\set release_type withdrawal
\i ~/work/qry-input/ccap-corp-taxwarrant-rel.sql
\o


BEGIN;

UPDATE "Message" SET status = 'D', "lastModified" = CURRENT_TIMESTAMP
WHERE  status = 'A' 
  AND  "messageId" IN (370755359,370755360,370755362,370755364,370755367,370755368,370755370,370755371,370755372,370755373,370755375,370755376,370755377,370755378,370755382,370755383,370755385,370755387,370755391,370755392);

UPDATE 20
step=> COMMIT;
COMMIT
step=> \echo `date`
Thu Feb 23 08:00:20 CST 2017
step=> 

 messageId | _clntMsgId |           destQueue            | _st |               _created                |             _lastModified             | _cN | _relType | _dorWrrntNo |   _caseNo    |  _relDate  |    _namePartial    | _ssnPartial |                                                               url                                                               
-----------+------------+--------------------------------+-----+---------------------------------------+---------------------------------------+-----+----------+-------------+--------------+------------+--------------------+-------------+---------------------------------------------------------------------------------------------------------------------------------
 370648743 | 140337     | CCAPCorp-TaxWarrantRelease-f11 | A   | Tue, Feb 21, 2017 10:38:42.227 PM CST | Tue, Feb 21, 2017 10:38:42.227 PM CST |  11 | partial  | 11-00005338 |              | 02-21-2017 | FRANCIS R KIEFER   | 388-40-7713 | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f11&messageId=370648743
 370755392 | 1668343    | CCAPCorp-TaxWarrantRelease-f11 | A   | Wed, Feb 22, 2017 09:46:49.806 PM CST | Wed, Feb 22, 2017 09:46:49.806 PM CST |  11 | partial  | 11-00005338 |              | 02-22-2017 | FRANCIS R KIEFER   | 388-40-7713 | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f11&messageId=370755392

 370648720 | 1092772    | CCAPCorp-TaxWarrantRelease-f67 | A   | Tue, Feb 21, 2017 10:38:41.600 PM CST | Tue, Feb 21, 2017 10:38:41.600 PM CST |  67 | partial  | 67-00225451 | 01TW002107   | 02-21-2017 | VIRGINIA CAMERON   | 396-24-4923 | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f67&messageId=370648720

SELECT "messageId", status, created, "lastModified" FROM "Message" WHERE "messageId" IN (370648743,370755392,370648720) ORDER BY "messageId";

\echo `date`
BEGIN;
UPDATE "Message" SET status = 'A', "lastModified" = CURRENT_TIMESTAMP
WHERE  status = 'D' 
  AND  "messageId" IN (370755392);




