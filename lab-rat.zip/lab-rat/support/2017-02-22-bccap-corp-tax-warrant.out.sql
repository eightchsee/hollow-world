starting at:  Wed Feb 22 08:34:18 CST 2017

 messageId | _clntMsgId |           destQueue            | _st |               _created                |             _lastModified             | _cN | _relType | _dorWrrntNo |   _caseNo    |  _relDate  |    _namePartial    | _ssnPartial |                                                               url                                                               
-----------+------------+--------------------------------+-----+---------------------------------------+---------------------------------------+-----+----------+-------------+--------------+------------+--------------------+-------------+---------------------------------------------------------------------------------------------------------------------------------
 370648709 | 1078914    | CCAPCorp-TaxWarrantRelease-f18 | A   | Tue, Feb 21, 2017 10:38:41.377 PM CST | Tue, Feb 21, 2017 10:38:41.377 PM CST |  18 | partial  | 18-00164484 | 02TW000087   | 02-21-2017 | ERNEST N WACKWITZ  | 391-42-8463 | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f18&messageId=370648709
 370648712 | 1096676    | CCAPCorp-TaxWarrantRelease-f67 | A   | Tue, Feb 21, 2017 10:38:41.437 PM CST | Tue, Feb 21, 2017 10:38:41.437 PM CST |  67 | partial  | 67-00235691 | 2006TW001078 | 02-21-2017 | LISA TEAYS         | 398-78-5388 | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f67&messageId=370648712
 370648715 | 1080983    | CCAPCorp-TaxWarrantRelease-f10 | A   | Tue, Feb 21, 2017 10:38:41.498 PM CST | Tue, Feb 21, 2017 10:38:41.498 PM CST |  10 | partial  | 10-00154058 | 2006TW000012 | 02-21-2017 | EMIL UNTIEDT JR    | 396-38-2074 | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f10&messageId=370648715
 370648716 | 1086735    | CCAPCorp-TaxWarrantRelease-f51 | A   | Tue, Feb 21, 2017 10:38:41.519 PM CST | Tue, Feb 21, 2017 10:38:41.519 PM CST |  51 | partial  | 51-00192768 | 01TW001026   | 02-21-2017 | FLOYD HOPKINS      | 587-32-6560 | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f51&messageId=370648716
 370648718 | 1704154    | CCAPCorp-TaxWarrantRelease-f51 | A   | Tue, Feb 21, 2017 10:38:41.557 PM CST | Tue, Feb 21, 2017 10:38:41.557 PM CST |  51 | partial  | 51-00193427 | 02TW000075   | 02-21-2017 | ROBERT R KLINGBEIL | 387-52-2963 | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f51&messageId=370648718
 370648719 | 1090811    | CCAPCorp-TaxWarrantRelease-f42 | A   | Tue, Feb 21, 2017 10:38:41.580 PM CST | Tue, Feb 21, 2017 10:38:41.580 PM CST |  42 | partial  | 42-11828763 | 2010TW000013 | 02-21-2017 | RITA WOOD          | 387-50-1026 | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f42&messageId=370648719
 370648720 | 1092772    | CCAPCorp-TaxWarrantRelease-f67 | A   | Tue, Feb 21, 2017 10:38:41.600 PM CST | Tue, Feb 21, 2017 10:38:41.600 PM CST |  67 | partial  | 67-00225451 | 01TW002107   | 02-21-2017 | VIRGINIA CAMERON   | 396-24-4923 | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f67&messageId=370648720
 370648721 | 1704155    | CCAPCorp-TaxWarrantRelease-f51 | A   | Tue, Feb 21, 2017 10:38:41.619 PM CST | Tue, Feb 21, 2017 10:38:41.619 PM CST |  51 | partial  | 51-00196138 | 2004TW000846 | 02-21-2017 | SCOTT KIPP         | 391-50-4783 | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f51&messageId=370648721
 370648722 | 1090812    | CCAPCorp-TaxWarrantRelease-f05 | A   | Tue, Feb 21, 2017 10:38:41.638 PM CST | Tue, Feb 21, 2017 10:38:41.638 PM CST |   5 | partial  | 05-11999178 | 2010TW000121 | 02-21-2017 | RITA K LINDE       | 473-68-9125 | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f05&messageId=370648722
 370648726 | 1084810    | CCAPCorp-TaxWarrantRelease-f05 | A   | Tue, Feb 21, 2017 10:38:41.877 PM CST | Tue, Feb 21, 2017 10:38:41.877 PM CST |   5 | partial  | 05-11971256 | 2010TW000122 | 02-21-2017 | RITA K LINDE       | 473-68-9125 | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f05&messageId=370648726
 370648727 | 1092773    | CCAPCorp-TaxWarrantRelease-f67 | A   | Tue, Feb 21, 2017 10:38:41.901 PM CST | Tue, Feb 21, 2017 10:38:41.901 PM CST |  67 | partial  | 67-00234349 | 2005TW001435 | 02-21-2017 | ISABEL L TERLINDEN | 387-48-9396 | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f67&messageId=370648727
 370648729 | 1562739    | CCAPCorp-TaxWarrantRelease-f40 | A   | Tue, Feb 21, 2017 10:38:41.940 PM CST | Tue, Feb 21, 2017 10:38:41.940 PM CST |  40 | partial  | 40-00455454 | 2003TW001761 | 02-21-2017 | SAMUEL JACKSON     | 433-76-9011 | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f40&messageId=370648729
 370648732 | 124256     | CCAPCorp-TaxWarrantRelease-f40 | A   | Tue, Feb 21, 2017 10:38:41.999 PM CST | Tue, Feb 21, 2017 10:38:41.999 PM CST |  40 | partial  | 40-00462701 | 2004TW005488 | 02-21-2017 | SHERLENE K BOSSE   | 394-30-2537 | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f40&messageId=370648732
 370648733 | 1086736    | CCAPCorp-TaxWarrantRelease-f53 | A   | Tue, Feb 21, 2017 10:38:42.023 PM CST | Tue, Feb 21, 2017 10:38:42.023 PM CST |  53 | partial  | 53-00182276 | 2006TW000247 | 02-21-2017 | SHIRLEY BUTT       | 388-50-8219 | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f53&messageId=370648733
 370648735 | 1672235    | CCAPCorp-TaxWarrantRelease-f51 | A   | Tue, Feb 21, 2017 10:38:42.063 PM CST | Tue, Feb 21, 2017 10:38:42.063 PM CST |  51 | partial  | 51-00191336 | 00TW001180   | 02-21-2017 | ROBERT R KLINGBEIL | 387-52-2963 | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f51&messageId=370648735
 370648737 | 1624630    | CCAPCorp-TaxWarrantRelease-f11 | A   | Tue, Feb 21, 2017 10:38:42.101 PM CST | Tue, Feb 21, 2017 10:38:42.101 PM CST |  11 | partial  | 11-00159228 | 99TW000454   | 02-21-2017 | FRANCIS R KIEFER   | 388-40-7713 | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f11&messageId=370648737
 370648738 | 1672236    | CCAPCorp-TaxWarrantRelease-f13 | A   | Tue, Feb 21, 2017 10:38:42.125 PM CST | Tue, Feb 21, 2017 10:38:42.125 PM CST |  13 | partial  | 13-00238047 | 2004TW000447 | 02-21-2017 | SHAWN ROBINSON     | 396-74-2812 | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f13&messageId=370648738
 370648741 | 1078915    | CCAPCorp-TaxWarrantRelease-f09 | A   | Tue, Feb 21, 2017 10:38:42.188 PM CST | Tue, Feb 21, 2017 10:38:42.188 PM CST |   9 | partial  | 09-00157850 | 01TW000144   | 02-21-2017 | WILLIAM WALMSLEY   | 369-64-1571 | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f09&messageId=370648741
 370648742 | 140336     | CCAPCorp-TaxWarrantRelease-f40 | A   | Tue, Feb 21, 2017 10:38:42.208 PM CST | Tue, Feb 21, 2017 10:38:42.208 PM CST |  40 | partial  | 40-00462702 | 2004TW005489 | 02-21-2017 | SHERLENE K BOSSE   | 394-30-2537 | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f40&messageId=370648742
 370648743 | 140337     | CCAPCorp-TaxWarrantRelease-f11 | A   | Tue, Feb 21, 2017 10:38:42.227 PM CST | Tue, Feb 21, 2017 10:38:42.227 PM CST |  11 | partial  | 11-00005338 |              | 02-21-2017 | FRANCIS R KIEFER   | 388-40-7713 | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f11&messageId=370648743
 370648745 | 1090813    | CCAPCorp-TaxWarrantRelease-f15 | A   | Tue, Feb 21, 2017 10:38:42.265 PM CST | Tue, Feb 21, 2017 10:38:42.265 PM CST |  15 | partial  | 15-00155756 | 01TW000018   | 02-21-2017 | LINDA LEROY        | 330-48-8680 | https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=CCAPCorp-TaxWarrantRelease-f15&messageId=370648745
(21 rows)

finishing at: Wed Feb 22 08:34:18 CST 2017

starting at:  Wed Feb 22 08:34:36 CST 2017

 messageId | _clntMsgId | destQueue | _st | _created | _lastModified | _cN | _relType | _dorWrrntNo | _caseNo | _relDate | _namePartial | _ssnPartial | url 
-----------+------------+-----------+-----+----------+---------------+-----+----------+-------------+---------+----------+--------------+-------------+-----
(0 rows)

finishing at: Wed Feb 22 08:34:37 CST 2017

starting at:  Wed Feb 22 08:34:48 CST 2017

 messageId | _clntMsgId | destQueue | _st | _created | _lastModified | _cN | _relType | _dorWrrntNo | _caseNo | _relDate | _namePartial | _ssnPartial | url 
-----------+------------+-----------+-----+----------+---------------+-----+----------+-------------+---------+----------+--------------+-------------+-----
(0 rows)

finishing at: Wed Feb 22 08:34:49 CST 2017

starting at:  Wed Feb 22 08:38:29 CST 2017

BEGIN
UPDATE 21
ROLLBACK
BEGIN
UPDATE 21
COMMIT
COMMIT
finishing at: Wed Feb 22 08:39:51 CST 2017

