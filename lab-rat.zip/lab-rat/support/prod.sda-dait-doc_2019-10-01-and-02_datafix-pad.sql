-- Tue 01 Oct 2019 04:17:14 PM CDT 
SELECT "messageId", "clientMessageId" AS "_clntMsgId", "destQueue", "status" AS "_st",to_char(created, 'Dy, Mon DD, YYYY HH12:MI:SS AM TZ') AS "_created", to_char("lastModified", 'Dy, Mon DD, YYYY HH12:MI:SS AM TZ') AS "_lastModified",
       "formatXMLString"('notes/text()',  replace(SUBSTRING(body::text FROM 1 FOR (position('<data>'     IN body::text)-1)) || SUBSTRING(body::text FROM position('</attachment>' IN body::text)),'\012','')::xml) AS "_notes",
       replace("formatXMLString"('attachment/attachmentDescription/text()',  replace(SUBSTRING(body::text FROM 1 FOR (position('<data>'     IN body::text)-1)) || SUBSTRING(body::text FROM position('</attachment>' IN body::text)),'\012','')::xml),'''','''''') AS "_attachDescr"
FROM   "Message" AS m JOIN "Body" AS b ON (b."bodySeqNo" = m."bodySeqNo")
WHERE  "destQueue" ~ 'CCAP-DADocument'
  AND  "created"  >= CURRENT_TIMESTAMP - INTERVAL :'period'
  AND  status IN ( :status )
  AND  "formatXMLString"('countyNumber/text()', replace(SUBSTRING(body::text FROM 1 FOR (position('<data>' IN body::text)-1)) || SUBSTRING(body::text FROM position('</attachment>' IN body::text)),'\012','')::xml)::int IN ( :county_no )
ORDER BY "created";

 messageId | _clntMsgId |    destQueue    | _st |             _created              |           _lastModified           | _bodySz | _cn |   _caseNo    |  _daCaseNo   |          _fullName           |    _dob    |                                             _attachDescr                                              |  _docSize  
-----------+------------+-----------------+-----+-----------------------------------+-----------------------------------+---------+-----+--------------+--------------+------------------------------+------------+-------------------------------------------------------------------------------------------------------+------------
 491860140 | 1150131810 | CCAP-DADocument | A   | Tue, Oct 01, 2019 03:15:30 PM CDT | Tue, Oct 01, 2019 03:15:30 PM CDT | 232 kB  |  44 | 2019CM000333 | 2018OU001041 | David J. Mancl               | 01-22-1952 | Jury Instructions_1 - Mancl, David J.pdf                                                              | 173 kB
 491860141 | 1150131811 | CCAP-DADocument | A   | Tue, Oct 01, 2019 03:15:31 PM CDT | Tue, Oct 01, 2019 03:15:31 PM CDT | 39 kB   |  44 | 2019CM000333 | 2018OU001041 | David J. Mancl               | 01-22-1952 | Jury Instruction \302\24729.055.pdf                                                                   | 29 kB
 491860143 | 1150131812 | CCAP-DADocument | A   | Tue, Oct 01, 2019 03:15:31 PM CDT | Tue, Oct 01, 2019 03:15:31 PM CDT | 50 kB   |  44 | 2019CM000333 | 2018OU001041 | David J. Mancl               | 01-22-1952 | Jury Instruction \302\24729.40(2).pdf                                                                 | 37 kB

\set mid 491860140,491860141,491860143


\t

-- this SELECT demo the replace, before the UPDATE statements

SELECT :mid AS msg_id, "bodySeqNo", replace(body::text, :'text_from', :'text_to_test')::"BodyT"
FROM   "Body"
WHERE  "bodySeqNo" = (SELECT "bodySeqNo" FROM "Message" WHERE "messageId" = :mid);

BEGIN;
UPDATE "Body" SET body = replace(body::text, :'text_from', :'text_to')::"BodyT"
WHERE  "bodySeqNo" = ( SELECT "bodySeqNo"
                       FROM   "Message"
                       WHERE  "messageId" = :mid );

UPDATE "Message" SET "lastModified" = CURRENT_TIMESTAMP WHERE "messageId" = :mid;

SELECT "messageId", "formatXMLString"('isCourtAppointed', replace(body::text, '\012','')::xml) AS "is_crt_apptd" FROM "Message" AS m JOIN "Body" b ON (b."bodySeqNo" = m."bodySeqNo") WHERE "messageId" = :mid;
SELECT "messageId", "lastModified", "formatXMLString"('isCourtAppointed', replace(body::text, '\012','')::xml) AS "is_crt_apptd" FROM "Message" AS m JOIN "Body" b ON (b."bodySeqNo" = m."bodySeqNo") WHERE "messageId" = :mid;

-- COMMIT;

<notes>Attaching Jury Instruction \302\24729.055 and \302\24729.40(2)</notes>
<notes>Attaching Jury Instruction Sec.29.055 and Sec.29.40(2)</notes>

SELECT :mid1 AS msg_id, "bodySeqNo", replace(body::text, '<notes>Attaching Jury Instruction \302\24729.055 and \302\24729.40(2)</notes>', '<notes>Attaching Jury Instruction Sec.29.055 and Sec.29.40(2)</notes>')::"BodyT"
FROM   "Body" WHERE "bodySeqNo" = (SELECT "bodySeqNo" FROM "Message" WHERE "messageId" = :mid);


BEGIN;
UPDATE "Body" SET body = replace(body::text, '<notes>Attaching Jury Instruction \302\24729.055 and \302\24729.40(2)</notes>', '<notes>Attaching Jury Instruction Sec.29.055 and Sec.29.40(2)</notes>')::"BodyT"
WHERE  "bodySeqNo" = ( SELECT "bodySeqNo"
                       FROM   "Message"
                       WHERE  "messageId" = :mid1 );

UPDATE "Message" SET "lastModified" = CURRENT_TIMESTAMP WHERE "messageId" = :mid1;
UPDATE "Message" SET status = :status_active, "lastModified" = CURRENT_TIMESTAMP WHERE "messageId" = :mid1 AND status = :status_delete;

<attachmentDescription>Jury Instruction \302\24729.055.pdf</attachmentDescription>
<attachmentDescription>Jury Instruction Sec.29.055.pdf</attachmentDescription>

SELECT :mid2 AS msg_id, "bodySeqNo", replace(body::text, '<attachmentDescription>Jury Instruction \302\24729.055.pdf</attachmentDescription>', '<attachmentDescription>Jury Instruction Sec.29.055.pdf</attachmentDescription>')::"BodyT"
FROM   "Body" WHERE "bodySeqNo" = (SELECT "bodySeqNo" FROM "Message" WHERE "messageId" = :mid2);

BEGIN;
UPDATE "Body" SET body = replace(body::text, '<attachmentDescription>Jury Instruction \302\24729.055.pdf</attachmentDescription>', '<attachmentDescription>Jury Instruction Sec.29.055.pdf</attachmentDescription>')::"BodyT"
WHERE  "bodySeqNo" = ( SELECT "bodySeqNo"
                       FROM   "Message"
                       WHERE  "messageId" = :mid2 );

UPDATE "Message" SET status = :status_active, "lastModified" = CURRENT_TIMESTAMP WHERE "messageId" = :mid2 AND status = :status_delete;

-- =================================================================================================
-- Wed 02 Oct 2019 07:56:26 AM CDT 

\t
SELECT :mid2 AS msg_id, "bodySeqNo", replace(body::text, '<attachmentDescription>Jury Instruction \302\24729.055.pdf</attachmentDescription>', '<attachmentDescription>Jury Instruction Sec.29.055.pdf</attachmentDescription>')::"BodyT"
FROM   "Body" WHERE "bodySeqNo" = (SELECT "bodySeqNo" FROM "Message" WHERE "messageId" = :mid2);

SELECT SUBSTRING(body::text FROM position('<attachmentD' IN body::text) FOR 100) AS snip FROM "Body" WHERE "bodySeqNo" = (SELECT "bodySeqNo" FROM "Message" WHERE "messageId" = :mid2);

SELECT * FROM "Message" WHERE "messageId" = :mid2;
BEGIN;
UPDATE "Body" SET body = replace(body::text, '<attachmentDescription>Jury Instruction \302\24729.055.pdf</attachmentDescription>', '<attachmentDescription>Jury Instruction Sec.29.055.pdf</attachmentDescription>')::"BodyT"
WHERE  "bodySeqNo" = ( SELECT "bodySeqNo"
                       FROM   "Message"
                       WHERE  "messageId" = :mid2 );

UPDATE "Message" SET status = :status_active, "lastModified" = CURRENT_TIMESTAMP WHERE "messageId" = :mid2 AND status = :status_delete;

SELECT SUBSTRING(body::text FROM position('<attachmentD' IN body::text) FOR 100) AS snip FROM "Body" WHERE "bodySeqNo" = (SELECT "bodySeqNo" FROM "Message" WHERE "messageId" = :mid2);
SELECT * FROM "Message" WHERE "messageId" = :mid2;




SELECT "messageId", "formatXMLString"('daCaseNumber/text()', replace(SUBSTRING(body::text FROM 1 FOR (position('<data>' IN body::text)-1)) || SUBSTRING(body::text FROM position('</attachment>' IN body::text)),'\012','')::xml) AS "_daCaseNo"
FROM   "Message" AS m JOIN "Body" AS b ON (b."bodySeqNo" = m."bodySeqNo") WHERE "messageId" IN ( 491860140,491860141,491860143 );

'1150131739','1150131740','1150131741','1150131810','1150131811','1150131812'

-- ==== Wed 02 Oct 2019 09:16:06 AM CDT ==== --
SELECT "messageId", "clientMessageId" AS "_clntMsgId", "destQueue", "status" AS "_st",to_char(created, 'Dy, Mon DD, YYYY HH12:MI:SS AM TZ') AS "_created", to_char("lastModified", 'Dy, Mon DD, YYYY HH12:MI:SS AM TZ') AS "_lastModified",
       "formatXMLString"('notes/text()',  replace(SUBSTRING(body::text FROM 1 FOR (position('<data>' IN body::text)-1)) || SUBSTRING(body::text FROM position('</attachment>' IN body::text)),'\012','')::xml) AS "_notes",
       replace("formatXMLString"('attachment/attachmentDescription/text()',  replace(SUBSTRING(body::text FROM 1 FOR (position('<data>' IN body::text)-1)) || SUBSTRING(body::text FROM position('</attachment>' IN body::text)),'\012','')::xml),'''','''''') AS "_attachDescr"
FROM   "Message" AS m JOIN "Body" AS b ON (b."bodySeqNo" = m."bodySeqNo")
WHERE  "destQueue" ~ 'CCAP-DADocument' AND "messageId" IN ( 491860140,491860141,491860143 );


SELECT :mid3 AS msg_id, SUBSTRING(body::text FROM position('<attachmentD' IN body::text) FOR 100) AS snip FROM "Body" WHERE "bodySeqNo" = (SELECT "bodySeqNo" FROM "Message" WHERE "messageId" = :mid3);
\t
SELECT :mid3 AS msg_id, "bodySeqNo", replace(body::text, '<attachmentDescription>Jury Instruction \302\24729.40(2).pdf</attachmentDescription>', '<attachmentDescription>Jury Instruction Sec.29.40(2).pdf</attachmentDescription>')::"BodyT"
FROM   "Body" WHERE "bodySeqNo" = (SELECT "bodySeqNo" FROM "Message" WHERE "messageId" = :mid3);
\t
SELECT :mid3 AS msg_id, SUBSTRING(body::text FROM position('<attachmentD' IN body::text) FOR 100) AS snip FROM "Body" WHERE "bodySeqNo" = (SELECT "bodySeqNo" FROM "Message" WHERE "messageId" = :mid3);

SELECT * FROM "Message" WHERE "messageId" = :mid3;
BEGIN;
UPDATE "Body" SET body = replace(body::text, '<attachmentDescription>Jury Instruction \302\24729.40(2).pdf</attachmentDescription>', '<attachmentDescription>Jury Instruction Sec.29.40(2).pdf</attachmentDescription>')::"BodyT"
WHERE  "bodySeqNo" = ( SELECT "bodySeqNo"
                       FROM   "Message"
                       WHERE  "messageId" = :mid3 );

UPDATE "Message" SET status = :status_active, "lastModified" = CURRENT_TIMESTAMP WHERE "messageId" = :mid3 AND status = :status_delete;

SELECT :mid3 AS msg_id, SUBSTRING(body::text FROM position('<attachmentD' IN body::text) FOR 100) AS snip FROM "Body" WHERE "bodySeqNo" = (SELECT "bodySeqNo" FROM "Message" WHERE "messageId" = :mid3);
SELECT * FROM "Message" WHERE "messageId" = :mid3;





