-- Fri 20 Sep 2019 09:56:13 AM CDT 

\set mid 490958532

\t
\set text_from '''<attachmentDescription>Motion to Admit Audiovisual Recording of AMH, a Child Pursuant to \302\247908.08(7) and  \302\247908.03(24).pdf</attachmentDescription>'''
\set text_to_test '''<attachmentDescription>MOTION TO ADMIT AUDIOVISUAL Recording of AMH, a Child Pursuant to &#167;908.08(7) and  &#167;908.03(24).pdf</attachmentDescription>'''
\set text_to '''<attachmentDescription>Motion to Admit Audiovisual Recording of AMH, a Child Pursuant to &#167;908.08(7) and  &#167;908.03(24).pdf</attachmentDescription>'''

SELECT :mid AS msg_id, "bodySeqNo", replace(body::text, :text_from, :text_to_test)::"BodyT"
FROM   "Body"
WHERE  "bodySeqNo" = (SELECT "bodySeqNo" FROM "Message" WHERE "messageId" = :mid);

BEGIN;
UPDATE "Body" SET body = replace(body::text, :text_from, :text_to)::"BodyT"
WHERE  "bodySeqNo" = ( SELECT "bodySeqNo"
                       FROM   "Message"
                       WHERE  "messageId" = :mid );

UPDATE "Message" SET "lastModified" = CURRENT_TIMESTAMP WHERE "messageId" = :mid;



SELECT :mid AS msg_id, "bodySeqNo", substring(body::text FROM 495 FOR 350) AS msg_part
FROM   "Body"
WHERE  "bodySeqNo" = (SELECT "bodySeqNo" FROM "Message" WHERE "messageId" = :mid);
  msg_id   | bodySeqNo |                                                                                                                                                                            msg_part                                                                                                                                                                            
-----------+-----------+----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 490958532 | 478454902 | <notes></notes><attachment><attachmentDescription>Motion to Admit Audiovisual Recording of AMH, a Child Pursuant to \302\247908.08(7) and  \302\247908.03(24).pdf</attachmentDescription><contentType>application/pdf</contentType><confidential>N</confidential><tempSeal>N</tempSeal><docSize>181562</docSize><data>JVBERi0xLjUNCiW1tbW1DQoxIDAgb2JqDQo8PC9U
(1 row)

SELECT :mid AS msg_id, "bodySeqNo", replace(body::text, '<attachmentDescription>Motion to Admit Audiovisual Recording of AMH, a Child Pursuant to \302\247908.08(7) and  \302\247908.03(24).pdf</attachmentDescription>','<attachmentDescription>MOTION TO ADMIT AUDIOVISUAL Recording of AMH, a Child Pursuant to &#167;908.08(7) and  &#167;908.03(24).pdf</attachmentDescription>')::"BodyT"
FROM   "Body"
WHERE  "bodySeqNo" = (SELECT "bodySeqNo" FROM "Message" WHERE "messageId" = :mid);

UPDATE "Body" SET body = replace(body::text, '<attachmentDescription>Motion to Admit Audiovisual Recording of AMH, a Child Pursuant to \302\247908.08(7) and  \302\247908.03(24).pdf</attachmentDescription>','<attachmentDescription>Motion to Admit Audiovisual Recording of AMH, a Child Pursuant to &#167;908.08(7) and  &#167;908.03(24).pdf</attachmentDescription>')::"BodyT"
WHERE  "bodySeqNo" = ( SELECT "bodySeqNo"
                       FROM   "Message"
                       WHERE  "messageId" = :mid );


UPDATE "Message" SET status = :status_active, "lastModified" = CURRENT_TIMESTAMP WHERE "messageId" = :mid AND status = :status_delete;


SELECT :mid AS msg_id, "bodySeqNo", replace(body::text,'<attachmentDescription>Motion to Admit Audiovisual Recording of AMH, a Child Pursuant to &#167;908.08(7) and  &#167;908.03(24).pdf</attachmentDescription>', '<attachmentDescription>MOTION TO ADMIT AUDIOVISUAL Recording of AMH, a Child Pursuant to Sec.908.08(7) and  Sec.908.03(24).pdf</attachmentDescription>')::"BodyT"
FROM   "Body"
WHERE  "bodySeqNo" = (SELECT "bodySeqNo" FROM "Message" WHERE "messageId" = :mid);

BEGIN;
UPDATE "Body" SET body = replace(body::text,'<attachmentDescription>Motion to Admit Audiovisual Recording of AMH, a Child Pursuant to &#167;908.08(7) and  &#167;908.03(24).pdf</attachmentDescription>', '<attachmentDescription>Motion to Admit Audiovisual Recording of AMH, a Child Pursuant to Sec.908.08(7) and  Sec.908.03(24).pdf</attachmentDescription>')::"BodyT"
WHERE  "bodySeqNo" = ( SELECT "bodySeqNo"
                       FROM   "Message"
                       WHERE  "messageId" = :mid );

UPDATE "Message" SET status = :status_active, "lastModified" = CURRENT_TIMESTAMP WHERE "messageId" = :mid AND status = :status_delete;






