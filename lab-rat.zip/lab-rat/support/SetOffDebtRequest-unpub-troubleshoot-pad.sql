-- Thu 06 Jun 2019 07:39:50 AM CDT 
-- see: https://exchange.wicourts.gov/owa/?ver=15.1.1713.1&cver=15.1.1531.3&vC=0&forceBO=false#path=/mail/inbox
-- Unpublished StepExport Report for 06-06-2019

-- run on county
\set iface DOR \set mtype SetOffDebtRequest \set seq_no_start 2175210 \set seq_no_end 2181178
SELECT *
FROM   "StepExport"
WHERE  "interfaceName" = :'iface'
  AND  "messageType"   = :'mtype'
  AND  "seqNo"         BETWEEN :seq_no_start AND :seq_no_end;


-- see: http://wikiccap-prod/mediawiki/index.php5/Tax_Intercept#Unpublished_StepExport_Report

SELECT "interfaceName",
       "messageType",
       "timeInserted",
       "timeModified",
       "status",
       "seqNo",
       "key1",
       "value1",
       "key2",
       "value2",
       "Trip"."debtNo"
FROM   "StepExport",
       "Trip"
WHERE  "StepExport"."interfaceName" = :'iface'
  AND  "StepExport"."status" = 'N'
  AND  "StepExport"."value1" = 'U'
  AND  "StepExport"."value2"::INTEGER = "Trip"."tripSeqNo"
  AND  "Trip"."debtNo" IS NULL
ORDER BY "seqNo";

\set iface DOR \set mtype SetOffDebtRequest
--run on CIR database
SELECT "countyNo", count(*), "timeInserted"::DATE
FROM  "StepExport"
WHERE "interfaceName" = :'iface'
  AND "messageType"   = :'mtype'
  AND "timeInserted"  BETWEEN CURRENT_DATE - INTERVAL '6 days' AND CURRENT_DATE
  AND "countyNo"      BETWEEN 51 AND 60
GROUP BY "countyNo", "timeInserted"::DATE
ORDER BY "countyNo", "timeInserted"::DATE;


