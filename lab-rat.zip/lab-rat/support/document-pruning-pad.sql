-- Mon 10 Dec 2018 11:53:42 AM CST 
us.wi.state.courts.ccap.intclients.v70.da.NewDAPubClient
refers to:
us.wi.state.courts.ccap.intclients.v70.da.NewDADocumentBuilder
in which:
addDocumentTableData(HashMap<String, Object>, Element)
which can call:
CaseDocImageDAWithSizeSQ - countyNo, caseNo, docId

That query could reasonably select from "StepEFileDocument" and so the following query could identify records that need to be preserved (for a time), as follows:
SELECT status, count(*)
FROM   "StepEFileDocument"
WHERE  "docId" IN (SELECT value4::int FROM "StepExport" WHERE "interfaceName" = 'DA' AND "messageType" = 'DACourtDocument' AND status = 'N')
GROUP BY status;

SELECT count(*) FROM "StepAgencyExpDOC" WHERE "docId" = :doc_id;
SELECT count(*) FROM "StepAgencyExpDOCAttach" WHERE "docId" = :doc_id;
SELECT count(*) FROM "StepChildWelDoc" WHERE "docId" = :doc_id;
SELECT count(*) FROM "StepDocument" WHERE "docId" = :doc_id;
SELECT count(*) FROM "StepEFileDocument"  WHERE "docId" = :doc_id;

SELECT "countyNo","docId","sectionNo","certifyStatus","certifiedTimestamp","docText","DocImage"."docImageMd5Hash" -- , "docImage"
FROM   "DocImage" WHERE "docId" = :doc_id;

    caseNo    | histSeqNo |  docId  | sectionNo | countyNo | dateLastAccessed | filedReceived | imageSize | isConfidential | isDuplex | orientation | paperSize | insertedBy | insertedDate |      docName       |                 docHash                  | isEFiling | isHidden | newDocId | eFilingFiledDate | eFilingRcvdDate | pages | docSource | formNumber | isSealed | eAccountNo | judgeNotes | messageSeqNo | filedByPartyNo | filedByAttyNo | accessCode | indexDocNo | docNumber 
--------------+-----------+---------+-----------+----------+------------------+---------------+-----------+----------------+----------+-------------+-----------+------------+--------------+--------------------+------------------------------------------+-----------+----------+----------+------------------+-----------------+-------+-----------+------------+----------+------------+------------+--------------+----------------+---------------+------------+------------+-----------
 2014CF002442 |         1 | 1975388 |         1 |       40 | 2018-07-20       | F             |    135850 | f              | t        | P           | USLETTER  | SDESWYS    | 2014-06-12   | Criminal Complaint | 4c2edd97c754ad082232be55290fb9eee97fb58a | t         | f        |          |                  |                 | 1-2   | S         |            | f        |            |            |              |                |               | N          |            |         1
(1 row)

SELECT "interfaceName", count(*) FROM "StepExport" WHERE key1 ~* 'docId' OR key2 ~* 'docId' OR key3 ~* 'docId' OR key4 ~* 'docId' OR key5 ~* 'docId' OR key6 ~* 'docId' GROUP BY "interfaceName" ORDER BY "interfaceName";

SELECT "interfaceName", count(*) FROM "StepExport" WHERE key1 ~* 'docId' GROUP BY "interfaceName" ORDER BY "interfaceName";
SELECT "interfaceName", count(*) FROM "StepExport" WHERE key2 ~* 'docId' GROUP BY "interfaceName" ORDER BY "interfaceName";
SELECT "interfaceName", count(*) FROM "StepExport" WHERE key3 ~* 'docId' GROUP BY "interfaceName" ORDER BY "interfaceName";
SELECT "interfaceName", count(*) FROM "StepExport" WHERE key4 ~* 'docId' GROUP BY "interfaceName" ORDER BY "interfaceName";
SELECT "interfaceName", count(*) FROM "StepExport" WHERE key5 ~* 'docId' GROUP BY "interfaceName" ORDER BY "interfaceName";
SELECT "interfaceName", count(*) FROM "StepExport" WHERE key6 ~* 'docId' GROUP BY "interfaceName" ORDER BY "interfaceName";

