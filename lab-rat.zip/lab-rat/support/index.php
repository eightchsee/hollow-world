<?php
  $ext = ".sql"
?>
<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <meta http-equiv="refresh" content="3600">
    <title><?php echo strstr(__DIR__,'lab-rat/'); ?></title>
    <!-- script type="text/JavaScript" src="inc/rollovers.js"></script>
    <link href="inc/sitestyle.css" rel="stylesheet" type="text/css" -->
    <style type="text/css">
      /*body {margin: 0 10px; background-image: url(http://localhost/lab-rat/evtcal/cheeters/logo.jpg);}*/
      body {
        /* margin: 0 10px; */
        background-image: url(../images/logo.jpg);
        width: 75%;
        margin: auto;
        font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 10px;
        background-repeat: repeat-x;
        /* background-color: #0000FF; */
      }
      p.date-heading {
        border-bottom: thin dashed; /* #ffa; */
        font-style: italic;
        padding-bottom: 3px;
        margin: 10px auto;
        /*text-align: center;*/
        text-indent: 8px;
        color: #700;
      }
      h3 {margin: 0 auto; padding-left: 25px;}
      ul {margin: 5px auto auto auto;}
      ul.month-listing {/*border-top: thin dashed #ffa;*/ font-size: 10pt; list-style-type: circle;}
      ul.month-listing > li { margin-bottom: 7px;}
      ul.month-listing > li.last-one { margin-bottom: 0;}
      /* a, */ a:visited {color: #c0c0c0; /* #ffa; */}
      a:hover {background-color: #ff0; color: #f00;}

      ul.top-nav {
        width: <?php echo (0.7153 * 6) ?>in;
      }

      div.tom_descr {
        display: none;
        padding: 0 0 2px 3px;
        border: 1px solid #F00;
        min-height: 30px;
        min-width: 90px;
        /* margin-left: 50px; */
      }
      a:hover + div.tom_descr {
        display: block;
      }
    </style>

  </head>
  <body>
    <p class="date-heading"><?php echo date('l M jS, Y @ h:i:s a T')  ?>&nbsp;</p></td>
<?php
  $max_month = 6;
//  $month_labels = ["July","August","September","October"];

  // Opens the folder
  $i = 0;
  $folder = opendir(".");
  $entries = array();

  // Loop trough all files in the folder
  while ((false !== ($entry = readdir($folder)))) {
    if (!is_dir($entry)) {
      $entries[$i] = $entry;
      $i++;
    }
  }
  asort($entries);
  $i = 0;
?>
    <ul class="month-listing">
<?php
  $this_file = substr(strrchr(__FILE__, "\\"), 1);
  foreach($entries as $item) {
    if (strcmp($item, $this_file) != 0) {
//      if (strpos($item, $ext) > 0) {
?>
      <li><a href="<?php echo $item; ?>" target="_blank"><?php echo $item; ?></a></li>
<?php
    $i++;
//      }
    }
  }
  // Close folder
  $folder = closedir($folder);
//  echo '      <li><a href="' . $_SERVER['PHP_SELF'] . '">' . $_SERVER['SCRIPT_NAME'] . '</a></li>';
?>
    </ul>

  </body>
</html>
