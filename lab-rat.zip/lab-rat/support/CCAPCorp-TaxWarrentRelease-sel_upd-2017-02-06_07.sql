BEGIN;

SELECT m."messageId", m."clientMessageId" AS "_clntMsgId", m."destQueue", m."status" AS _st,
       to_char(m."created", 'Dy, Mon DD, YYYY HH12:MI:SS AM TZ') AS "_created",
       to_char(m."lastModified", 'Dy, Mon DD, YYYY HH12:MI:SS AM TZ') AS "_lastModified",
       "formatXMLString"('@countyNumber', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_cN",
       "formatXMLString"('@releaseType', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_relType",
       "formatXMLString"('dorWarrantNumber/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_dorWrrntNo",
       "formatXMLString"('caseNumber/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_caseNo",
       "formatXMLString"('releaseDate/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_relDate",
       "formatXMLString"('namePartial/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_namePartial"
FROM   "Message" AS m
  JOIN "Body"    AS b ON (b."bodySeqNo" = m."bodySeqNo")
WHERE  ("destQueue" ~ 'CCAPCorp-TaxWarrantRelease' AND "destQueue" ~ '-f')
  AND  status = 'A' AND "formatXMLString"('@releaseType', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) = 'partial'
ORDER BY created;

UPDATE "Message"
SET    "status" = 'D'
WHERE  "messageId" IN (369523829,369523830,369523831,369523834,369523864,369523870,369523885,369523886,369523901,369523928,369523933,369523961,369523977,369524001,369524013,369524043,369524049,369524078)
  AND  "status" = 'A';

SELECT m."messageId", m."clientMessageId" AS "_clntMsgId", m."destQueue", m."status" AS _st,
       to_char(m."created", 'Dy, Mon DD, YYYY HH12:MI:SS AM TZ') AS "_created",
       to_char(m."lastModified", 'Dy, Mon DD, YYYY HH12:MI:SS AM TZ') AS "_lastModified",
       "formatXMLString"('@countyNumber', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_cN",
       "formatXMLString"('@releaseType', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_relType",
       "formatXMLString"('dorWarrantNumber/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_dorWrrntNo",
       "formatXMLString"('caseNumber/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_caseNo",
       "formatXMLString"('releaseDate/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_relDate",
       "formatXMLString"('namePartial/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_namePartial"
FROM   "Message" AS m
  JOIN "Body"    AS b ON (b."bodySeqNo" = m."bodySeqNo")
WHERE  "messageId" IN (369523829,369523830,369523831,369523834,369523864,369523870,369523885,369523886,369523901,369523928,369523933,369523961,369523977,369524001,369524013,369524043,369524049,369524078);


