SELECT count(DISTINCT p."caseNo"), SUBSTRING(p."caseNo" FROM 1 FOR 4)::int AS "_yr"
FROM   "Party"     AS p
  JOIN "AttyParty" AS ap ON (ap."countyNo" = p."countyNo" AND ap."caseNo" = p."caseNo" AND ap."attySearchName" = p."attySearchName")
WHERE  p."isENotice" = false
  AND  p."attySearchName" IS NOT NULL
  AND  (ap."enteredDate" <= CURRENT_DATE AND (ap."withdrewDate" IS NOT NULL AND ap."withdrewDate" < CURRENT_DATE))
GROUP BY "_yr"
ORDER BY "_yr"
;

SELECT p."caseNo", p."partyNo", p."attySearchName", ap."attySearchName", ap."enteredDate", ap."withdrewDate"
FROM   "Party"     AS p
  JOIN "AttyParty" AS ap ON (ap."countyNo" = p."countyNo" AND ap."caseNo" = p."caseNo" AND ap."attySearchName" = p."attySearchName")
  JOIN "Case"      AS c ON (p."countyNo" = c."countyNo" AND p."caseNo" = c."caseNo" AND c."isElectronicFiling" = true)
WHERE  p."isENotice" = false
  AND  p."attySearchName" IS NOT NULL
  AND  (ap."enteredDate" <= CURRENT_DATE AND (ap."withdrewDate" IS NOT NULL AND ap."withdrewDate" < CURRENT_DATE))
  AND  SUBSTRING(p."caseNo" FROM 1 FOR 4)::int = 2016
ORDER BY p."caseNo";
    caseNo    
--------------
 2016CM000036
 2016CM000109
 2016CM000113
 2016CM000387
 2016CT000307
 2016CV000142
 2016FO000556
 2016PA000119
(8 rows)

SELECT p."caseNo", p."partyNo", p."attySearchName", ap."attySearchName", ap."enteredDate", ap."withdrewDate"
FROM   "Party"     AS p
  JOIN "AttyParty" AS ap ON (ap."countyNo" = p."countyNo" AND ap."caseNo" = p."caseNo" AND ap."attySearchName" = p."attySearchName")
  JOIN "Case"      AS c ON (p."countyNo" = c."countyNo" AND p."caseNo" = c."caseNo" AND c."isElectronicFiling" = true)
WHERE  p."isENotice" = false
  AND  p."attySearchName" IS NOT NULL
  AND  (ap."enteredDate" <= CURRENT_DATE AND (ap."withdrewDate" IS NOT NULL AND ap."withdrewDate" < CURRENT_DATE))
  AND  NOT EXISTS (
    SELECT 1
    FROM   "AttyParty" AS ap2
    WHERE  ap2."countyNo" = ap."countyNo"
      AND  ap2."caseNo"   = ap."caseNo"
      AND  (ap2."enteredDate" <= CURRENT_DATE AND (ap2."withdrewDate" IS NULL OR ap."withdrewDate" >= CURRENT_DATE))
  )
  AND  SUBSTRING(p."caseNo" FROM 1 FOR 4)::int = 2016
ORDER BY p."caseNo";

BEGIN;
UPDATE "Party" SET "attyNameF" = 'James', "attyNameM" = 'C.', "attyNameL" = 'Herrick', "attySuffix" = 'Jr.' WHERE "caseNo" = '2016CV000142' AND "partyNo" = 1 AND "countyNo" = 70;



\echo 'currently:'`date`
SELECT "caseNo","countyNo","partyNo","cpi","defendantId",to_char("dob", 'MM-DD-YYYY') AS "_dob","fingerPrintId","isInCustody"::VARCHAR(5) AS "_isInCstdy","isSentNotc"::VARCHAR(5) AS "_isSntNtc","Party"."fullNameFirstNameFirst" AS "_fullName","partyType" AS "_pTyp",
       "Party"."searchName","Party"."soundex","statusCode" AS "stCd","sex",'123-45-6789' AS "_ssn",'H98765432101234' AS "_operLicNo","isENotice"::VARCHAR(5) AS "_isENtc","Party"."attySearchName","Party"."attyFullNameFirstNameFirst" AS "_attyFullName"
FROM   "Party"
WHERE  "caseNo" = '2016CV000142' --  AND  "partyNo" = 2
ORDER BY "partyNo";
--     caseNo    | countyNo | partyNo | cpi | defendantId | _dob | fingerPrintId | _isInCstdy | _isSntNtc |                _fullName                | _pTyp |            searchName             | soundex | stCd | sex |    _ssn     |   _operLicNo    | _isENtc |   attySearchName   |    _attyFullName     
-- --------------+----------+---------+-----+-------------+------+---------------+------------+-----------+-----------------------------------------+-------+-----------------------------------+---------+------+-----+-------------+-----------------+---------+--------------------+----------------------
--  2016CV000142 |       70 |       1 |     |             |      |               | false      | false     | Maxwell Wisnefske                       | CH    | WISNEFSKE,MAXWELL                 | W251    | AC   |     | 123-45-6789 | H98765432101234 | false   |                    | 
--  2016CV000142 |       70 |       2 |     |             |      |               | false      | false     | Shannon Truttmann                       | PL    | TRUTTMANN,SHANNON                 | T635    | AC   |     | 123-45-6789 | H98765432101234 | false   | HERRICK,JAMESCJR   | James C. Herrick Jr.
--  2016CV000142 |       70 |       3 |     |             |      |               | false      | false     | Keith Wisnefske                         | PL    | WISNEFSKE,KEITH                   | W251    | AC   |     | 123-45-6789 | H98765432101234 | false   | HERRICK,JAMESCJR   | James C. Herrick Jr.
--  2016CV000142 |       70 |       4 |     |             |      |               | false      | false     | Blue Cross and Blue Shield of Minnesota | IP    | BLUECROSSANDBLUESHIELDOFMINNESOTA | B426    | AC   |     | 123-45-6789 | H98765432101234 | false   | MAYER,MATTHEWSHAWN | Matthew Shawn Mayer
--  2016CV000142 |       70 |       5 |     |             |      |               | false      | false     | Blue Cross and Blue Shield of Minnesota | IP    | BLUECROSSANDBLUESHIELDOFMINNESOTA | B426    | AC   |     | 123-45-6789 | H98765432101234 | false   | MAYER,MATTHEWSHAWN | Matthew Shawn Mayer
--  2016CV000142 |       70 |       6 |     |             |      |               | false      | false     | Judith S Papenfuss                      | DE    | PAPENFUSS,JUDITHS                 | P151    | AC   |     | 123-45-6789 | H98765432101234 | false   | EMER,MICHAELANDREW | Michael Andrew Emer
--  2016CV000142 |       70 |       7 |     |             |      |               | false      | false     | Safeco Insurance Company of America     | DE    | SAFECOINSURANCECOMPANYOFAMERICA   | S125    | AC   |     | 123-45-6789 | H98765432101234 | false   | EMER,MICHAELANDREW | Michael Andrew Emer
--  2016CV000142 |       70 |       8 |     |             |      |               | false      | false     | Safeco Insurance Company of America     | DE    | SAFECOINSURANCECOMPANYOFAMERICA   | S125    | AC   |     | 123-45-6789 | H98765432101234 | false   | EMER,MICHAELANDREW | Michael Andrew Emer
-- (8 rows)

-- \echo `date`
-- Wed Feb 15 10:28:30 CST 2017
-- \d "Party_pkey" 
--       Index "public.Party_pkey"
--   Column  |    Type     | Definition 
-- ----------+-------------+------------
--  caseNo   | "CaseNoT"   | "caseNo"
--  partyNo  | "PartyNoT"  | "partyNo"
--  countyNo | "CountyNoT" | "countyNo"
-- primary key, btree, for table "public.Party"

BEGIN;
UPDATE "Party" SET "attyNameF" = 'James', "attyNameM" = 'C.', "attyNameL" = 'Herrick', "attySuffix" = 'Jr.' WHERE "caseNo" = '2016CV000142' AND "partyNo" = 1 AND "countyNo" = 70;
COMMIT;
SELECT "caseNo","countyNo","partyNo","cpi","defendantId",to_char("dob", 'MM-DD-YYYY') AS "_dob","fingerPrintId","isInCustody"::VARCHAR(5) AS "_isInCstdy","isSentNotc"::VARCHAR(5) AS "_isSntNtc","Party"."fullNameFirstNameFirst" AS "_fullName","partyType" AS "_pTyp",
       "Party"."searchName","Party"."soundex","statusCode" AS "stCd","sex",'123-45-6789' AS "_ssn",'H98765432101234' AS "_operLicNo","isENotice"::VARCHAR(5) AS "_isENtc","Party"."attySearchName","Party"."attyFullNameFirstNameFirst" AS "_attyFullName"
FROM   "Party"
WHERE  "caseNo" = '2016CV000142'
ORDER BY "partyNo";
--     caseNo    | countyNo | partyNo | cpi | defendantId | _dob | fingerPrintId | _isInCstdy | _isSntNtc |                _fullName                | _pTyp |            searchName             | soundex | stCd | sex |    _ssn     |   _operLicNo    | _isENtc |   attySearchName   |    _attyFullName     
-- --------------+----------+---------+-----+-------------+------+---------------+------------+-----------+-----------------------------------------+-------+-----------------------------------+---------+------+-----+-------------+-----------------+---------+--------------------+----------------------
--  2016CV000142 |       70 |       1 |     |             |      |               | false      | false     | Maxwell Wisnefske                       | CH    | WISNEFSKE,MAXWELL                 | W251    | AC   |     | 123-45-6789 | H98765432101234 | false   | HERRICK,JAMESCJR   | James C. Herrick Jr.
--  2016CV000142 |       70 |       2 |     |             |      |               | false      | false     | Shannon Truttmann                       | PL    | TRUTTMANN,SHANNON                 | T635    | AC   |     | 123-45-6789 | H98765432101234 | false   | HERRICK,JAMESCJR   | James C. Herrick Jr.
--  2016CV000142 |       70 |       3 |     |             |      |               | false      | false     | Keith Wisnefske                         | PL    | WISNEFSKE,KEITH                   | W251    | AC   |     | 123-45-6789 | H98765432101234 | false   | HERRICK,JAMESCJR   | James C. Herrick Jr.
--  2016CV000142 |       70 |       4 |     |             |      |               | false      | false     | Blue Cross and Blue Shield of Minnesota | IP    | BLUECROSSANDBLUESHIELDOFMINNESOTA | B426    | AC   |     | 123-45-6789 | H98765432101234 | false   | MAYER,MATTHEWSHAWN | Matthew Shawn Mayer
--  2016CV000142 |       70 |       5 |     |             |      |               | false      | false     | Blue Cross and Blue Shield of Minnesota | IP    | BLUECROSSANDBLUESHIELDOFMINNESOTA | B426    | AC   |     | 123-45-6789 | H98765432101234 | false   | MAYER,MATTHEWSHAWN | Matthew Shawn Mayer
--  2016CV000142 |       70 |       6 |     |             |      |               | false      | false     | Judith S Papenfuss                      | DE    | PAPENFUSS,JUDITHS                 | P151    | AC   |     | 123-45-6789 | H98765432101234 | false   | EMER,MICHAELANDREW | Michael Andrew Emer
--  2016CV000142 |       70 |       7 |     |             |      |               | false      | false     | Safeco Insurance Company of America     | DE    | SAFECOINSURANCECOMPANYOFAMERICA   | S125    | AC   |     | 123-45-6789 | H98765432101234 | false   | EMER,MICHAELANDREW | Michael Andrew Emer
--  2016CV000142 |       70 |       8 |     |             |      |               | false      | false     | Safeco Insurance Company of America     | DE    | SAFECOINSURANCECOMPANYOFAMERICA   | S125    | AC   |     | 123-45-6789 | H98765432101234 | false   | EMER,MICHAELANDREW | Michael Andrew Emer
-- (8 rows)

\echo `date`
BEGIN;
UPDATE "Party" SET "attyNameF" = NULL, "attyNameM" = NULL, "attyNameL" = NULL, "attySuffix" = NULL WHERE "caseNo" = '2016CV000142' AND "partyNo" = 1 AND "countyNo" = 70;
COMMIT;

-- =======================================================================================================================================================================

-- Mon 20 Feb 2017 07:22:14 AM CST 
SELECT m."messageId", m."clientMessageId" AS "_clntMsgId", m."status" AS _st,
       to_char(m.created, 'Dy, Mon DD, YYYY HH12:MI:SS.MS AM TZ') AS "_created", to_char(m."lastModified", 'Dy, Mon DD, YYYY HH12:MI:SS.MS AM TZ') AS "_lastModified",
       "formatXMLString"('@countyNumber',           SUBSTRING(replace(b.body::text,'\015\012','') FROM 113 )::xml)::int AS "_cN",
       "formatXMLString"('@releaseType',            SUBSTRING(replace(b.body::text,'\015\012','') FROM 113 )::xml) AS "_relType",
       "formatXMLString"('dorWarrantNumber/text()', SUBSTRING(replace(b.body::text,'\015\012','') FROM 113 )::xml) AS "_dorWrrntNo",
       "formatXMLString"('caseNumber/text()',       SUBSTRING(replace(b.body::text,'\015\012','') FROM 113 )::xml) AS "_caseNo",
       "formatXMLString"('releaseDate/text()',      SUBSTRING(replace(b.body::text,'\015\012','') FROM 113 )::xml) AS "_relDate",
       "formatXMLString"('namePartial/text()',      SUBSTRING(replace(b.body::text,'\015\012','') FROM 113 )::xml) AS "_namePartial",
       'https://stepadmin.wicourts.gov/viewMessage.do?operation=particular&queueName=' ||  m."destQueue" || '&messageId=' || m."messageId" AS url
FROM   "Message" AS m
  JOIN "Body"    AS b ON (b."bodySeqNo" = m."bodySeqNo")
WHERE  m."destQueue" ~ 'CCAPCorp-TaxWarrantRelease'
  AND  NOT "formatXMLString"('@releaseType', SUBSTRING(replace(b.body::text,'\015\012','') FROM 113 )::xml) IN ( 'partial' )
  AND  NOT "formatXMLString"('@releaseType', SUBSTRING(replace(b.body::text,'\015\012','') FROM 113 )::xml) IN ( 'full' )
  AND  m.status = 'A'
ORDER BY created;
