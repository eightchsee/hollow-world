BEGIN;

SELECT m."messageId", m."clientMessageId" AS "_clntMsgId", m."destQueue", m."status" AS _st,
       to_char(m."created", 'Dy, Mon DD, YYYY HH12:MI:SS AM TZ') AS "_created",
       to_char(m."lastModified", 'Dy, Mon DD, YYYY HH12:MI:SS AM TZ') AS "_lastModified",
       "formatXMLString"('@countyNumber', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_cN",
       "formatXMLString"('@releaseType', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_relType",
       "formatXMLString"('dorWarrantNumber/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_dorWrrntNo",
       "formatXMLString"('caseNumber/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_caseNo",
       "formatXMLString"('releaseDate/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_relDate",
       "formatXMLString"('namePartial/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_namePartial"
FROM   "Message" AS m
  JOIN "Body"    AS b ON (b."bodySeqNo" = m."bodySeqNo")
WHERE  ("destQueue" ~ 'CCAPCorp-TaxWarrantRelease' AND "destQueue" ~ '-f')
  AND  status = 'A' AND "formatXMLString"('@releaseType', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) = 'partial'
ORDER BY created;
 messageId | _clntMsgId |           destQueue            | _st |             _created              |           _lastModified           | _cN | _relType | _dorWrrntNo |   _caseNo    |  _relDate  |    _namePartial    
-----------+------------+--------------------------------+-----+-----------------------------------+-----------------------------------+-----+----------+-------------+--------------+------------+--------------------
 369523829 | 112246     | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:29 PM CST | Mon, Feb 06, 2017 10:50:29 PM CST | 05  | partial  | 05-11971256 | 2010TW000122 | 02-06-2017 | RITA K LINDE
 369523830 | 124236     | CCAPCorp-TaxWarrantRelease-f13 | A   | Mon, Feb 06, 2017 10:50:29 PM CST | Mon, Feb 06, 2017 10:50:29 PM CST | 13  | partial  | 13-00238047 | 2004TW000447 | 02-06-2017 | SHAWN ROBINSON
 369523831 | 1694226    | CCAPCorp-TaxWarrantRelease-f67 | A   | Mon, Feb 06, 2017 10:50:29 PM CST | Mon, Feb 06, 2017 10:50:29 PM CST | 67  | partial  | 67-00234349 | 2005TW001435 | 02-06-2017 | ISABEL L TERLINDEN
 369523834 | 120318     | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:29 PM CST | Mon, Feb 06, 2017 10:50:29 PM CST | 51  | partial  | 51-00193427 | 02TW000075   | 02-06-2017 | ROBERT R KLINGBEIL
 369523864 | 128332     | CCAPCorp-TaxWarrantRelease-f18 | A   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 18  | partial  | 18-00164484 | 02TW000087   | 02-06-2017 | ERNEST N WACKWITZ
 369523870 | 132299     | CCAPCorp-TaxWarrantRelease-f53 | A   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 53  | partial  | 53-00182276 | 2006TW000247 | 02-06-2017 | SHIRLEY BUTT
 369523885 | 144294     | CCAPCorp-TaxWarrantRelease-f42 | A   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 42  | partial  | 42-11828763 | 2010TW000013 | 02-06-2017 | RITA WOOD
 369523886 | 1056953    | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 40  | partial  | 40-00462701 | 2004TW005488 | 02-06-2017 | SHERLENE K BOSSE
 369523901 | 1064989    | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 51  | partial  | 70-11602469 | 2014TW000030 | 02-06-2017 | RICK E JACOBSEN
 369523928 | 128335     | CCAPCorp-TaxWarrantRelease-f09 | A   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 09  | partial  | 09-00157850 | 01TW000144   | 02-06-2017 | WILLIAM WALMSLEY
 369523933 | 1072867    | CCAPCorp-TaxWarrantRelease-f05 | A   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 05  | partial  | 05-11999178 | 2010TW000121 | 02-06-2017 | RITA K LINDE
 369523961 | 136445     | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 51  | partial  | 51-00191336 | 00TW001180   | 02-06-2017 | ROBERT R KLINGBEIL
 369523977 | 132302     | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:50:33 PM CST | Mon, Feb 06, 2017 10:50:33 PM CST | 51  | partial  | 51-00192768 | 01TW001026   | 02-06-2017 | FLOYD HOPKINS
 369524001 | 1694230    | CCAPCorp-TaxWarrantRelease-f67 | A   | Mon, Feb 06, 2017 10:50:33 PM CST | Mon, Feb 06, 2017 10:50:33 PM CST | 67  | partial  | 67-00225451 | 01TW002107   | 02-06-2017 | VIRGINIA CAMERON
 369524013 | 1078910    | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:38 PM CST | Mon, Feb 06, 2017 10:50:38 PM CST | 40  | partial  | 40-00455454 | 2003TW001761 | 02-06-2017 | SAMUEL JACKSON
 369524043 | 148292     | CCAPCorp-TaxWarrantRelease-f67 | A   | Mon, Feb 06, 2017 10:50:47 PM CST | Mon, Feb 06, 2017 10:50:47 PM CST | 67  | partial  | 67-00235691 | 2006TW001078 | 02-06-2017 | LISA TEAYS
 369524049 | 1626617    | CCAPCorp-TaxWarrantRelease-f40 | A   | Mon, Feb 06, 2017 10:50:47 PM CST | Mon, Feb 06, 2017 10:50:47 PM CST | 40  | partial  | 40-00462702 | 2004TW005489 | 02-06-2017 | SHERLENE K BOSSE
 369524078 | 128341     | CCAPCorp-TaxWarrantRelease-f51 | A   | Mon, Feb 06, 2017 10:51:05 PM CST | Mon, Feb 06, 2017 10:51:05 PM CST | 51  | partial  | 51-00196138 | 2004TW000846 | 02-06-2017 | SCOTT KIPP
(18 rows)


UPDATE "Message"
SET    "status" = 'D'
WHERE  "messageId" IN (369523829,369523830,369523831,369523834,369523864,369523870,369523885,369523886,369523901,369523928,369523933,369523961,369523977,369524001,369524013,369524043,369524049,369524078)
  AND  "status" = 'A';
UPDATE 18
SELECT m."messageId", m."clientMessageId" AS "_clntMsgId", m."destQueue", m."status" AS _st,
       to_char(m."created", 'Dy, Mon DD, YYYY HH12:MI:SS AM TZ') AS "_created",
       to_char(m."lastModified", 'Dy, Mon DD, YYYY HH12:MI:SS AM TZ') AS "_lastModified",
       "formatXMLString"('@countyNumber', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_cN",
       "formatXMLString"('@releaseType', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_relType",
       "formatXMLString"('dorWarrantNumber/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_dorWrrntNo",
       "formatXMLString"('caseNumber/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_caseNo",
       "formatXMLString"('releaseDate/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_relDate",
       "formatXMLString"('namePartial/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_namePartial"
FROM   "Message" AS m
  JOIN "Body"    AS b ON (b."bodySeqNo" = m."bodySeqNo")
WHERE  "messageId" IN (369523829,369523830,369523831,369523834,369523864,369523870,369523885,369523886,369523901,369523928,369523933,369523961,369523977,369524001,369524013,369524043,369524049,369524078);
 messageId | _clntMsgId |           destQueue            | _st |             _created              |           _lastModified           | _cN | _relType | _dorWrrntNo |   _caseNo    |  _relDate  |    _namePartial    
-----------+------------+--------------------------------+-----+-----------------------------------+-----------------------------------+-----+----------+-------------+--------------+------------+--------------------
 369523864 | 128332     | CCAPCorp-TaxWarrantRelease-f18 | D   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 18  | partial  | 18-00164484 | 02TW000087   | 02-06-2017 | ERNEST N WACKWITZ
 369523829 | 112246     | CCAPCorp-TaxWarrantRelease-f05 | D   | Mon, Feb 06, 2017 10:50:29 PM CST | Mon, Feb 06, 2017 10:50:29 PM CST | 05  | partial  | 05-11971256 | 2010TW000122 | 02-06-2017 | RITA K LINDE
 369523830 | 124236     | CCAPCorp-TaxWarrantRelease-f13 | D   | Mon, Feb 06, 2017 10:50:29 PM CST | Mon, Feb 06, 2017 10:50:29 PM CST | 13  | partial  | 13-00238047 | 2004TW000447 | 02-06-2017 | SHAWN ROBINSON
 369523831 | 1694226    | CCAPCorp-TaxWarrantRelease-f67 | D   | Mon, Feb 06, 2017 10:50:29 PM CST | Mon, Feb 06, 2017 10:50:29 PM CST | 67  | partial  | 67-00234349 | 2005TW001435 | 02-06-2017 | ISABEL L TERLINDEN
 369523834 | 120318     | CCAPCorp-TaxWarrantRelease-f51 | D   | Mon, Feb 06, 2017 10:50:29 PM CST | Mon, Feb 06, 2017 10:50:29 PM CST | 51  | partial  | 51-00193427 | 02TW000075   | 02-06-2017 | ROBERT R KLINGBEIL
 369523901 | 1064989    | CCAPCorp-TaxWarrantRelease-f51 | D   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 51  | partial  | 70-11602469 | 2014TW000030 | 02-06-2017 | RICK E JACOBSEN
 369523885 | 144294     | CCAPCorp-TaxWarrantRelease-f42 | D   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 42  | partial  | 42-11828763 | 2010TW000013 | 02-06-2017 | RITA WOOD
 369523886 | 1056953    | CCAPCorp-TaxWarrantRelease-f40 | D   | Mon, Feb 06, 2017 10:50:31 PM CST | Mon, Feb 06, 2017 10:50:31 PM CST | 40  | partial  | 40-00462701 | 2004TW005488 | 02-06-2017 | SHERLENE K BOSSE
 369523870 | 132299     | CCAPCorp-TaxWarrantRelease-f53 | D   | Mon, Feb 06, 2017 10:50:30 PM CST | Mon, Feb 06, 2017 10:50:30 PM CST | 53  | partial  | 53-00182276 | 2006TW000247 | 02-06-2017 | SHIRLEY BUTT
 369524001 | 1694230    | CCAPCorp-TaxWarrantRelease-f67 | D   | Mon, Feb 06, 2017 10:50:33 PM CST | Mon, Feb 06, 2017 10:50:33 PM CST | 67  | partial  | 67-00225451 | 01TW002107   | 02-06-2017 | VIRGINIA CAMERON
 369523961 | 136445     | CCAPCorp-TaxWarrantRelease-f51 | D   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 51  | partial  | 51-00191336 | 00TW001180   | 02-06-2017 | ROBERT R KLINGBEIL
 369523928 | 128335     | CCAPCorp-TaxWarrantRelease-f09 | D   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 09  | partial  | 09-00157850 | 01TW000144   | 02-06-2017 | WILLIAM WALMSLEY
 369523933 | 1072867    | CCAPCorp-TaxWarrantRelease-f05 | D   | Mon, Feb 06, 2017 10:50:32 PM CST | Mon, Feb 06, 2017 10:50:32 PM CST | 05  | partial  | 05-11999178 | 2010TW000121 | 02-06-2017 | RITA K LINDE
 369523977 | 132302     | CCAPCorp-TaxWarrantRelease-f51 | D   | Mon, Feb 06, 2017 10:50:33 PM CST | Mon, Feb 06, 2017 10:50:33 PM CST | 51  | partial  | 51-00192768 | 01TW001026   | 02-06-2017 | FLOYD HOPKINS
 369524013 | 1078910    | CCAPCorp-TaxWarrantRelease-f40 | D   | Mon, Feb 06, 2017 10:50:38 PM CST | Mon, Feb 06, 2017 10:50:38 PM CST | 40  | partial  | 40-00455454 | 2003TW001761 | 02-06-2017 | SAMUEL JACKSON
 369524043 | 148292     | CCAPCorp-TaxWarrantRelease-f67 | D   | Mon, Feb 06, 2017 10:50:47 PM CST | Mon, Feb 06, 2017 10:50:47 PM CST | 67  | partial  | 67-00235691 | 2006TW001078 | 02-06-2017 | LISA TEAYS
 369524049 | 1626617    | CCAPCorp-TaxWarrantRelease-f40 | D   | Mon, Feb 06, 2017 10:50:47 PM CST | Mon, Feb 06, 2017 10:50:47 PM CST | 40  | partial  | 40-00462702 | 2004TW005489 | 02-06-2017 | SHERLENE K BOSSE
 369524078 | 128341     | CCAPCorp-TaxWarrantRelease-f51 | D   | Mon, Feb 06, 2017 10:51:05 PM CST | Mon, Feb 06, 2017 10:51:05 PM CST | 51  | partial  | 51-00196138 | 2004TW000846 | 02-06-2017 | SCOTT KIPP
(18 rows)

COMMIT;


-- Wed 08 Feb 2017 05:01:46 PM CST 

SELECT m."messageId", m."clientMessageId" AS "_clntMsgId", m."destQueue", m."status" AS _st,
       to_char(m."created", 'Dy, Mon DD, YYYY HH12:MI:SS AM TZ') AS "_created",
       to_char(m."lastModified", 'Dy, Mon DD, YYYY HH12:MI:SS AM TZ') AS "_lastModified",
       "formatXMLString"('@countyNumber', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_cN",
       "formatXMLString"('@releaseType', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_relType",
       "formatXMLString"('dorWarrantNumber/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_dorWrrntNo",
       "formatXMLString"('caseNumber/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_caseNo",
       "formatXMLString"('releaseDate/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_relDate",
       "formatXMLString"('namePartial/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_namePartial"
FROM   "Message" AS m
  JOIN "Body"    AS b ON (b."bodySeqNo" = m."bodySeqNo")
WHERE  ("destQueue" ~ 'CCAPCorp-TaxWarrantRelease' AND "destQueue" ~ '-f')
  AND  status = 'A' AND "formatXMLString"('@releaseType', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) = 'partial'
ORDER BY created;
 messageId | _clntMsgId |           destQueue            | _st |             _created              |           _lastModified           | _cN | _relType | _dorWrrntNo |   _caseNo    |  _relDate  |    _namePartial    
-----------+------------+--------------------------------+-----+-----------------------------------+-----------------------------------+-----+----------+-------------+--------------+------------+--------------------
 369629992 | 1098698    | CCAPCorp-TaxWarrantRelease-f13 | A   | Tue, Feb 07, 2017 11:25:11 PM CST | Tue, Feb 07, 2017 11:25:11 PM CST | 13  | partial  | 13-00238047 | 2004TW000447 | 02-07-2017 | SHAWN ROBINSON
 369629995 | 1700235    | CCAPCorp-TaxWarrantRelease-f05 | A   | Tue, Feb 07, 2017 11:25:11 PM CST | Tue, Feb 07, 2017 11:25:11 PM CST | 05  | partial  | 05-11971256 | 2010TW000122 | 02-07-2017 | RITA K LINDE
 369629996 | 1646349    | CCAPCorp-TaxWarrantRelease-f67 | A   | Tue, Feb 07, 2017 11:25:11 PM CST | Tue, Feb 07, 2017 11:25:11 PM CST | 67  | partial  | 67-00235691 | 2006TW001078 | 02-07-2017 | LISA TEAYS
 369629999 | 1656322    | CCAPCorp-TaxWarrantRelease-f51 | A   | Tue, Feb 07, 2017 11:25:11 PM CST | Tue, Feb 07, 2017 11:25:11 PM CST | 51  | partial  | 51-00193427 | 02TW000075   | 02-07-2017 | ROBERT R KLINGBEIL
 369630000 | 1662284    | CCAPCorp-TaxWarrantRelease-f51 | A   | Tue, Feb 07, 2017 11:25:11 PM CST | Tue, Feb 07, 2017 11:25:11 PM CST | 51  | partial  | 51-00196138 | 2004TW000846 | 02-07-2017 | SCOTT KIPP
 369630001 | 1664328    | CCAPCorp-TaxWarrantRelease-f11 | A   | Tue, Feb 07, 2017 11:25:11 PM CST | Tue, Feb 07, 2017 11:25:11 PM CST | 11  | partial  | 11-00159228 | 99TW000454   | 02-07-2017 | FRANCIS R KIEFER
 369630002 | 1662285    | CCAPCorp-TaxWarrantRelease-f40 | A   | Tue, Feb 07, 2017 11:25:11 PM CST | Tue, Feb 07, 2017 11:25:11 PM CST | 40  | partial  | 40-00473553 | 2007TW000945 | 02-07-2017 | SHARECA THOMPSON
 369630003 | 1648376    | CCAPCorp-TaxWarrantRelease-f40 | A   | Tue, Feb 07, 2017 11:25:11 PM CST | Tue, Feb 07, 2017 11:25:11 PM CST | 40  | partial  | 40-00462702 | 2004TW005489 | 02-07-2017 | SHERLENE K BOSSE
 369630004 | 1710166    | CCAPCorp-TaxWarrantRelease-f10 | A   | Tue, Feb 07, 2017 11:25:11 PM CST | Tue, Feb 07, 2017 11:25:11 PM CST | 10  | partial  | 10-00154058 | 2006TW000012 | 02-07-2017 | EMIL UNTIEDT JR
 369630005 | 1088877    | CCAPCorp-TaxWarrantRelease-f51 | A   | Tue, Feb 07, 2017 11:25:11 PM CST | Tue, Feb 07, 2017 11:25:11 PM CST | 51  | partial  | 51-00192768 | 01TW001026   | 02-07-2017 | FLOYD HOPKINS
 369630006 | 140322     | CCAPCorp-TaxWarrantRelease-f53 | A   | Tue, Feb 07, 2017 11:25:11 PM CST | Tue, Feb 07, 2017 11:25:11 PM CST | 53  | partial  | 53-00182276 | 2006TW000247 | 02-07-2017 | SHIRLEY BUTT
 369630007 | 1712128    | CCAPCorp-TaxWarrantRelease-f15 | A   | Tue, Feb 07, 2017 11:25:11 PM CST | Tue, Feb 07, 2017 11:25:11 PM CST | 15  | partial  | 15-00155756 | 01TW000018   | 02-07-2017 | LINDA LEROY
 369630008 | 140323     | CCAPCorp-TaxWarrantRelease-f51 | A   | Tue, Feb 07, 2017 11:25:11 PM CST | Tue, Feb 07, 2017 11:25:11 PM CST | 51  | partial  | 70-11602469 | 2014TW000030 | 02-07-2017 | RICK E JACOBSEN
 369630009 | 1714141    | CCAPCorp-TaxWarrantRelease-f67 | A   | Tue, Feb 07, 2017 11:25:11 PM CST | Tue, Feb 07, 2017 11:25:11 PM CST | 67  | partial  | 67-00234349 | 2005TW001435 | 02-07-2017 | ISABEL L TERLINDEN
 369630010 | 1630606    | CCAPCorp-TaxWarrantRelease-f40 | A   | Tue, Feb 07, 2017 11:25:11 PM CST | Tue, Feb 07, 2017 11:25:11 PM CST | 40  | partial  | 40-00462701 | 2004TW005488 | 02-07-2017 | SHERLENE K BOSSE
 369630011 | 1646351    | CCAPCorp-TaxWarrantRelease-f05 | A   | Tue, Feb 07, 2017 11:25:11 PM CST | Tue, Feb 07, 2017 11:25:11 PM CST | 05  | partial  | 05-11999178 | 2010TW000121 | 02-07-2017 | RITA K LINDE
 369630012 | 1562737    | CCAPCorp-TaxWarrantRelease-f42 | A   | Tue, Feb 07, 2017 11:25:11 PM CST | Tue, Feb 07, 2017 11:25:11 PM CST | 42  | partial  | 42-11828763 | 2010TW000013 | 02-07-2017 | RITA WOOD
 369630013 | 140324     | CCAPCorp-TaxWarrantRelease-f51 | A   | Tue, Feb 07, 2017 11:25:11 PM CST | Tue, Feb 07, 2017 11:25:11 PM CST | 51  | partial  | 51-00191336 | 00TW001180   | 02-07-2017 | ROBERT R KLINGBEIL
 369630014 | 1654362    | CCAPCorp-TaxWarrantRelease-f40 | A   | Tue, Feb 07, 2017 11:25:11 PM CST | Tue, Feb 07, 2017 11:25:11 PM CST | 40  | partial  | 40-00455454 | 2003TW001761 | 02-07-2017 | SAMUEL JACKSON
 369630016 | 1716100    | CCAPCorp-TaxWarrantRelease-f18 | A   | Tue, Feb 07, 2017 11:25:11 PM CST | Tue, Feb 07, 2017 11:25:11 PM CST | 18  | partial  | 18-00164484 | 02TW000087   | 02-07-2017 | ERNEST N WACKWITZ
 369630026 | 1662287    | CCAPCorp-TaxWarrantRelease-f09 | A   | Tue, Feb 07, 2017 11:25:25 PM CST | Tue, Feb 07, 2017 11:25:25 PM CST | 09  | partial  | 09-00157850 | 01TW000144   | 02-07-2017 | WILLIAM WALMSLEY
 369630033 | 1646352    | CCAPCorp-TaxWarrantRelease-f67 | A   | Tue, Feb 07, 2017 11:25:43 PM CST | Tue, Feb 07, 2017 11:25:43 PM CST | 67  | partial  | 67-00225451 | 01TW002107   | 02-07-2017 | VIRGINIA CAMERON
 369630034 | 1630607    | CCAPCorp-TaxWarrantRelease-f11 | A   | Tue, Feb 07, 2017 11:25:43 PM CST | Tue, Feb 07, 2017 11:25:43 PM CST | 11  | partial  | 11-00005338 |              | 02-07-2017 | FRANCIS R KIEFER
(23 rows)
BEGIN;

UPDATE "Message"
SET    "status" = 'D'
WHERE  "messageId" IN (369629992,369629995,369629996,369629999,369630000,369630001,369630002,369630003,369630004,369630005,369630006,369630007,369630008,369630009,369630010,369630011,369630012,369630013,369630014,369630016,369630026,369630033,369630034)
  AND  "status" = 'A';

SELECT m."messageId", m."clientMessageId" AS "_clntMsgId", m."destQueue", m."status" AS _st,
       to_char(m."created", 'Dy, Mon DD, YYYY HH12:MI:SS AM TZ') AS "_created",
       to_char(m."lastModified", 'Dy, Mon DD, YYYY HH12:MI:SS AM TZ') AS "_lastModified",
       "formatXMLString"('@countyNumber', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_cN",
       "formatXMLString"('@releaseType', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_relType",
       "formatXMLString"('dorWarrantNumber/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_dorWrrntNo",
       "formatXMLString"('caseNumber/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_caseNo",
       "formatXMLString"('releaseDate/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_relDate",
       "formatXMLString"('namePartial/text()', SUBSTRING(replace(b.body::text, '\015\012', '') FROM 113 )::xml) AS "_namePartial"
FROM   "Message" AS m
  JOIN "Body"    AS b ON (b."bodySeqNo" = m."bodySeqNo")
WHERE  "messageId" IN (369629992,369629995,369629996,369629999,369630000,369630001,369630002,369630003,369630004,369630005,369630006,369630007,369630008,369630009,369630010,369630011,369630012,369630013,369630014,369630016,369630026,369630033,369630034)
ORDER BY created;

-- COMMIT;



