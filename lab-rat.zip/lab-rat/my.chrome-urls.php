<?php
?>
<!doctype html />
<html>
  <head>
    <meta content="1800" http-equiv="refresh">
    <title>my chrome-urls</title>
    <style type="text/css">
      body {font-size: .8em;}
      div.listing {font-family: monospace; font-size: 12pt;}
      curr_time {display: block; text-align: center; margin: 10px; color: #c00000; font-size: small; line-height: 1pt; font-style: italic;}
    </style>
  </head>
  <body>
<?php
  $myfile = fopen("chrome-urls.txt", "r") or die("Unable to open file!");
?>
    <ul>
<?php
  // Output one line until end-of-file
  while(!feof($myfile)) {
    $line = fgets($myfile);
    if (strstr($line, "http") != null) {
?>
      <li><a target="_blank" href="<?php echo $line ?>"><?php echo $line ?></a></li>
<?php
    }
    else {
?>
      <li style="list-style-type: none; margin-top: 8px;"><?php echo $line ?></li>
<?php
    }
  }
  fclose($myfile);
?>
    </ul>
  </body>
</html>
