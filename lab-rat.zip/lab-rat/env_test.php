<?php
  if (isset($_ENV["HOSTNAME"]))
    $hostname = $_ENV["HOSTNAME"];
//  $uzername = $_ENV["USERNAME"];
  $uzername = getenv("SUDO_USER");
?>
<!doctype html />
<html>
  <head>
    <title>my environment stuff</title>
    <style type="text/css">div.listing {font-family: monospace; font-size: 12pt;}</style>
  </head>
  <body>
    <!-- div class="listing"><//?php echo $uzername . "@" . $hostname . ":~$ "; ?></div -->
    <div class="listing"><?php echo $uzername . "@tom_h-c-ubuntu:~$ "; ?></div>
    <?php phpinfo(INFO_GENERAL); ?>
    <?php phpinfo(INFO_ENVIRONMENT); ?>
  </body>
</html
