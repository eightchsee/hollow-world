-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 03, 2015 at 02:31 PM
-- Server version: 5.5.40-36.1-log
-- PHP Version: 5.4.23

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `redhotra_rattlers`
--

-- --------------------------------------------------------

--
-- Table structure for table `Venues`
--

DROP TABLE IF EXISTS `Venues`;
CREATE TABLE IF NOT EXISTS `Venues` (
  `ID` bigint(16) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  `Address1` varchar(100) DEFAULT NULL,
  `Address2` varchar(100) DEFAULT NULL,
  `City` varchar(100) DEFAULT NULL,
  `State` char(2) DEFAULT NULL,
  `Zip` varchar(15) DEFAULT NULL,
  `Contact` varchar(100) DEFAULT NULL,
  `Phone` varchar(15) DEFAULT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `URL` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=97 ;

--
-- Dumping data for table `Venues`
--

INSERT INTO `Venues` (`ID`, `Name`, `Address1`, `Address2`, `City`, `State`, `Zip`, `Contact`, `Phone`, `Description`, `URL`) VALUES
(4, 'Arena Firemen''s Benefit', NULL, NULL, 'Arena', 'WI', '53503', NULL, NULL, NULL, NULL),
(3, 'The Dry Bean', '5264 Verona Rd', NULL, 'Madison', 'WI', '53711', 'info@thedrybean.com', '608.274.3324', NULL, 'www.thedrybean.com'),
(10, 'Sauk County Fair', 'Sauk County Fairgrounds', NULL, 'Baraboo', 'WI', '53913', 'Shayna Cassidy', '608.356.0503', NULL, NULL),
(11, 'Beck''s On The Water', 'N3135 Cth V', NULL, 'Poynette', 'WI', '53955', NULL, NULL, NULL, NULL),
(12, 'Endres Manufacturing Company', '802 S Century Avenue', NULL, 'Waunakee', 'WI', '53597', NULL, NULL, NULL, NULL),
(14, 'UW Field House', '1430 Monroe St', NULL, 'Madison', 'WI', '53711', NULL, '608.263.6566', NULL, 'http://www.uwbadgers.com/'),
(18, 'Q106 25th Birthday Bash', 'Willow Island at Alliant Energy Center', 'John Nolan Drive', 'Madison', 'WI', '53701', NULL, NULL, NULL, NULL),
(20, 'Mt. Horeb Frolic', 'Grundahl Park', 'Blue Mounds Street & Parkway', 'Mount Horeb', 'WI', '53572', NULL, NULL, NULL, 'www.trollway.com'),
(21, 'St John''s Church Festival', '209 South St', NULL, 'Waunakee', 'WI', '53597', NULL, NULL, NULL, 'www.stjb.org'),
(22, 'Fire on the River', 'Veteran''s Park', NULL, 'Prairie du Sac', 'WI', '53578', NULL, NULL, NULL, NULL),
(23, 'New Glarus Firemen''s Festival', NULL, NULL, 'New Glarus', 'WI', '53574', NULL, NULL, NULL, NULL),
(24, 'Oregon Summerfest', 'Jaycee Park', 'Entrances at N. Perry Parkway & S. Oak Streets', 'Oregon', 'WI', '53575', NULL, NULL, NULL, 'http://www.oregonwi.com'),
(25, 'Fitz''s On The Lake', 'W11602 County Road V', NULL, 'Lodi', 'WI', '53555', '608.592.3302', '800.852.9658', '"Lake Wisconsin''s BEST Restaurant and Sports Bar Located Along the Shores of Lake Wisconsin mid-way Between Lodi and the Merrimac Ferry"', 'www.fitzsrestaurantlakewisconsin.com/'),
(26, 'Mazomanie wild west days', NULL, NULL, 'Mazomanie', 'WI', NULL, NULL, NULL, NULL, NULL),
(28, 'Taste of Madison', 'Capitol Square', NULL, 'Madison', 'WI', '53701', 'bonnie@wjjo.com', '608.441.3732', 'The Taste of Madison is a celebration of food, entertainment, and fun! For the past 32 years, Madison''s finest in eats and entertainment, families and friends gather in the Capitol Square for this free festival. This year, Taste of Madison features 80 res', 'www.tasteofmadison.com'),
(30, 'Marion Park', NULL, NULL, 'Prairie du Sac', 'WI', NULL, NULL, NULL, 'Wisconsin State Cow Chip Throw', 'http://www.wiscowchip.com/events.htm'),
(32, 'Marriott West', NULL, NULL, 'Middleton', 'WI', NULL, NULL, NULL, 'Private Party', NULL),
(34, 'St. Joseph''s Church Festival', NULL, NULL, 'Waunakee', 'WI', NULL, NULL, NULL, NULL, NULL),
(35, 'JB''s Grill', NULL, NULL, 'Sun Prairie', 'WI', NULL, NULL, NULL, NULL, NULL),
(36, 'Cottage Grove Festival', NULL, NULL, 'Cottage Grove', 'WI', NULL, NULL, NULL, NULL, NULL),
(37, 'Evansville Carnival ', NULL, NULL, 'Evansville', 'WI', NULL, NULL, NULL, NULL, NULL),
(38, 'Harley Davidson Party', 'Capitol Harley Madison', NULL, 'Madison', 'WI', NULL, NULL, NULL, NULL, NULL),
(39, 'Sacred Hearts Festival', '221 Columbus Street', NULL, 'Sun Prairie', 'WI', '53590', 'sacredhearts@sacred-hearts.org', '608,837,7381', 'Scared Hearts Church', 'sacred-hearts.org/'),
(40, 'Trails End Bar & Grill ', '1497 Alpine Drive', 'Town of Rome', 'Nakoosa', 'WI', '54457', NULL, '715.325.9898', NULL, 'trailsendbarandgrill.com/'),
(45, 'Club Tavern', '1915 Branch St', NULL, 'Middleton', 'WI', '53562', 'moose@clubtavern.com', '608-836-3773', 'What are you looking for......\r\n\r\nGreat food? \r\nMaybe just quick lunch? \r\nFriday, Saturday or Sunday Breakfast with the kids? \r\nAre you looking to Party?\r\nOr are you simply looking for a place to catch a beer after work?  \r\n\r\nNo matter what the occasion, ', 'www.clubtavern.com/'),
(46, 'Badger Bowl', '506 East Badger Road', NULL, 'Madison', 'WI', '53713', NULL, '608-274-6662', NULL, 'badgerbowl.com/entertainment/livemusic.html'),
(47, 'Jingles Coliseum Bar', '232 County Road MC', NULL, 'Madison', 'WI', NULL, NULL, '608-251-2434', NULL, NULL),
(48, 'Private Party', NULL, NULL, 'Madison', 'WI', NULL, NULL, NULL, NULL, NULL),
(49, 'Private Party', NULL, NULL, 'Fenimore', 'WI', NULL, NULL, NULL, NULL, NULL),
(50, 'Brat Fest', '1919 Alliant Energy Way', 'Willow Island', 'Madison', 'WI', NULL, NULL, NULL, NULL, NULL),
(51, 'Dejope', NULL, NULL, 'Madison', NULL, NULL, NULL, NULL, NULL, NULL),
(52, 'Star Spangled Celebration, Richland Center Wis.', 'Richland Center Wis.', NULL, NULL, NULL, NULL, NULL, NULL, 'Music festival', NULL),
(53, 'Battle of the Bands', 'Country Kitchen / White House Banquets', NULL, 'Richland Center', 'WI', NULL, NULL, NULL, 'Battle of the Bands for opening Spot at The Star Spangled Celebration in Richland center June 24,25,&26 ', NULL),
(54, 'SSC Battle of the Bands', 'Richland center', 'Country Kitchen/White house banquets', 'Richland center', NULL, NULL, NULL, NULL, 'Battle of the Bands for an opening spot at The Star Spangled Celebration in Richland Center', NULL),
(55, 'Plain Fire and EMS 3-Day Celebration', '925 Parkview Avenue', NULL, 'Plain', 'WI', '53577', NULL, NULL, NULL, 'www.plainwi.govoffice2.com'),
(56, 'Hodag Music Festival', NULL, NULL, 'Rhinelander ', 'WI', NULL, NULL, NULL, 'Hodag Music Fest State Band Competition', NULL),
(57, 'Labatt Blue Hockey Tourney', 'Oregon Community Sports Arena', NULL, 'Oregon', 'WI', NULL, NULL, NULL, NULL, NULL),
(58, 'Marquette County Fair', NULL, NULL, 'Westfield ', 'WI', NULL, NULL, NULL, 'County fair', NULL),
(59, 'Memorial union terrace', NULL, NULL, 'Madison', 'WI', NULL, NULL, NULL, 'Outside behind the Memorial Union Terrace\r\nUW MAdison', NULL),
(60, 'Star Spangled Celebration', NULL, NULL, 'Richland center', 'WI', NULL, NULL, NULL, 'Star Spangled Celebration music festival Richland Center WIS', NULL),
(61, 'Gilda''s Club Madison', NULL, NULL, 'Madison', NULL, NULL, NULL, NULL, NULL, NULL),
(62, 'Colgate County Showdown', NULL, NULL, 'Manitowoc', 'WI', NULL, NULL, NULL, 'Colgate Country Showdown', NULL),
(63, 'Wisconsin State Fair', '640 South 84th Street', NULL, 'West Allis', 'WI', '53214', 'wsfp@wisconsin.gov', '414.266.7000', 'Wis, State Fair', 'www.best11daysofsummer.com/wp/'),
(64, 'Black Earth Field Day''s', NULL, NULL, 'Black Earth', NULL, NULL, NULL, NULL, 'Black Earth Field Day''s Festival', NULL),
(65, 'Cannon Run', NULL, NULL, 'Bunker Hill', 'WI', NULL, NULL, NULL, 'Cannon run Motorcycle run Party', NULL),
(66, 'CC Riders Club House', '1325 Parkside Dr.', NULL, 'Madison', 'WI', NULL, NULL, NULL, NULL, NULL),
(67, 'MSA Party', 'chula vista', NULL, 'wis dells', NULL, NULL, NULL, NULL, 'MSA company party ', NULL),
(68, 'Q106 Majestic theater free concert', 'Majestic theater', 'King st.', 'Madison', 'WI', '53711', NULL, NULL, 'Q106 free concert opening for Frankie Ballard', NULL),
(69, 'New Glarus music festival', NULL, NULL, 'New Glarus', 'WI', NULL, NULL, NULL, NULL, NULL),
(70, 'Hollandale Fireman''s Festival', NULL, NULL, 'Hollandale', 'WI', NULL, NULL, NULL, NULL, NULL),
(71, 'Verona Home Town Days', '111 Lincoln Street', NULL, 'Verona ', 'WI', '53593', NULL, NULL, NULL, 'veronahometowndays.com'),
(72, 'Monona Community Festival', 'Winnequah Park', '1055 Nichols Road', 'Monona', 'WI', '53716', 'mononafestival@charter.net', '608.235.6726', NULL, 'www.mononafestival.com'),
(73, 'Urban Theater', NULL, NULL, 'Madison', 'WI', NULL, NULL, NULL, 'Urban Theater Local Music TV Show', 'www.facebook.com/theurbantheater'),
(74, 'Stoughton Fireman''s Dance', 'Mandt Park', NULL, 'Stoughton', 'WI', NULL, NULL, NULL, NULL, NULL),
(75, 'Cambridge Fireman''s Fest', 'Cambridge Fire Station', NULL, 'Cambridge', 'WI', NULL, NULL, NULL, NULL, 'www.cambridgewi.com/schedule%20events.htm#September0'),
(76, 'Poynette Street Dance', NULL, NULL, 'Poynette', 'WI', NULL, NULL, NULL, NULL, NULL),
(77, 'Red Mouse', NULL, NULL, 'Pine Bluff', 'WI', NULL, NULL, NULL, NULL, NULL),
(78, 'Q106 free concert', 'Badger Bowl', NULL, 'Madison', NULL, NULL, NULL, NULL, NULL, NULL),
(79, 'Belleville Bowl', NULL, NULL, 'Belleville', 'WI', NULL, NULL, NULL, NULL, NULL),
(80, 'HSJC FUR BALL ', '711 W. Racine St.', NULL, 'Jefferson', 'WI', '53549', NULL, NULL, 'Humane Society of Jefferson County Fur Ball At the Fairview in Jefferson', NULL),
(81, 'St Dennis Festival', '413 Dempsey Road', 'Dempsy Rd.', 'Madison', 'WI', '53714', 'info@stdennisparish.org', '608.246.5124', 'Saint Dennis Catholic Church', 'www.stdennisparish.org/'),
(82, 'Sugar River Lanes', '807 River Street', NULL, 'Belleville', 'WI', '53508', NULL, '608.424.3774', NULL, 'sugarriverlanes.com'),
(83, 'Honey Creek Rod & Gun Club', 'E 7412 Co. Rd. C', NULL, 'Leland ', 'WI', '53951', NULL, '608.963.5164', 'Hwy. 12 to Co. C or PF West to Leland.\r\nHwy. 23 to Leland rd. then east to Leland. \r\n\r\nThe Honey Creek Rod & Gun Club''s annual “Party At The Pond” in the park in Leland. 6 p.m. X2 DJs from 6 to 8 p.m. followed by Rachelle And The Red Hot Rattlers. $5 (und', NULL),
(84, 'Dane County Fair', 'Alliant Energy Center', '1919 Alliant Energy Way', 'Madison ', 'WI', '53713', 'dcf@wdexpo.com', '608.224.0500', 'The Dane County Fair is five days of fun and free entertainment.\r\nAll outdoor concerts and entertainment are FREE with fair admission! Stage shows, youth exhibits and special attractions are only some of the entertainment you''ll find at the fair!\r\nThe Dan', 'www.danecountyfair.com/'),
(85, 'SunPrairie golf course', NULL, NULL, 'Sun Prairie', 'WI', NULL, NULL, NULL, NULL, NULL),
(87, 'Kestrel Ridge Golf Club', '900 Avalon Rd', NULL, 'Columbus', 'WI', NULL, NULL, NULL, NULL, NULL),
(88, 'Angell Park', '315 Park Street', NULL, 'Sun Prairie ', 'WI', '53590', NULL, '608,837,5252', 'On land originally donated by Colonel William Angell, the Sun Prairie Volunteer Fire Department has been providing the community of Sun Prairie with entertainment and a place to gather for over 100 years. From gridiron to ball diamond; dance hall to swimm', 'www.angellparkspeedway.com'),
(89, 'Lake Arrowhead South Lake Center', '1195 Apache Lane', NULL, 'Nakoosa', 'WI', '54457', NULL, '715,325,2929', NULL, NULL),
(90, 'JD & ME''s (formerly Nelson''s crossing)', '1152 Berlin Rd', NULL, 'Marshall', 'WI', '53559', NULL, '608,655,1163', NULL, 'nelsons-crossing.webs.com'),
(91, 'Dorf Haus', NULL, NULL, 'Roxbury', 'WI', NULL, NULL, NULL, 'Private Party', NULL),
(92, 'Private Party', '1195 Apache Lane', NULL, 'Nakoosa', 'WI', '54457', NULL, NULL, NULL, 'lakearrowhead-golf.com/'),
(94, 'Pillars Pub', '225 S 5th Ave', NULL, 'West Bend', 'WI', '53095', NULL, '(262) 353-9333', NULL, NULL),
(95, 'Art Fair on the Square', NULL, NULL, 'Madison', 'WI', NULL, NULL, NULL, 'State Street Stage Music\r\nArt Fair on the Square , Madison', 'www.mmoca.org/art-fair'),
(96, 'KEVA Sports Center', '8312 Forsythia St', NULL, 'Middleton', 'WI', '53562', 'David O''Keefe', '608,662,7529', 'KEVA Sports Center\r\nKEVA has newly resurfaced courts to play the only indoor soccer game sanctioned by FIFA...Futsal! Youth and adult leagues are available and there are many promotions to take advantage of. Click ''Leagues'' and then youth or adult futsal ', 'www.kevasports.com/');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
