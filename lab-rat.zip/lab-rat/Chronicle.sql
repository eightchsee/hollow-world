-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 03, 2015 at 02:35 PM
-- Server version: 5.5.40-36.1-log
-- PHP Version: 5.4.23

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `redhotra_rattlers`
--

-- --------------------------------------------------------

--
-- Table structure for table `Chronicle`
--

DROP TABLE IF EXISTS `Chronicle`;
CREATE TABLE IF NOT EXISTS `Chronicle` (
  `ID` int(6) NOT NULL AUTO_INCREMENT,
  `Date` date NOT NULL DEFAULT '0000-00-00',
  `Title` varchar(50) NOT NULL DEFAULT '',
  `Body` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `Chronicle`
--

INSERT INTO `Chronicle` (`ID`, `Date`, `Title`, `Body`) VALUES
(14, '2005-10-17', 'Back With A Bite in ‘05', 'Somewhere between SHeDAISY and Delbert McClinton, you''ll find what Madison, Wisconsin''s multi-award winning band Rachelle & The Red Hot Rattlers call "Country with a bite!" \r\n\r\nYou won''t find steel guitar or fiddle on stage at a Rattlers show, as the band draws on influences like Linda Ronstadt, Faith Hill, Delbert McClinton, Sugarland and Shania to define their sound. "We''re not really a twang band," says Rachelle when asked about the band''s Country identity. "People who aren''t necessarily Country fans tell us they love the band," she adds. \r\n\r\nThe Rattlers return to the Madison scene after a 5-year break, having performed at nearly every major festival in South-Central Wisconsin and raking in numerous awards throughout the state in the late ''90s. "It''s great to be back with this group of people. Our first rehearsal felt like only a few months had passed," says drummer Ron Granberg. "We just missed the fun of the festivals, and people kept asking when we were coming back. Well, here we are!" \r\n\r\nMadison''s Country Q106 invited Rachelle & The Red Hot Rattlers back to the Taste of Madison in 2005 for their first show of the year. Within a month, the band was added to the Madison Country Music Awards ballot for Local Country Group of the Year and Female Vocalist of the Year. "I''m a little shocked," said Rachelle, despite the 6 MCMAs she and the band previously won. "We''re humbled by the nominations. It''s a great feeling to be welcomed back this way." \r\n\r\nThe band is currently updating their show to premier in early spring ''06 for the festival season. "Word seems to be getting around. We''re already booking festivals for next summer," says Mike Fiskey, who also returned as the Rattlers'' manager. \r\n'),
(18, '2006-06-27', 'Summertime', 'So much has been going on, where do we start? <br>\r\nWell, first let''s talk about the Rattlers'' newest member, Lisa B! Although she''s the newest part of our family, she has a long affiliation with the band dating back to the mid-90s. Yes, she''s the same Lisa B you know from....well...everywhere! She''s a standout performer, and you should check out her show between Rattlers shows! Why not head over to <A HREF="http://www.meetlisab.com">Lisa''s website</A>?<br>\r\n\r\nWe''ve been busy learning a ton of new material...and sharpening up your favorites too! We don''t want to spoil the surprise, but we can tell you we''ve added tunes by Little Big Town, Miranda Lambert, Keith Urban, Sugarland, Toby Keith, Gretchen Wilson, and much much more! (remember the K-Tel records?...eh..nevermind)<br>\r\n\r\nWe''re very excited about this summer. It kicked off with the Mt. Horeb Frolic on June 2nd, followed up by Arena Firemens Fest, Deerfield Firemens Fest, Sauk County Fair w/<A HREF="http://www.jasonaldean.com">Jason Aldean</A>, Dane County Fair w/<A HREF="http://www.bluecountyfans.com">Blue County</A>, Q106 25th Birthday Bash w/<A HREF="http://www.philvassar.com">Phil Vassar</A>, <A HREF="http://www.madfest.org/taste/">Taste of Madison</A> and probably some shows we don''t know about yet mixed in. If you make it out to a few shows, make sure you come and say hi. Hopefully we''ll see some familiar faces and new friends too!\r\n</p>\r\nBe safe & be well!<br>\r\nRachelle & The Red Hot Rattlers'),
(22, '2012-10-21', 'Summer 2009!', 'Somewhere between Little Big Town and Delbert McClinton, you''ll find what Madison’s country group Rachelle & The Red Hot Rattlers call "Country with a Bite!" \r\n\r\nThe ‘Rattlers Contemporary Country sound may be Top-40, but their roots run deep in R&B and Soul, with two members hailing from the legendary ''Funky Drummer'' Clyde Stubblefield’s Band. Now, the band mixes artists like Linda Ronstadt, Delbert McClinton and Lee Roy Parnell with Little Big Town, Carrie Underwood, Sugarland and Lady Antebellum into their show. "I guess we''re not much of a twang band," says Rachelle when asked about the band''s identity. "People who aren''t necessarily Country fans tell us they love the sound," she adds.\r\nThe band has performed at nearly every major festival in South-Central Wisconsin and raking in numerous awards throughout the state, including being voted Wisconsin’s #1 Country Band at the 1997 & 2010 Hodag Country Festivals. \r\n\r\nSince their return in 2005, the band has opened for artists such as Phil Vassar, Jason Aldean, Little Big Town, Taylor Swift, Jack Ingram, and Eric Church. The band is fronted by Rachelle Fiskey of Sun Prairie; most recently recognized a 7th time as Top Local Female Vocalist of the Year at the 19th annual Madison Country Music Awards.\r\n\r\nRounding out the lineup is Steve Gundlach on Bass, mandolin and vocals, Tom Cobb on Lead guitar and vocals, Al Heidemann on Keyboards, Lisa B on Vocals and Percussion, Kent Zocher on Drums and Dave Allen on Acoustic Guitar & Mandolin.'),
(23, '2014-07-24', 'Our Story as of Summer 2014', 'Somewhere between Little Big Town and Delbert McClinton, you''ll find what Madison''s country group Rachelle & The Red Hot Rattlers call "Country with a Bite!" \r\n<br>The Rattlers Contemporary Country sound may be Top-40, but their roots run deep in R&B and Soul, with two members hailing from the legendary ''Funky Drummer'' Clyde Stubblefield''s Band. Now, the band mixes artists like Linda Ronstadt, Delbert McClinton and Fleetwood Mac with Little Big Town, Miranda Lambert, Sugarland and Lady Antebellum into their show.<br> "I guess we''re not much of a twang band," says Rachelle when asked about the band''s identity. "People who aren''t necessarily Country fans tell us they love the sound," she adds.\r\n<br>The band has performed at nearly every major festival in South-Central Wisconsin and raking in numerous awards throughout the state, including being voted Wisconsin''s #1 Country Band at the 1997 & 2010 Hodag Country Festivals. \r\n<br>Since their return in 2005, the band has opened for artists such as Phil Vassar, Jason Aldean, Little Big Town, Taylor Swift, Jack Ingram, and Eric Church. The band is fronted by Rachelle Fiskey of Sun Prairie; most recently recognized a 7th time as Top Local Female Vocalist of the Year at the 19th annual Madison Country Music Awards.\r\n<br>Rounding out the lineup is Steve Gundlach on Bass, mandolin and vocals, Tom Cobb on Lead guitar and vocals, Al Heidemann on Keyboards, Lisa B on Vocals and Percussion, and Kent Zocher on Drums\r\n<br>We always look forward to seeing fans of good live music and hope to make more of it with you in attendance wherever that might be here in greater southern Wisconsin.\r\nIn the meantime <a href="http://www.facebook.com/pages/Rachelle-and-The-Red-Hot-Rattlers/111112498908001" target="_blank">Find us on Facebook</a>');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
