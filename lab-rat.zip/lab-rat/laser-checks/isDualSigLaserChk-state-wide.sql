cir=>
SELECT ca."countyNo", c."countyName", ca."checkingAcct", ca."dupLaserCheckPrint",
       CASE
         WHEN ca."dupLaserCheckPrint" = 'N' THEN 'Do (N)ot print duplicates'
         WHEN ca."dupLaserCheckPrint" = 'C' THEN 'Print dupli(C)ates to laser check printer'
         WHEN ca."dupLaserCheckPrint" = 'D' THEN 'Print (D)uplicates to user-defined default printer'
         ELSE 'unknown'
       END AS "dupLaserCheckPrint_descr",
       CASE
         WHEN ca."isDualSigLaserChk" = true THEN 'TRUE'
         ELSE 'False'
       END AS "isDualSigLaserChk"
FROM   "ControlAccounting" AS ca
  JOIN "County" AS c ON (ca."countyNo" = c."countyNo")
ORDER BY ca."isDualSigLaserChk", ca."countyNo";

 countyNo | countyName  | checkingAcct | dupLaserCheckPrint |              dupLaserCheckPrint_descr              | isDualSigLaserChk 
----------+-------------+--------------+--------------------+----------------------------------------------------+-------------------
        1 | Adams       | CK           | N                  | Do (N)ot print duplicates                          | False
        2 | Ashland     | CK           | N                  | Do (N)ot print duplicates                          | False
        4 | Bayfield    | CK           | D                  | Print (D)uplicates to user-defined default printer | False
        5 | Brown       | CK           | N                  | Do (N)ot print duplicates                          | False
        6 | Buffalo     | CK           | D                  | Print (D)uplicates to user-defined default printer | False
        7 | Burnett     | CK           | N                  | Do (N)ot print duplicates                          | False
        8 | Calumet     | CK           | N                  | Do (N)ot print duplicates                          | False
        9 | Chippewa    | CK           | N                  | Do (N)ot print duplicates                          | False
       10 | Clark       | CK           | N                  | Do (N)ot print duplicates                          | False
       11 | Columbia    | CK           | D                  | Print (D)uplicates to user-defined default printer | False
       12 | Crawford    | CK           | N                  | Do (N)ot print duplicates                          | False
       13 | Dane        | CK           | N                  | Do (N)ot print duplicates                          | False
       14 | Dodge       | CK           | N                  | Do (N)ot print duplicates                          | False
       15 | Door        | CK           | N                  | Do (N)ot print duplicates                          | False
       16 | Douglas     | CK           | N                  | Do (N)ot print duplicates                          | False
       17 | Dunn        | CK           | D                  | Print (D)uplicates to user-defined default printer | False
       18 | Eau Claire  | CK           | D                  | Print (D)uplicates to user-defined default printer | False
       19 | Florence    | CK           | N                  | Do (N)ot print duplicates                          | False
       20 | Fond du Lac | CK           | D                  | Print (D)uplicates to user-defined default printer | False
       21 | Forest      | CK           | D                  | Print (D)uplicates to user-defined default printer | False
       22 | Grant       | CK           | C                  | Print dupli(C)ates to laser check printer          | False
       23 | Green       | CK           | N                  | Do (N)ot print duplicates                          | False
       24 | Green Lake  | CK           | N                  | Do (N)ot print duplicates                          | False
       25 | Iowa        | CK           | N                  | Do (N)ot print duplicates                          | False
       26 | Iron        | CK           | N                  | Do (N)ot print duplicates                          | False
       27 | Jackson     | CK           | N                  | Do (N)ot print duplicates                          | False
       28 | Jefferson   | CK           | N                  | Do (N)ot print duplicates                          | False
       29 | Juneau      | CK           | D                  | Print (D)uplicates to user-defined default printer | False
       30 | Kenosha     | CK           | N                  | Do (N)ot print duplicates                          | False
       31 | Kewaunee    | CK           | N                  | Do (N)ot print duplicates                          | False
       32 | La Crosse   | CK           | N                  | Do (N)ot print duplicates                          | False
       33 | Lafayette   | CK           | D                  | Print (D)uplicates to user-defined default printer | False
       34 | Langlade    | CK           | D                  | Print (D)uplicates to user-defined default printer | False
       35 | Lincoln     | CK           | D                  | Print (D)uplicates to user-defined default printer | False
       36 | Manitowoc   | CK           | N                  | Do (N)ot print duplicates                          | False
       37 | Marathon    | CK           | D                  | Print (D)uplicates to user-defined default printer | False
       38 | Marinette   | CK           | D                  | Print (D)uplicates to user-defined default printer | False
       40 | Milwaukee   | CK           | D                  | Print (D)uplicates to user-defined default printer | False
       41 | Monroe      | CK           | C                  | Print dupli(C)ates to laser check printer          | False
       43 | Oneida      | CK           | D                  | Print (D)uplicates to user-defined default printer | False
       44 | Outagamie   | CK           | N                  | Do (N)ot print duplicates                          | False
       45 | Ozaukee     | CK           | D                  | Print (D)uplicates to user-defined default printer | False
       46 | Pepin       | CK           | N                  | Do (N)ot print duplicates                          | False
       47 | Pierce      | CK           | D                  | Print (D)uplicates to user-defined default printer | False
       48 | Polk        | CK           | N                  | Do (N)ot print duplicates                          | False
       49 | Portage     | CK           | N                  | Do (N)ot print duplicates                          | False
       50 | Price       | CK           | N                  | Do (N)ot print duplicates                          | False
       51 | Racine      | CK           | N                  | Do (N)ot print duplicates                          | False
       52 | Richland    | CK           | N                  | Do (N)ot print duplicates                          | False
       53 | Rock        | CK           | N                  | Do (N)ot print duplicates                          | False
       54 | Rusk        | CK           | N                  | Do (N)ot print duplicates                          | False
       55 | St Croix    | CK           | N                  | Do (N)ot print duplicates                          | False
       56 | Sauk        | CK           | N                  | Do (N)ot print duplicates                          | False
       57 | Sawyer      | CK           | N                  | Do (N)ot print duplicates                          | False
       59 | Sheboygan   | CK           | N                  | Do (N)ot print duplicates                          | False
       60 | Taylor      | CK           | D                  | Print (D)uplicates to user-defined default printer | False
       61 | Trempealeau | CK           | N                  | Do (N)ot print duplicates                          | False
       62 | Vernon      | CK           | D                  | Print (D)uplicates to user-defined default printer | False
       63 | Vilas       | CK           | D                  | Print (D)uplicates to user-defined default printer | False
       64 | Walworth    | CK           | N                  | Do (N)ot print duplicates                          | False
       66 | Washington  | CK           | N                  | Do (N)ot print duplicates                          | False
       67 | Waukesha    | CK           | N                  | Do (N)ot print duplicates                          | False
       68 | Waupaca     | CK           | N                  | Do (N)ot print duplicates                          | False
       69 | Waushara    | CK           | N                  | Do (N)ot print duplicates                          | False
       70 | Winnebago   | CK           | N                  | Do (N)ot print duplicates                          | False
       71 | Wood        | CK           | N                  | Do (N)ot print duplicates                          | False
       72 | Menominee   | CK           | D                  | Print (D)uplicates to user-defined default printer | False
        3 | Barron      | CK           | N                  | Do (N)ot print duplicates                          | TRUE
       39 | Marquette   | CK           | N                  | Do (N)ot print duplicates                          | TRUE
       42 | Oconto      | CK           | D                  | Print (D)uplicates to user-defined default printer | TRUE
       58 | Shawano     | CK           | N                  | Do (N)ot print duplicates                          | TRUE
       65 | Washburn    | CK           | N                  | Do (N)ot print duplicates                          | TRUE
(72 rows)

