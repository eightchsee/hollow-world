<?php
?>
<!doctype html />
<html>
  <head>
    <meta content="7200" http-equiv="refresh">
    <title>my .pg_service.conf</title>
    <style type="text/css">
      div.listing {font-family: monospace; font-size: 12pt;}
      curr_time {display: block; text-align: center; margin: 10px; color: #c00000; font-size: small; line-height: 1pt; font-style: italic;}
    </style>
  </head>
  <body>
    <!-- div style="font-family: monospace; font-size: 16pt; white-space: pre;">ccapuser@tom_h-c-ubuntu:~$ grep "\[" .pg_service.conf
[bbe-tr-ec]
[bbestage]
[bbe]
[olr-tr-ec]
[olrstage]
[olr]
[costage]
[co-tr-ec]
[co-dev]
[co]
[scca-tr-ec]
[sccadev]
[sccastage]
[scca]
[kenosha-trunk]
[greenlake-trunk]
[ccap2dev1]
[ccap2dev2]
[patches14.3]
[qtest]
[step]
[qtest_dodge]
[preversion]
[training]
[training1]
ccapuser@tom_h-c-ubuntu:~$ psql "service = kenosha-trunk"<div -->
    <div class="listing">ccapuser@tom_h-c-ubuntu:~$ grep &quot;\[&quot; .pg_service.conf</div>
<?php
  $myfile = fopen("/home/ccapuser/.pg_service.conf", "r") or die("Unable to open file!");
  // Output one line until end-of-file
  while(!feof($myfile)) {
    $line = fgets($myfile);
    if (strstr($line, "[") != null) {
      echo "<div class='listing'>" . $line . "</div>";
    }
  }
  fclose($myfile);
?>
    <div class="listing">ccapuser@tom_h-c-ubuntu:~$ psql &quot;service = kenosha-trunk&quot;</div>
<?php
  $curr_date = time();
  $display_curr_date = date('l', $curr_date) . ' ' . date('F', $curr_date) . ' ' . date('jS', $curr_date) . ', ' . date('Y', $curr_date);
  $display_curr_time = (date('h', $curr_date)) . ':' . date('i', $curr_date) . ':' . date('s', $curr_date) . ':' . date('A', $curr_date) . ' ' . date('e', $curr_date);
?>
    <curr_time><?php echo $display_curr_date ?> @ <?php echo $display_curr_time ?></curr_time>  <body>
</html>
