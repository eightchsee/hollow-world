-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 03, 2015 at 02:34 PM
-- Server version: 5.5.40-36.1-log
-- PHP Version: 5.4.23

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `redhotra_rattlers`
--

-- --------------------------------------------------------

--
-- Table structure for table `Band`
--

DROP TABLE IF EXISTS `Band`;
CREATE TABLE IF NOT EXISTS `Band` (
  `ID` bigint(16) NOT NULL AUTO_INCREMENT,
  `FullName` varchar(255) DEFAULT NULL,
  `Description` text,
  `Quote` varchar(255) DEFAULT NULL,
  `Instruments` varchar(255) DEFAULT NULL,
  `EmailAddress` varchar(255) DEFAULT NULL,
  `PhotoName` varchar(255) DEFAULT NULL,
  `Link1` varchar(255) DEFAULT NULL,
  `Link2` varchar(255) DEFAULT NULL,
  `Link3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `Band`
--

INSERT INTO `Band` (`ID`, `FullName`, `Description`, `Quote`, `Instruments`, `EmailAddress`, `PhotoName`, `Link1`, `Link2`, `Link3`) VALUES
(19, 'Al Heidemann', 'Between the end of WW2 and 1950 there was every kind of music imaginable at any given time on the Top 20 A.M. Radio charts and Jukeboxes.\r\nI wasnt born until 1950, but the seeds were already sewn. Mom was a DJ, Her dad was a Big Band Leader and her brother an aspiring Jazz Pianist.\r\nBy the time I was born, there was a maintained collection of never less than 500 78 rpm records in the house. Thats 1000 sides.\r\nI memorized the labels on them before I could read. I''d wear the records out and mom would bring home more.\r\nWhen I was 4 or 5 I saw JoAnne Castle for the first time on the Lawrence Welk show playing the Accordion , Flight of the Bumblebee with her right hand and this impossible " Boogie Woogie" thing with her left.\r\nMelody, Bass and Chords all on this box strapped on. I was IN LOVE!\r\nIn 1957 I placed second  in Milwaukee at the Wis. state Accordion festival among 500 student contestants. \r\nDizzy Fingers at age 10, and Trieste Overture at 12.\r\nThen came Rock and Roll, and with Accordion teachers getting harder to find, I woodshedded the Bass and Hammond Organ thinking maybe I''d be more marketable one day.\r\nThen came Middle and Highschool. I had crooked teeth back then,so Horns weren''t in the cards so Drums and Percussion in the High School band rounded things out.\r\nThe first serious road gig was 1966 in High school with Eddie  and the Calientys,Cynthia and the Soul Asylum after that.Then came a band called Sound Corporation, after which,\r\nIn 1970 or so, I found myself working with our present day Bass Player Steve Gundlach in a band called Pride Street.\r\nMoondance was my 70''s Piano gig,(they are still playing),Studying College level music theory and the American Flyer Band in the 80''s.\r\nThe 90''s was the Dry Bean house band, Neon Cactus after that,Swing West followed and then finally Rachelle in1995.\r\nThen in 2000, I joined up with Brent Clausons Dinner Theater Music Show in Coloma ,Wis.and still do that during the week, playing ALL of the instuments Ive learned.\r\nFavoite Pianist, Art Tatum\r\nFavorite Organist, Virgil Fox \r\nFavorite Accordionist, Richard Galliano\r\nFavorite Guitarist, Angello DeBarre \r\nFavorite Drummer, Buddy Rich\r\nFavorite Bassist, Richard Davis\r\nFavorite Vocalist,K.D.Lang\r\nFavorite influencial Band most people can relate to, Little Feat\r\nI could go on and on.......', 'Plenty of great seats STILL available!!', 'Pianos, Organ, Synthesizer, Accordion', 'alheidemann@frontier.com', 'al.jpg', 'www.clausonfamilymusicshows.com', 'www.jbmusicinc.net/default.asp', 'www.wwoz.org'),
(15, 'Tom Cobb', 'A long time veteran of the Madison area music scene, Tom''s musical roots extend back farther than he''d care to admit. That said, suffice it to say that late 60''s and early 70''s rock, pop, blues, and folk music all combined to influence Tom''s unique approach to guitar playing in particular and to the art of music and entertainment generally.\r\n\r\nTom''s claim to fame, prior to becoming the latest "Red Hot Rattler", goes back some time to the latter half of the 1980''s when he was a member of local favorites "The Cheeters". This is the band that appeared on the Television Show "Star Search".\r\n\r\nThere were a few bands before and after that time in his musical life (including a short stint in a re-formed "Cheeters" with both Rachelle and Lisa) but sometime in the middle 90''s, Tom had departed the music scene (much to his chagrin, the music scene carried on successfully without him).\r\n\r\nIn the winter of 2011, Lisa met with Tom and (as she had several times before) tried to convince him to get back into the arena of playing music in public. She told him that the Rattlers were looking to fill in a position on guitar. After some coaxing, Tom agreed to come on by for a practice session and see how it all felt. Long story short, by April of that year, Tom was starting his time as a member of a great local band.\r\n\r\nIt must be noted, a major thank-you goes to Mr. Scott Miller whose very big musical shoes Tom was tasked with filling. Scott had moved on to Nashville TN to pursue his musical career but in order to facilitate Tom''s transition into becoming a full-fledged "Rattler", Scott returned to share guitar "duties" on several of the early dates after Tom started with the group. For this Tom says: "Couldn''t have done it without ya Scott. Thanks a ton brother!!".\r\n\r\nTom also wants to say thanks to the "Rattlers" for welcoming him into the fold. He feels blessed and honored to be part of this family.', 'Never be afraid to be part of a community and to offer help to and accept help from others.', 'Lead Guitar/Vocals', 'heibercobb@charter.net', 'tom.jpg', NULL, NULL, NULL),
(20, 'Kent Zocher', NULL, NULL, 'Drums', NULL, 'kent.jpg', NULL, NULL, NULL),
(5, 'Rachelle Fiskey', NULL, NULL, 'Vocals, Rythm Guitar', NULL, 'rachelle.jpg', NULL, NULL, NULL),
(7, 'Steve Gundlach', 'After seeing the Beatles on TV I had to be a musician! That started it all.\r\nI started playing gigs at the age of 15 in and around southern Wisconsin. Started and played in the Abracadabra band which played the area for 13yrs(the rest is history). I''ve played all kinds of music over the years but find my self drawn to anything with strong vocal harmonies.\r\nI''ve just recently started to play a little mandolin, that is a challenge!\r\nInfluences...\r\nWow there''s a lot of them.\r\nSteely Dan, The Beatles, Billy Joel, Delbert McClinton, The Eagles, Animal Logic, Kansas, Edith Piaf... the list never ends.\r\nI''m influenced by everything I listen to.\r\nThe Rattlers are my second family. We are a little different than most bands of today. We work well together and strive to be the best we can but have fun doing it as well.I have the pleasure of playing with some of the finest musicians in Wisconsin.\r\nKent is a monster on drums, between Lisa and Al the two of them can play just about everything, Tom''s got "THE" guitar sound, Dave is great on the acoustic guitar and Mando, and singing with Rachelle and the rest of the band is heaven.\r\nI can think of no where else I''d rather be.\r\n', 'Bass player''s like it on the bottom!', 'Bass,Mandolin,Vocals,Guitar', 'steve@redhotrattlers.com', 'steve.jpg', NULL, NULL, NULL),
(9, 'The Band', '<b>FOR OUR FANS...</b>\r\n\r\nWhat can one say about you, the fantastic people of Southern Wisconsin? You come out and party hard when the summer rolls around, but you come out and support your neighbor in times of need too. It''s a great privilege to play each and every show...we''ll never take that for granted.\r\n\r\nWe''ve been fortunate to be a part of some amazing events along the way, and NONE of it would be possible without your support. Below is a list of some memorable events that were made possible by the best fans a group could ask for!! Maybe you were at a few of these shows?\r\n\r\n<b>ACCOMPLISHMENTS</b>\r\n\r\nVoted Wisconsin’s #1 Country Band at the Hodag Country Festival in Rhinelander, WI\r\n7-Time Madison Female Vocalist of the Year, MCMAs\r\n2-Time Local Country Group of the Year, MCMAs\r\nQ-106 Pick-Off Band of the Year\r\nWYOU TV Show “Worth Watching”(still plays our Christmas Special of a few years back during the Chritmas Holiday) \r\nUrban Theater summer ''07\r\n\r\n<b>OPENED SHOWS FOR THE FOLLOWING NATIONAL ACTS</b>\r\n\r\nMartina McBride • Jason Aldean • Blue County • Phil Vassar • Little Big Town  • Steve Azar • Jack Ingram • Katrina Elam • Taylor Swift • Jessica Andrews • Tracy Byrd• Ryan Shupe and the Rubberband • Hanna McEuen • Sammy Kershaw • Trace Adkins • Lee Roy Parnell • Doug Stone • Sons of the Desert\r\n\r\n<b>PAST FESTIVALS AND SPECIAL EVENTS</b>\r\n\r\n \r\nMt. Horeb Frolic\r\nMt. Horeb FDMH Muster\r\nMt. Horeb Firemen’s Fest\r\nDeerfield Firemen''s Festival\r\nCottage Grove Firemen’s Festival\r\nArena Firemen''s Festival\r\nBlack Earth Firemen''s Festival\r\nVerona Hometown Days\r\nWaunafest\r\nDodgeville Festival\r\nLake Mills Festival\r\nOl’ Fitchburg Days\r\nMiddleton Good Neighbor Fest\r\nEdgerton Tobacco Heritage Days\r\nSauk City Fire on the River\r\nSauk Prairie Cow Chip Throw\r\nSauk County Fair\r\nDane County Fair\r\nSun Prairie St. Albert’s Festival\r\nSun Prairie Cornfest\r\nSun Prairie Angell Park Speedway Events\r\nStar Spangled Celebration - Richland Center\r\nQ106 25th Birthday Bash\r\nQ106 Madison Country Music Awards \r\nQ106 Stage - Taste of Madison\r\nHodag Country Fest - Rhinelander\r\nAlliant Expo Center – Classic Car Show\r\nUW Badger Bash – W Club Pre-Game\r\nUW Comprehensive Cancer Center Benefit\r\nStoughton Tornado Relief Benefit\r\nNBC 15 News at 5 - Live Performance \r\n', NULL, NULL, NULL, 'theband.jpg', NULL, NULL, NULL),
(13, 'Lisa B', NULL, NULL, ' Vocals and Percussion', NULL, 'lisa.jpg', 'www.meetlisab.com', NULL, NULL),
(14, 'Dave Allen', NULL, NULL, 'Guitar & Mandolin', NULL, NULL, NULL, NULL, NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
