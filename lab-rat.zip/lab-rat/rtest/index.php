<?php require_once('Connections/content.php'); ?>
<?php
// declare vars and select content
//mysql_select_db($database_content, $content);

$sql_focus = "SELECT * FROM Band WHERE ID = 13";
//$focus = mysql_query($sql_focus, $content) or die(mysql_error());
$focus = mysqli_query($connection, $sql_focus) or die(mysqli_error());
$lb_row_focus = mysqli_fetch_assoc($focus);
mysqli_free_result($focus);


$sql_focus = "SELECT * FROM Band WHERE ID = 15";
//$focus = mysql_query($sql_focus, $content) or die(mysql_error());
$focus = mysqli_query($connection, $sql_focus) or die(mysqli_error());
$tc_row_focus = mysqli_fetch_assoc($focus);
mysqli_free_result($focus);

$sql_focus = "SELECT * FROM Band WHERE ID = 19";
//$focus = mysql_query($sql_focus, $content) or die(mysql_error());
$focus = mysqli_query($connection, $sql_focus) or die(mysqli_error());
$ah_row_focus = mysqli_fetch_assoc($focus);
mysqli_free_result($focus);


?>
<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <title>The Rattlers</title>
    <script type="text/JavaScript" src="inc/rollovers.js"></script>
    <link href="inc/sitestyle.css" rel="stylesheet" type="text/css">
    <style type="text/css">
      ul.top-nav {
        width: <?php echo (0.7153 * 6) ?>in;
      }

      div.tom_descr {
        display: none;
        padding: 0 0 2px 3px;
        border: 1px solid #F00;
        min-height: 30px;
        min-width: 90px;
        /* margin-left: 50px; */
      }
      a:hover + div.tom_descr {
        display: block;
      }
    </style>
    <link rel="shortcut icon" href="http://localhost/rattlers/dotcom/favicon.ico" />
  </head>

  <body>
    <div id="header">
      <div id="header_inner">
        <?php include("inc/new_menu.php"); ?>
      </div>
    </div>
    <div id="wrapper">
      <?php
      $w_var = 0.60;
      $h_var = 0.70; ?>
<div style="width: <?php echo ( (1075 - (1075 * $w_var)) + 22 ) ?>px; margin: auto; margin-top: 0;">
        <img src="../images/rattler_logo_2014.jpg" width="<?php echo ( (1075 - (1075 * $w_var)) + 22 ) ?>" height="<?php echo (520 - (520 * $h_var)) ?>" />
        <div style="font-style: italic; text-align: center; font-weight: bold; color: #e3ab57; font-size: larger; letter-spacing: 6px; padding: 3px 0;">Country With A Bite!</div>
        <!-- h2 style="font-style: italic; text-align: center; color: #e3ab57;">Country With A Bite!</h2 -->
      </div>
      <div style="border-top: thin solid #E3AB57; margin-bottom: 3px;"></div>
      <!-- img src="http://placehold.it/960x150" / -->
      <!-- if <?php echo (1075 * $w_var) ?> is <?php echo $h_var ?>% of 1075 then reducing the image width by that amount would leave <?php echo (1075 - (1075 * $w_var)) ?> -->
      <!-- if <?php echo (520 * $h_var) ?> is <?php echo $w_var ?>% of 520 then reducing the image width by that amount would leave <?php echo (520 - (520 * $h_var)) ?> -->
      <!-- div style="color: #ff0; border-top: thin solid #ff0;">if <//?php echo (1075 * $w_var) ?> is <//?php echo $h_var ?>% of 1075 then reducing the image width by that amount would leave <//?php echo (1075 - (1075 * $w_var)) ?></div -->
      <!-- div style="color: #ff0;">if <//?php echo (520 * $h_var) ?> is <//?php echo $w_var ?>% of 520 then reducing the image width by that amount would leave <//?php echo (520 - (520 * $h_var)) ?></div -->
      <img src="../images/rattlers-r.png" height="175" width="91"  />

      <img src="../images/kent-z-02.jpg"  height="175" width="125" title="Kent: Drums, Vocals, Percussion" />

      <img src="../images/steveg-01.jpg"  height="175" width="125" title="Steve: Bass, Vocals, Mandolin" />

      <img src="../images/chell-01.jpg"   height="175" width="125" title="Rachelle: Vocals, Rhythm Guitar" />

      <a><img src="../images/lisab-01.jpg"   height="175" width="125" title="Lisa: Vocals, Percussion, Flute" /></a>
      <div class="tom_descr"><?php echo str_replace("\n","<br>",$lb_row_focus['Description']); ?></div>

      <a><img src="../images/al-h-01.jpg"    height="175" width="125" title="Al: Keyboards, Accordion" /></a>
      <div class="tom_descr"><?php echo str_replace("\n","<br>",$ah_row_focus['Description']); ?></div>

      <a><img src="../images/tom-01.jpg"     height="175" width="125" title="Tom: Guitars, Vocals" /></a>
      <div class="tom_descr"><?php echo str_replace("\n","<br>",$tc_row_focus['Description']); ?></div>

      <img src="../images/rattlers-r.png" height="175" width="91"  />
      
      <p>
        Move the mouse pointer into the text area to fire the onmouseover event. Move 
        it out to clear the text.
        <textarea name="txtMouseTrack" 
          onmouseover="this.value='onmouseover fired'" 
          onmouseout="this.value=''">
        </textarea>
      </p>
      <div>
        <img src="../../images/main/logo_left.gif" /><img src="../../images/main/logo_main.gif" />
        <img src="../../rattlers/images/logo.gif" />
      </div>
    </div>
  </body>
</html>
