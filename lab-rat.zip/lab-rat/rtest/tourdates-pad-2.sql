-- Wed 25 Jul 2018 11:36:44 AM CDT 

`ID`, `VenueID`, `Date`, `Time`, `Title`, `CoverCharge`, `Description`


SELECT TourDates.ID,TourDates.Date,
       Venues.Name,Venues.City
FROM TourDates,Venues WHERE Venues.ID = TourDates.VenueID AND `Date` >= '". date('Y-m-d') ."' AND OffDate = 0 ORDER BY `Date` ASC LIMIT 5

SELECT td."ID",td."Date",
       v."Name",v."City"
FROM   "TourDates" AS td
  JOIN "Venues"    AS v ON (v."ID" = td."VenueID")
WHERE  "Date" >= CURRENT_DATE
  AND  "OffDate" = 0
ORDER BY "Date" ASC LIMIT 5


SELECT td.`ID`,td.`Date`,
       v.`Name`,v.`City`
FROM   `TourDates` AS td
  JOIN `Venues` AS v ON (
       v.`ID` = td.`VenueID`
  )
WHERE  `Date`    >= CURRENT_DATE
  AND  `OffDate` =  0
ORDER BY `Date` ASC LIMIT 5
