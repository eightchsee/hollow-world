<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional //EH" "http://www.w3.org/TR/html4/loose.dtd">

<html lang="en">
  <head>
    <title>Form Processing</title>
    <!-- see: https://www.youtube.com/watch?v=OxZd6w_4XY0&list=PLkafFmR_hW8Pa3_jcrncS4R9LLysK-A8n&index=12 -->
  </head>
  <body>
    
    <pre>
<?php
  print_r($_POST);
?>
    </pre>
    <br />
<?php
  // set default values
  if (isset($_POST["username"])) {
    $username = $_POST["username"];
  } else {
    $username = "";
  }
  if (isset($_POST["password"])) {
    $password = $_POST["password"];
  } else {
    $password = "";
  }
?>

<?php
  // set default values using ternary operator
  //   boolean_test ? value_if_true : value_if_false
  $username = isset($_POST['username']) ? $_POST['username'] : "";
  $password = isset($_POST['password']) ? $_POST['password'] : "";
?>

<?php
  // detect form submission
  if (isset($_POST['submit'])) {
    echo "form was submitted";
  }
?>

<?php
  echo "{$username}: {$password}";
?>
  </body>
</html>