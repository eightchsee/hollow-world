SELECT ID, VenueID, `Date`, `Time`, Title, Description
FROM   `TourDates`
WHERE  VenueID IN (SELECT ID FROM `Venues` WHERE City LIKE '%iddleton%')
ORDER BY `Date` DESC
-- =====================================================================================================================
SELECT td.ID, td.`Date`, td.`Time`, v.Name, v.City, td.Title, td.Description
FROM   TourDates AS td
  JOIN Venues AS v ON (v.ID = td.VenueID)
WHERE  td.`Date` >= DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY) AND  OffDate = 0
ORDER BY td.`Date`
-- =====================================================================================================================
SELECT td.ID, td.VenueID, td.`Date`, td.`Time`, v.Name, v.City, td.Title, td.Description
FROM   TourDates AS td
  JOIN Venues AS v ON (v.ID = td.VenueID)
WHERE  (
           td.`Date` >= DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY)
        OR td.VenueID IN (SELECT v2.ID FROM `Venues` AS v2 WHERE v2.City LIKE '%iddleton%')
       )
ORDER BY td.`Date`
-- =====================================================================================================================
http://backstage.redhotrattlers.com

http://stats.redhotrattlers.com

SELECT td.ID, td.VenueID, td.`Date`, td.`Time`, v.Name, v.City, td.Title, td.Description
FROM   TourDates AS td
  JOIN Venues AS v ON (v.ID = td.VenueID)
WHERE  td.`Date` >= DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY) AND  OffDate = 0
ORDER BY td.`Date`


