<?php require_once('Connections/content.php'); ?>
<?php
  $query  = "SELECT ID, FullName, Instruments, EmailAddress, PhotoName ";
  $query .= "FROM   band ";
  $query .= "WHERE  ID IN(5,7,13,15,19,20) ";
  $query .= "ORDER BY ID;";
/*
ID
FullName
Description
Quote
Instruments
EmailAddress
PhotoName
Link1
Link2
Link3
*/
  $result = mysqli_query($connection, $query);
  $result2 = mysqli_query($connection, $query);
  // Test if there was a query error
  if (!$result) {
    echo $query . "<br />";
    die("Database query failed.");
  }
?>
<?php 
  $days_counts = array(0=>31,1=>28,2=>31,3=>30,4=>31,5=>30,6=>31,7=>31,8=>30,9=>31,10=>30,11=>31);
  $day_labels = array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
  $mo = date('m');
  $yr = date('Y');
  if ( isset($_GET['mth']) ) {
    $mo = $_GET['mth'];
  }
  if ( isset($_GET['yyyy']) ) {
    $yr = $_GET['yyyy'];
  }
  function link2today ($mm, $yy) {
    $curr_date = time();
    $display_curr_date = date('l', $curr_date) . ' ' . date('F', $curr_date) . ' ' . date('jS', $curr_date) . ', ' . date('Y', $curr_date);
    $m = date('m', $curr_date);
    $y = date('Y', $curr_date);
    if($m == $mm && $y == $yy) {
      echo '<span style="color: #c00000;">' . $display_curr_date . '</span>';
    }
    else {
      echo '<a href="' . $_SERVER['PHP_SELF'] .' ">' . $display_curr_date . '</a>';
    }
  }
  function prev_month($mnth) {
    if($mnth == 1) echo 12;
    else echo $mnth - 1;
  }
  function next_month($mnth) {
    if($mnth == 12) echo 1;
    else echo $mnth + 1;
  }
  function get_year_left($mnth, $yy) {
    switch ($mnth) {
      case  1: echo $yy - 1; break;
      default: echo $yy;
    }
  }
  function get_year_rght($mnth, $yy) {
    switch ($mnth) {
      case 12: echo $yy + 1; break;
      default: echo $yy;
    }
  }
  function check_leap_year($d) {
    if(date('L', $d) == 1) {return 'yes';}
    else {return 'no';}
  }

  $date = mktime(0,0,0, $mo, 1, $yr);

  if (check_leap_year($date) == 'yes') {
    $days_counts[1] = 29;
  }

  //This puts the day, month, and year in seperate variables 
  $day = date('d', $date) ; 
  $month = date('m', $date) ; 
  $year = date('Y', $date) ;

  //Here we generate the first day of the month 
  $first_day = mktime(0,0,0,$month, 1, $year) ; 

  //This gets us the month name 
  $month_name = date('F', $first_day) ;

  //Here we find out what day of the week the first day of the month falls on 
  $day_of_week = date('D', $first_day) ;

  //Once we know what day of the week it falls on, we know how many blank days occure before it. If the first day of the week is a Sunday then it would be zero
  $blank = date('w', $first_day);
  //We then determine how many days are in the current month
  $days_in_month = cal_days_in_month(0, $month, $year) ;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta content="7200" http-equiv="refresh">
    <title><?php echo $month_name . ' - ' . $year; ?></title>
    <link href="css/php-cal.css" type="text/css" rel="stylesheet" />
    <script src="script/datestuff.js" type="text/javascript"></script>
    <script type="text/javascript">
      function mark_day(dy, m, y, txt) {
        var elm;
        var dt = new Date();
        var mth = dt.getMonth() + 1;
        var yr = dt.getFullYear();
      //  alert(dt + "\n" + "  m: " + m + "\n" + "mth: " + mth + "\n" + "y: " + y + "\n" + "yr: " + yr + "\n" + "txt: " + txt);
        if (y == yr) {
          var d = parseInt(dy, 10);
      //    alert(m + "-" + d + "-" + y);
          elm = document.getElementById(d);
         // elm.style.backgroundColor="#0F0";
          elm.innerHTML = elm.innerHTML + '<p style="color: #f00; font-size: 7.5pt; font-weight: normal;">' + txt +'</p>';
        }
      }
    </script>
    <style type="text/css">
    </style>
  </head>
<?php
  $file = "state-holidays.txt";
  $stateholidays = file_get_contents($file);
  // echo '<p>' . $stateholidays . '</p>';
  $holidays = explode("\r\n", $stateholidays);
  //$days = array();
  //$days_txt = array();
  $dayz = array();
  $idx = 0;
  foreach ($holidays as $holiday) {
    $holiday_mnth = explode('-', substr($holiday, 0, 10))[1];

    if ($holiday_mnth == $month) {
      $dayz[$idx] = explode('-', substr($holiday, 0, 10))[2];
      $dayz_txt[$idx] = substr($holiday, strpos($holiday, "=")+1);
      echo '  <!-- holiday_mnth: ' . $holiday_mnth . '; holiday_day: ' . $dayz[$idx] . '; idx: '. $idx . '; holiday: ' . substr($holiday, strpos($holiday, "=")+1) . ' -->'; echo "\n";
      $idx++;
    }
  }
?>
<?php
  if(count($dayz) > 0) {
?>
  <!-- <body onload='st_holiday(<//?php echo json_encode($dayz) . ', ' . $month . ', ' . $year . ', ' . json_encode($dayz_txt); ?>); mark_day(5, 01, 2015, "rachelle.jpg"); mark_day(27, 01, 2015, "lisa.jpg")'> -->
  <body onload='st_holiday(<?php echo json_encode($dayz) . ', ' . $month . ', ' . $year . ', ' . json_encode($dayz_txt); ?>);
                <?php while($band_member = mysqli_fetch_assoc($result)) { ?> mark_day( <?php echo $band_member["ID"] . ', ' . $mo . ', ' . $yr . ', "' . $band_member["FullName"] . '"';?> );<?php } ?>'>
<?php
  }
  else {
?>
  <body onload='setit(<?php echo $mo . ', ' . $yr; ?>);
                <?php while($band_member = mysqli_fetch_assoc($result)) { ?> mark_day( <?php echo $band_member["ID"] . ', ' . $mo . ', ' . $yr . ', "' . $band_member["FullName"] . '"';?> );<?php } ?>'>
<?php
  }
?>
    <ul style="float: left;">
<?php
  // 3. Use returned data (if any)
  //while($band_member = mysqli_fetch_row($result)) {
  while($band_member = mysqli_fetch_assoc($result2)) {
    // output data from each band_member
    /*var_dump($band_member);
    echo "<hr />";*/
    $id = $band_member["ID"];
    $photo_name = $band_member["PhotoName"];
?>
      <li><?php echo $band_member["FullName"] . " (". $band_member["ID"] .")"; ?></li>
      <script type="text/javascript">mark_day(<?php echo $id . ', ' . $mo . ', ' . $yr . ', "' . $photo_name . '"'; ?>)</script>
<?php

  }
?>
    </ul>
<?php
  // 4. Release returned data
  mysqli_free_result($result);
?>



    <div id="page-head"><?php echo $year; ?></div>
    <div id="today_date">Today&apos;s Date: <?php link2today($mo, $yr); ?></div>
    <table>
      <tr id="month-heading">
        <th><a href="<?php echo $_SERVER['PHP_SELF']; ?>?mth=<?php prev_month($mo); ?>&amp;yyyy=<?php get_year_left($mo, $yr); ?>" class="prev_next">&lt;</a></th>
        <th colspan="5"><?php echo $month_name; ?></th>
        <th><a href="<?php echo $_SERVER['PHP_SELF']; ?>?mth=<?php next_month($mo); ?>&amp;yyyy=<?php get_year_rght($mo, $yr); ?>" class="prev_next">&gt;</a></th>
      </tr>
      <tr class="day-label">
<?php
  foreach ($day_labels as $day_label) {
?>
        <th><?php echo $day_label ?></th>
<?php
  }
?>
      </tr>
<?php //This counts the days in the week, up to 7
  $day_count = 1;
?>
      <tr class="curr-month-days">
<?php //first we take care of those blank days
  $prev_mo = $mo - 1;
  if ($prev_mo == 0) {$prev_mo = 12;}
  $left_over_prev_days_start = ($days_counts[$prev_mo - 1] - $blank) +1;

  while ( $blank > 0 ) {
  $blank--;
  $day_count++;
?>
        <td class="pre-post"><?php echo $left_over_prev_days_start; ?></td>
<?php 
   $left_over_prev_days_start++;
  } 
  //sets the first day of the month to 1 
  $day_num = 1;

  //count up the days, until we've done all of them in the month
  while ( $day_num <= $days_in_month ) {
    if ($day_count == 7) {
?>
        <td id="<?php echo $day_num; ?>" class="weekend"><?php echo $day_num; ?></td>
<?php 
  } // if ($day_count == 7)
  else {
?>
        <td id="<?php echo $day_num; ?>"><?php echo $day_num; ?></td>
<?php 
  }
  $day_num++; 
  $day_count++;
  //Make sure we start a new row every week
  if ($day_count > 7) {
    $day_count = 1;
?>
      </tr>
<?php 
//  if ( !$day_num > $days_in_month ) {
?>
      <tr class="curr-month-days" key="<?php echo $days_in_month; ?>" key2="<?php echo $day_num; ?>">
<?php
//     }
   } // if ($day_count > 7)
 } // while ( $day_num <= $days_in_month )

  //Finaly we finish out the table with some blank details if needed
  $next_month_day = 1;
  while ( $day_count > 1 && $day_count <= 7 ) {
    if ($day_count == 7) {
 ?>
        <td class="pre-post weekend"><?php echo $next_month_day; ?></td>
<?php 
  }
  else {
?>
        <td class="pre-post"><?php echo $next_month_day; ?></td>
<?php 
    }
  $day_count++;
  $next_month_day++;
  }
//  if ( !$day_num > $days_in_month ) {
?>
      </tr>
<?php
//  }
  mysqli_close($connection);
?>
    </table>
    <p>
      <a href="http://www.goatella.com" target="_blank">Goatella's home page</a><br />
      <a href="https://github.com/Goatella/PHP-Calendar" target="_blank">This calendar on GitHub.</a>
    </p>
  </body>
</html>