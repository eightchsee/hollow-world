<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional //EH" "http://www.w3.org/TR/html4/loose.dtd">

<html lang="en">
  <head>
    <title>Form</title>
    <!-- see: https://www.youtube.com/watch?v=OxZd6w_4XY0&list=PLkafFmR_hW8Pa3_jcrncS4R9LLysK-A8n&index=12 -->
  </head>
  <body>
    
    <form action="form_processing.php" method="post">
      Username: <input type="text" name="username" value="" /><br/>
      Password: <input type="password" name="password" value="" /><br/>
      <br />
      <input type="submit" name="submit" value="Submit" />
    </form>
  </body>
</html>