-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 03, 2015 at 02:32 PM
-- Server version: 5.5.40-36.1-log
-- PHP Version: 5.4.23

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `redhotra_rattlers`
--

-- --------------------------------------------------------

--
-- Table structure for table `WhatsNew`
--

DROP TABLE IF EXISTS `WhatsNew`;
CREATE TABLE IF NOT EXISTS `WhatsNew` (
  `ID` bigint(16) NOT NULL AUTO_INCREMENT,
  `Date` date DEFAULT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Article` text,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=71 ;

--
-- Dumping data for table `WhatsNew`
--

INSERT INTO `WhatsNew` (`ID`, `Date`, `Title`, `Article`) VALUES
(35, '2010-02-28', 'Q106 PICKOFF', 'Well, we are on our way to the Hodag Festival to compete in the state competition.\r\nThanks to all of you who showed up at the Dry Bean Saloon to root for us and support all of the great bands that played!See you in Rhinelander.\r\n'),
(38, '2010-03-08', 'Star Spangled Celebration', 'We will be playing at The Star Spangled Celebration in Richland Center on Sat June 26th (time to be announced).\r\nThe Battle of the bands was alot of fun 10 great bands all with excellent musicians and vocalist.\r\nThanks to all who worked so hard to put on the event especially those from the Star Spangled Celebration and the White house Banquet center in Richland center.\r\nCome on down on June 26th and party!!'),
(39, '2010-03-09', 'DEJOPE Bingo Madison', 'Come on out to Dejope this Friday & Saturday. We will be performing 2 shows each night 8pm to 9:30pm and 10pm to 11:30pm.  '),
(40, '2010-03-17', 'what''s next?', '\r\nHappy St Patrick''s day!\r\nWe had a great time at Dejope, thanks to all who came out to the show\r\nWe will be at The Dry Bean April 17th to help party with the people from the Big horse show at the coliseum see ya there?'),
(41, '2010-04-11', 'Midwest Horse Fair', 'Welcome to all those attending the Midwest Horse Fair at the Allient energy Center On the weekend of April 17 & 18.\r\nHope to see you at the Dry Bean on Saturday the 17th'),
(43, '2010-05-22', 'uw memorial union terrace', 'What a great night at the Memorial union terrace! A perfect night to listen to three bands and have some beers.\r\nThanks to Q106 for putting together another excellent show.and thanks to all who attended ( it was a packed house) '),
(44, '2010-05-28', 'Bratfest', 'Don''t forget Friday May 28 we will be at Bratfest  from 5:40 till 7pm.\r\nCome down to willow island and enjoy the brats and music and help support a good cause.\r\n'),
(45, '2010-06-10', 'Cottage Grove Fire Mans Fest', 'Well it''s been a fine start to summer so far.\r\nWe have some great gig s coming up. Be sure to come out to the Cottage Grove Fire Mans Fest on June 19th 8pm to 12 It''s a gonna be FUN!'),
(46, '2010-06-18', 'Gilda''s Club Madison', 'Stop down July 1st to Gilda''s Club Madison for their Fundraiser event\r\n Lisa, Kent And Steve From The Red Hot Rattlers along with Josh Becker from Cherry pie will be playing.                                               advance tickets call 828 8880\r\nor go to info@gildasclubmadison.org'),
(47, '2010-06-27', 'Star Spangled Celebration', 'We had a great time at SSC on sat. Talk about friendly and helpful people. Everyone from the stage crew to those in charge were wonderful. We especially like the ladies in the VIP tent ( you know who you are) you gals are the best. You made our day! Hope to see you all again soon.\r\nThanks for everything\r\n'),
(48, '2010-06-27', 'Colgate Country Showdown', 'Next up,\r\nManitowoc and the Colgate country showdown.\r\nSat July then Sunday the 4th in Nakoosa at the Trails end Bar,on to Hodag to compete for the state pickoff title on the 9th and finish up our week at the Marquette county fair in Westfield on the 10th, A busy Rattler week!\r\nHope to see you all there!'),
(49, '2010-07-03', 'Colgate country showdown', 'Well, we went to Manitowoc competed int he showdown and WON! Now we go to the State Fair in Milwaukee on AUG 5th to compete in the State competition. Come on down and root for the Rattlers!'),
(50, '2010-07-03', 'Nakoosa Trails end bar', 'We will be at the Trails End Bar in Nakoosa tomorrow July 4th 7 to 11pm.\r\nCome celebrate the 4th with us on their HUGE outdoor patio/bar /stage area, it''s really cool!'),
(51, '2010-07-03', 'Hodag', 'We will be at The Hodag Festival Fri July 9th for the state band competition. We will be performing at 3pm. It''s a great time ,excellent music, food and loads of fun for all.\r\nSat the 11th of July we will be at the Marquette County Fair in Westfield from 8 to 12 Party in Westfield!'),
(52, '2010-07-09', 'Hodag', 'Rachelle & The Red Hot Rattlers\r\nHodag''s 2010 pickof winners!\r\nWisconsin country band of the year 2010'),
(53, '2010-07-09', 'Hodag', 'Rachelle & The Red Hot Rattlers\r\nHodag''s 2010 pickof winners!\r\nWisconsin country band of the year 2010'),
(54, '2010-07-13', 'moving right along', 'Fresh off the win at Hodag we will be at the Dane County Fair this Friday July 16th at 7pm.Opening for Troy Olsen Come on down and "COUNTRY ROCK" with us!'),
(55, '2010-07-18', 'Dane County Fair', 'It was a hot night at the fair, not just the crowd and the band IT WAS HOT!\r\nThanks to all who braved the heat to come out and party.(saw Johnny Masino there!:)\r\nTroy Olsen and his band were great and just a nice bunch of guys. We bonded over a few beers afterwards and made some good Nashville contacts. Hope to see some of them on vacation in Nashville at the end of the month. Check em out next time they are round.'),
(56, '2010-07-18', 'The Club Tavern', 'Wow what a night at the Club Tavern in Middleton.We had allot of guest tamborine players and dancers on stage. We had a  bachelorette party and a 40th birthday group who both danced up a storm. Moose you would have been proud!'),
(57, '2010-08-04', 'Colgate Country Showdown', 'Thursday Aug 5th \r\nRattlers will be in Milwaukee at the State Fair grounds for the Colgate Country Showdown competition\r\n7pm'),
(59, '2010-08-31', 'Taste of Madison', 'Don''t forget to come down to The Taste of Madison Sat Sept 4th at 3pm.\r\nWe will be on the Q106 Stage on the Wisconsin Ave side of the square'),
(60, '2010-09-23', 'Gigs', 'The rattlers will be at the CC Riders club house 1325 Parkside Dr Madison this Friday Sept. 24th from 9 to 12 and Sat. Sept. 25th at the club Tavern in Middleton. Come out and Party with the Band and celebrate the beginning of fall!'),
(61, '2010-09-23', 'This fall ', 'Our guitarist Scott is nearing the end of his Schooling at SAE in Nashville. We will be heading down to do some recording with him in November.\r\nWe will be working on new songs and some originals for the coming year.'),
(62, '2010-11-15', 'Nashville recording trip', 'What a great weekend in Nashville!!! It was too short though. Spent many hours in the studio but made up for it at the clubs listening to lots of excellent music and players.We also got to get up on the stage at the "2nd Fiddle "bar and play a song or 2. There are pics on Steve''s facebook page and we will get some up on the rattler page soon as well. Wish we could spend more time there. '),
(63, '2010-11-27', 'many thanks', 'The Rattlers want to wish everyone a safe and happy Thanksgiving. Remember our troops wherever they may be. And thanks to all who have supported us and come to see us in this past year. It really was a great year for us. Thanks and many blessings to all.'),
(64, '2011-01-05', 'New news', 'The Rattlers will be opening for Frankie Ballard Fri Jan 28th at The Majestic theater on King St. in Madison. We will be joined by our Nashville guitarist Scott Miller. It should prove to be a very special night for all!'),
(65, '2012-11-17', 'Badger Pregame', 'UW FIELDHOUSE Badger Pregame\r\n1450 Monroe St\r\nMadison, WI\r\n11:45 am'),
(66, '2012-11-18', 'back online', 'Sorry if you had problems getting on our web site. We had some malware problems but are now back up and running.\r\nWe are looking forward to working on new material for next year and getting ready to rock.\r\n'),
(67, '2012-11-21', 'Rachelle wins Star 96.3''s female vocal', 'At the Star 96.3 country music awards on Tuesday Nov 20th Rachelle took home the  Country Female vocalist award. That makes 8 with the previous 7 from Q106. Congrats Rachelle!'),
(68, '2013-03-19', 'Rattlers unplugged', 'Rachelle & The Rattlers Unplugged are coming to Columbus! (www.redhotrattlers.com/) Voted best band at last years ''Taste of Madison'' and Rachelle has been voted best local female vocalist 7 times by the CMA!  \r\n\r\nSponsored by the Columbus Masonic Lodge #75  (www.columbus75.com)   \r\n\r\nFriday April 26th at 7 pm.  Kestrel Ridge Golf Club   $20 + 2 drink minimum  Come and listen or dance!   Also, there will be a fish fry previous to the show downstairs at Kestrel Ridge.  \r\n\r\nFor tickets call Bill @ 608-575-5485 or email     info@columbus75.com  '),
(69, '2014-08-30', 'Samples from the Taste of Madison, 2014', 'Hey folks, check out some samples of our show at the Taste of Madison, 2014. See our <a href="/">homepage</a>'),
(70, '2014-12-31', 'New Year''s Eve', 'JOIN US FOR A NEW WAY TO PARTY ON NEW YEAR’S\nEVE!\nAdult Party at KEVA 9p - 1a\nLive Music by Old School w/Lisa B.\nGuest Appearance by Rachelle and the Red Hot Rattlers');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
