-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 03, 2015 at 02:37 PM
-- Server version: 5.5.40-36.1-log
-- PHP Version: 5.4.23

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `redhotra_rattlers`
--

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `photos`
--

INSERT INTO `photos` (`id`, `title`, `description`, `url`, `date`) VALUES
(8, '2005 Madison Country Music Awards', '2005 MCMA', 'http://www.redhotrattlers.com/gallery/05MCMA/', '2005-11-02'),
(4, 'Stoughton Tornado Relief Benefit', 'Contributed photos from the Tornado Relief Benefit in September, 05', '/gallery/Stoughton/', '2005-09-18'),
(9, '2006 Deerfield Firemen''s Festival', '2006 Deerfield Firemen''s Festival', 'http://www.redhotrattlers.com/gallery/06DVFDFest/', '2006-07-08'),
(10, '2006 Sauk County Fair', '2006 Sauk County Fair w/Jason Aldean', 'http://www.redhotrattlers.com/gallery/06SaukCtyFair/', '2006-07-14'),
(11, '2006 Dane County Fair', '2006 Dane County Fair w/Blue County', 'http://www.redhotrattlers.com/gallery/06DCF/', '2006-07-21'),
(12, 'Q106 25th Birthday Bash', 'Q106 25th Birthday Bash w/Phil Vassar', 'http://www.redhotrattlers.com/gallery/06Q106bash/', '2006-08-04'),
(13, '2006 Taste of Madison', '2006 Taste of Madison w/Bomshel', 'http://www.redhotrattlers.com/gallery/06TasteOfMadison/', '2006-09-03'),
(14, '2006 Q106 Madison Country Music Awards', '2006 Q106 Madison Country Music Awards', '06MCMA/', '2006-11-18'),
(15, '2007 Sauk County Fair', '2007 Sauk County Fair w/ Eric Church', '07SCF/', '2007-07-13'),
(16, '2007 Urban Theater', 'Urban Theater taping, July 12 2007', '07UrbanTheater/', '2007-07-12'),
(17, '2007 Taste of Madison', '2007 Taste of Madison w/Carolina Rain, Whiskey Falls', '07TasteOfMadison/', '2007-09-01'),
(18, '2007 Badger Bash', '2007 Badger Bash w/Barry Alvarez & Ron Dayne', '07BadgerBash/', '2007-11-10');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
