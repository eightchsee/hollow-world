<?php
  $curr_date = time();
  $display_curr_date = date('l', $curr_date) . ' ' . date('F', $curr_date) . ' ' . date('jS', $curr_date) . ', ' . date('Y', $curr_date);
  $display_curr_time = (date('h', $curr_date)) . ':' . date('i', $curr_date) . ':' . date('s', $curr_date) . ':' . date('A', $curr_date) . ' ' . date('e', $curr_date);
?>
<!doctype html />
<html>
  <head>
    <meta content="7200" http-equiv="refresh">
    <title>my sql scripts</title>
    <style type="text/css">
      body {font-size: 0.8em; margin: 25px auto auto 100px;}
      curr_time {
        display: block;
        margin-bottom: 10px;
        color: #c00000;
        font-size: small;
        line-height: 1pt;
        font-style: italic;
      }
    </style>
  </head>
  <body>
    <curr_time><?php echo $display_curr_date ?> @ <?php echo $display_curr_time ?></curr_time>
<?php
  // orig file date was Fri Jun  2 14:14:05 CDT 2017
  // changed to correct directory for new PC with (believe it or not) 'theiber' userID
  // on Thu 17 May 2018 08:41:48 AM CDT 
  $dir = '/home/theiber/work/qry-input'; // '/tmp'; // '/home/ccapuser/work/qry-input';
  $files = scandir($dir);
?>
    <pre>
<?php
  // 
  print_r($files);
  if (is_dir($dir)) {
    if ($dh = opendir($dir)) {
      while ( ($file = readdir($dh)) !== false ) {
        $file_parts = pathinfo($file);
        if ($file_parts['extension'] == "sql") {
          echo "<div>" . $file . "</div>" ;
        }
      }
    }
  closedir($dh);
  }
?>
    </pre>
  <body>
</html>
