<?php

?>
<!DOCTYPE html>
<html>
  <head>
    <title>libra emoji {maybe}</title>
    <style type="text/css">
      body {margin: 50px; background-color: #FFF;}
      .moji {font-size: 50pt;}
    </style>
  </head>
  <body>
    <div>
      <a href="http://www.fileformat.info/info/emoji/libra/index.htm" target="_blank">http://www.fileformat.info/info/emoji/libra/index.htm</a>
    </div>
    <div style="margin-bottom: 10px;">
      <a href="http://www.fileformat.info/info/unicode/char/264e/index.htm" target="_blank">http://www.fileformat.info/info/unicode/char/264e/index.htm</a>
    </div>
    <div>:libra:</div>
    <div class="moji">&#x264e;</div>
  </body>
</html>
