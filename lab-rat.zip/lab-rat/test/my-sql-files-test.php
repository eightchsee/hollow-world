<?php
  $curr_date = time();
  $display_curr_date = date('l', $curr_date) . ' ' . date('F', $curr_date) . ' ' . date('jS', $curr_date) . ', ' . date('Y', $curr_date);
  $display_curr_time = (date('h', $curr_date)) . ':' . date('i', $curr_date) . ':' . date('s', $curr_date) . ':' . date('A', $curr_date) . ' ' . date('e', $curr_date);
  
  $dir = '/home/theiber/work/qry-input';
  if ( isset($_GET['dir']) ) {
    $dir = $_GET['dir'];
  }
?>
<!doctype html />
<html>
  <head>
    <meta content="3600" http-equiv="refresh">
    <title>my sql scripts</title>
    <style type="text/css">
      body {font-size: 0.8em; margin: 25px auto auto 100px;}
      curr_time {
        display: block;
        margin-bottom: 10px;
        color: #c00000;
        font-size: small;
        line-height: 1pt;
        font-style: italic;
      }
    </style>
  </head>
  <body>
    <curr_time><?php echo $display_curr_date ?> @ <?php echo $display_curr_time ?></curr_time>
<?php
  // orig file date was Fri Jun  2 14:14:05 CDT 2017
  // changed to correct directory for new PC with (believe it or not) 'theiber' userID
  // on Thu 17 May 2018 08:41:48 AM CDT 
//  $dir = '/home/theiber/work/qry-input'; // '/tmp'; // '/home/ccapuser/work/qry-input';
  $files = scandir($dir,SCANDIR_SORT_NONE);
?>
    <!-- pre -->
<?php
  // 
//  print_r($files);
  if (is_dir($dir)) {
?>
    <h4><?php echo $dir; ?></h4>
<?php
    if ($dh = opendir($dir)) {
      while ( ($file = readdir($dh)) !== false ) {
        $file_parts = pathinfo($file);
//        echo print_r($file_parts);
        // just prior to:Tue 09 Apr 2019 09:44:37 AM CDT - found out how to negate the error that was happening for files w/o extensions (including directories)
        if ( ( isset($file_parts['extension']) ) && ( $file_parts['extension'] == "sql" ) ) {
          // echo "<div><a target='_blank' href='" . $file . "'>". $file ."</a></div>" ;
          echo "<div><a target='_blank' href='file://". $dir. "/" . $file . "'>". $file ."</a></div>" ;
        }
        else {echo "<div style='padding: 3px;'>" . $file_parts['basename'] . " &nbsp;&nbsp;&lt;== non-SQL</div>" ;}
      }
    }
  closedir($dh);
  }
?>
    <!-- /pre -->
    <!--
    created this:              http://thcentre-m910t/lab-rat/test/ZD_78323-bookmark-count.sql
    but needed to create this: http://thcentre-m910t/lab-rat/support/zd-tix/ZD_78323-bookmark-count.sql
    if inputting directory: /opt/lampp/htdocs/lab-rat/support/zd-tix
    
    file:///home/theiber/work/qry-input/PartyQRY.sql
    http://thcentre-m910t/lab-rat/test/PartyQRY.sql
    -->
  <body>
</html>
