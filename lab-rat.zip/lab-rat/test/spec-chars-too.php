<!doctype html />
<html>
  <head>
    <style type="text/css">
      div {margin-top: 0.25in; margin-left: 0.25in;}
      demos {display: table; width: 80%; table-layout: fixed; border-collapse: collapse;}
      demos-r {display: table-row;}
      demos-c {display: table-cell; padding: 2pt; border: thin solid #F00;}
      demos-c.dob::before {content: 'Date of Birth: ';}
      demos-c.sex::before {content: 'Sex: ';}
      demos-c.race::before {content: 'Race: ';}
      demos-c.hair::before {content: 'Hair color: ';}
      demos-c.eye::before {content: 'Eye color: ';}

      demos-c.height::before {content: 'Height: ';}
      demos-c.weight::before {content: 'Weight: ';}
      demos-c.dl-no::before {content: 'DL No: ';}
      demos-c.dl-st::before {content: 'DL State: ';}
      demos-c.exp-date::before {content: 'Exp: ';}

      demos-c.phone::before {content: 'Phone: ';}
      demos-c.ident-char::before,td.ident-char::before {content: 'Other identifying characteristics: ';}
      demos-c.ident-char {-webkit-column-span: 4;}
    </style>
  </head>
  <body>
    <div>&#195;&#162;&#226;&#130;&#172;&#226;&#132;&#162;</div>
    <div></div>
    <p>
      <demos>
        <demos-r>
          <demos-c class="dob">08-07-1969</demos-c>
          <demos-c class="sex">M</demos-c>
          <demos-c class="race">Hispanic</demos-c>
          <demos-c class="hair">Brown</demos-c>
          <demos-c class="eye">Blue</demos-c>
        </demos-r>
        <demos-r>
          <demos-c class="height">5 ft 11 in</demos-c>
          <demos-c class="weight">175 lbs</demos-c>
          <demos-c class="dl-no">A1531657300803</demos-c>
          <demos-c class="dl-st">TX</demos-c>
          <demos-c class="exp-date">10-31-2018</demos-c>
        </demos-r>
        <demos-r>
          <demos-c class="phone">608-555-1212</demos-c>
          <demos-c class="ident-char"></demos-c>
          <!-- td class="ident-char" colspan="3"></td -->
        </demos-r>
      </demos>
    </p>
  </body>
</html>
