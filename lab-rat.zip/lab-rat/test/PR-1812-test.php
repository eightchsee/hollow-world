<html>
  <head>
    <title>PR-1812 Denial of Application for Informal Administration</title>
    <!-- link media="all" title="Common Style" href="classpath:/css/cc-globals.css" type="text/css" rel="stylesheet" />
    <link media="all" title="Common Sign Style" href="classpath:/css/sig-placement.css" type="text/css" rel="stylesheet" />
    <link media="all" title="distribution style" href="classpath:/css/distribution.css" type="text/css" rel="stylesheet" />
    <link media="all" title="Form Specific Style" href="classpath:/css/PR-1812.css" type="text/css" rel="stylesheet" / -->
    <style type="text/css">/* *[style] {background-color: #F96; color: #CF0;} */
          v-sp {background-color: transparent; width: 3pt;}
          /* ol {  background-color: #cf6;} */

          form-create-time-box,
          party-name-box   { /* visibility: visible; */ }</style>
  </head>
  <body>
    <block class="footer">
      <row style="width: 0;">
        <block style="width: 4in;">
          PR-1812(CCAP), 03/2012 Denial of Application for Informal Administration
          <spa-text class="rev-date" />
          <hmo-text class="rev-date" />
        </block>
        <block style="width: 4in;">
          <block style="text-align: right;">§865.08(3), Wisconsin Statutes</block>
        </block>
      </row>
      <row>
        <block style="width: 2.00in;" />
        <modified-text />
        <block style="text-align: right; width: 2.00in;" />
      </row>
    </block>
    <div style="font-style: italic; font-size: 25pt; font-weight: bold; text-transform: uppercase; margin: 10px;">there's nuthin' to print</div>
    <div style="font-style: italic; font-size: 25pt; font-weight: bold; font-family: 'Times New Roman'; text-transform: uppercase; margin: 10px;">there's nuthin' to print</div>
    <div style="font: italic bold 32pt/1.5em sans-serif; text-transform: uppercase; margin: 20px;">there's really nuthin' to print</div>
  </body>
</html>


