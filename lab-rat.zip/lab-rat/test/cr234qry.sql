-- Thu 17 Jan 2019 12:11:27 PM CST 
-- \set county_no 29
-- \set case_no 2011CF000002
-- \i /tmp/cr234qry.sql
--SELECT "c"."countyNo",       "c"."caseNo",       "c"."chargeNo",       "c"."chargeSeqNo",       "c"."dispoCode",       "s"."sentCode",       "s"."len1",       "s"."len1Pd",       "s"."len2",       "s"."len2Pd" --,
--       "cc"."orderSeqNo",
--       "cc"."concurConsecCode"
--FROM   "Charge"      AS "c"
--  JOIN "Supervision" AS "s" ON (
--       "s"."countyNo"    = "c"."countyNo"
--   AND "s"."caseNo"      = "c"."caseNo"
--   AND "s"."chargeNo"    = "c"."chargeNo"
--   AND "s"."chargeSeqNo" = "c"."chargeSeqNo"
--  )
--  LEFT OUTER JOIN "ConcurConsec" AS "cc" ON (
--       "cc"."countyNo"         =  "s"."countyNo"
--   AND "cc"."caseNo"           =  "s"."caseNo"
--   AND "cc"."chargeSeqNo"      =  "s"."chargeSeqNo"
--   AND "cc"."orderSeqNo"       =  "s"."orderSeqNo"
--   AND "cc"."concurConsecCode" IN ('C','S')
--  )
--WHERE ( ("c"."countyNo" = :county_no) AND ("s"."sentCode" IN ('73','91')) )
--  AND ("c"."countyNo"   = :county_no)
--  AND ("c"."caseNo"     = :'case_no')
--ORDER BY "countyNo", "caseNo", "chargeNo", "chargeSeqNo", "dispoCode", "sentCode";


SELECT "c"."countyNo", "c"."caseNo", "c"."chargeNo", "c"."chargeSeqNo", "c"."dispoCode",
       "s"."sentCode", "s"."len1", "s"."len1Pd", "s"."len2", "s"."len2Pd","s"."jdgmtSeqNo","cc"."jdgmtSeqNo","s"."orderSeqNo",
       "cc"."orderSeqNo", "cc"."concurConsecCode"
FROM   "Charge"      AS "c"
  JOIN "Supervision" AS "s" ON (
       "s"."countyNo"    = "c"."countyNo"
   AND "s"."caseNo"      = "c"."caseNo"
   AND "s"."chargeNo"    = "c"."chargeNo"
   AND "s"."chargeSeqNo" = "c"."chargeSeqNo"
   AND (
        ( "s"."sentCode" = '73' AND EXISTS ( SELECT 1
                                             FROM   "Supervision" AS s2
                                               JOIN "Charge"      AS c2 ON (
                                                    (s2."countyNo"    = "c"."countyNo"    AND s2."countyNo"    = c2."countyNo")
                                                AND (s2."caseNo"      = "c"."caseNo"      AND s2."caseNo"      = c2."caseNo")
                                                AND (s2."chargeNo"    = "c"."chargeNo"    AND s2."chargeNo"    = c2."chargeNo")
                                                AND (s2."chargeSeqNo" = "c"."chargeSeqNo" AND s2."chargeSeqNo" = c2."chargeSeqNo") 
                                               )
                                             WHERE s2."sentCode" = '91' ) )
        OR ( "s"."sentCode" = '91' AND EXISTS ( SELECT 1
                                                FROM   "Supervision" AS s2
                                                 JOIN "Charge"      AS c2 ON (
                                                      (s2."countyNo"    = "c"."countyNo"    AND s2."countyNo"    = c2."countyNo")
                                                  AND (s2."caseNo"      = "c"."caseNo"      AND s2."caseNo"      = c2."caseNo")
                                                  AND (s2."chargeNo"    = "c"."chargeNo"    AND s2."chargeNo"    = c2."chargeNo")
                                                  AND (s2."chargeSeqNo" = "c"."chargeSeqNo" AND s2."chargeSeqNo" = c2."chargeSeqNo") 
                                                 )
                                                WHERE s2."sentCode" = '73' ) )
       )
  )
  LEFT OUTER JOIN "ConcurConsec" AS "cc" ON (
       "cc"."countyNo"         =  "s"."countyNo"
   AND "cc"."caseNo"           =  "s"."caseNo"
   AND "cc"."chargeSeqNo"      =  "s"."chargeSeqNo"
   AND "cc"."jdgmtSeqNo"       =  "s"."jdgmtSeqNo"
   AND "cc"."orderSeqNo"       =  "s"."orderSeqNo"
   AND "cc"."concurConsecCode" IN ('C','S')
  )
WHERE ( ("c"."countyNo" = :county_no) AND ("s"."sentCode" IN ('73','91')) )
  AND ("c"."countyNo"   = :county_no)
  AND ("c"."caseNo"     = :'case_no')
ORDER BY "countyNo", "caseNo", "chargeNo", "chargeSeqNo", "dispoCode", "sentCode";

