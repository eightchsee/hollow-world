<?php
  if (isset($_POST['target_db'])) {
    $target_db = $_POST["target_db"];
  }
?>
<!DOCTYPE HTML>
<html>
  <head>
    <title>show client profile</title>
    <style>
      .error {color: #FF0000;}
      .county-profile > a {text-transform: capitalize;}
      ul.in-house {list-style-type: none; font-size: 0.9em; }
      ul.in-house > li {margin-left: -30px; margin-bottom: 5px;}
      ul.in-house a:hover {background-color: #FFFF00; color: #FF0000;}
    </style>
  </head>
  <body>
    <?php
      if (!isset($_POST['submit'])) {
    ?>
    <p>
      <form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
        <div>Counties:</div>
        <select name="target_db">
          <option value="">Select...</option>
          <option value="adams">Adams</option>
          <option value="ashland">Ashland</option>
          <option value="barron">Barron</option>
          <option value="bayfield">Bayfield</option>
          <option value="brown">Brown</option>
          <option value="buffalo">Buffalo</option>
          <option value="burnett">Burnett</option>
          <option value="calumet">Calumet</option>
          <option value="chippewa">Chippewa</option>
          <option value="clark">Clark</option>
          <option value="columbia">Columbia</option>
          <option value="crawford">Crawford</option>
          <option value="dane">Dane</option>
          <option value="dodge">Dodge</option>
          <option value="door">Door</option>
          <option value="douglas">Douglas</option>
          <option value="dunn">Dunn</option>
          <option value="eauclaire">Eau Claire</option>
          <option value="florence">Florence</option>
          <option value="fond du lac">Fond du Lac</option>
          <option value="forest">Forest</option>
          <option value="grant">Grant</option>
          <option value="green">Green</option>
          <option value="greenlake">Green Lake</option>
          <option value="iowa">Iowa</option>
          <option value="iron">Iron</option>
          <option value="jackson">Jackson</option>
          <option value="jefferson">Jefferson</option>
          <option value="juneau">Juneau</option>
          <option value="kenosha">Kenosha</option>
          <option value="kewaunee">Kewaunee</option>
          <option value="lacrosse">La Crosse</option>
          <option value="lafayette">Lafayette</option>
          <option value="langlade">Langlade</option>
          <option value="lincoln">Lincoln</option>
          <option value="manitowoc">Manitowoc</option>
          <option value="marathon">Marathon</option>
          <option value="marinette">Marinette</option>
          <option value="marquette">Marquette</option>
          <option value="menominee">Menominee</option>
          <option value="milwaukee">Milwaukee</option>
          <option value="monroe">Monroe</option>
          <option value="oconto">Oconto</option>
          <option value="oneida">Oneida</option>
          <option value="outagamie">Outagamie</option>
          <option value="ozaukee">Ozaukee</option>
          <option value="pepin">Pepin</option>
          <option value="pierce">Pierce</option>
          <option value="polk">Polk</option>
          <option value="portage">Portage</option>
          <option value="price">Price</option>
          <option value="racine">Racine</option>
          <option value="richland">Richland</option>
          <option value="rock">Rock</option>
          <option value="rusk">Rusk</option>
          <option value="sauk">Sauk</option>
          <option value="sawyer">Sawyer</option>
          <option value="shawano">Shawano</option>
          <option value="sheboygan">Sheboygan</option>
          <option value="stcroix">St Croix</option>
          <option value="taylor">Taylor</option>
          <option value="trempealeau">Trempealeau</option>
          <option value="vernon">Vernon</option>
          <option value="vilas">Vilas</option>
          <option value="walworth">Walworth</option>
          <option value="washburn">Washburn</option>
          <option value="washington">Washington</option>
          <option value="waukesha">Waukesha</option>
          <option value="waupaca">Waupaca</option>
          <option value="waushara">Waushara</option>
          <option value="winnebago">Winnebago</option>
          <option value="wood">Wood</option>
        </select>
        <!-- div style="margin-top: 15px;">In-House:</div>
        <select name="target_db">
          <option value="">Select...</option>
          <option value="qtest">QTest Chippewa</option>
          <option value="qtest1">QTest Dane</option>
          <option value="qtest2">QTest Dodge</option>
        </select -->
        <div style="margin-top: 15px;">
          <input type="submit" value="Submit" name="submit">
        </div>
      </form>
    </p>
    <?php
    }
    else {
      $target_db = $_POST["target_db"];
      $href = 'http://' . $target_db . '-db:50104/filelist/client';
      //display the output:
    ?>
    <p class="county-profile">
      Profile for: <a href="<?php echo $href ?>" target="_blank"><?php echo $target_db ?></a>
    </p>

    <!-- //?php -->
<!--      echo "<p>"; -->
<!--      echo 'Profile for: <a href="' . $href . '" target="_blank">' . $target_db . '</a>'; -->
<!--      echo "</p>";-->
    <!-- //? -->
      <p><button onclick="goBack()">Go Back</button></p>
      <!-- p>PROFILE 4: <a href="<?php echo $href ?>" target="_blank"><?php echo $target_db ?></a -->
    <?php
    }
    ?>
      
    <ul class="in-house">
      <li><a href="http://qtest-db:50104/filelist/client"  target="_blank">QTest &mdash; Chippewa</a></li>
      <li><a href="http://qtest1-db:50104/filelist/client" target="_blank">QTest &mdash; Dane</a></li>
      <li><a href="http://qtest2-db:50104/filelist/client" target="_blank">QTest &mdash; Dodge</a></li>
      <li><a href="http://dev1-db:52104/filelist/client"   target="_blank">dev1 &mdash; Columbia</a></li>
      <li><a href="http://dev1-db:52204/filelist/client"   target="_blank">dev1 &mdash; Milwaukee</a></li>
      <li><a href="http://dev2-db:52104/filelist/client"   target="_blank">dev2 &mdash; Crawford</a></li>
      <li><a href="http://dev2-db:52204/filelist/client"   target="_blank">dev2 &mdash; Iowa</a></li>
      <li><a href="http://dev3-db:52104/filelist/client"   target="_blank">dev3 &mdash; La Crosse</a></li>
      <li><a href="http://dev3-db:52204/filelist/client"   target="_blank">dev3 &mdash; Monroe</a></li>
      <li><a href="http://dev4-db:52104/filelist/client"   target="_blank">dev4 &mdash; Dunn</a></li>
      <li><a href="http://dev4-db:52204/filelist/client"   target="_blank">dev4 &mdash; Winnebago</a></li>
      <li><a href="http://dev5-db:52104/filelist/client"   target="_blank">dev5 &mdash; Manitowoc</a></li>
      <li><a href="http://dev5-db:52204/filelist/client"   target="_blank">dev5 &mdash; Green Lake</a></li>
      <li><a href="http://dev6-db:52104/filelist/client"   target="_blank">dev6 &mdash; Jefferson</a></li>
      <li><a href="http://dev6-db:52204/filelist/client"   target="_blank">dev6 &mdash; Ozaukee</a></li>
      <li><a href="http://dev7-db:52104/filelist/client"   target="_blank">dev7 &mdash; Ashland</a></li>
      <li><a href="http://dev7-db:52204/filelist/client"   target="_blank">dev7 &mdash; Pierce</a></li>
      <li><a href="http://dev8-db:52104/filelist/client"   target="_blank">dev8 &mdash; Barron</a></li>
      <li><a href="http://dev8-db:52204/filelist/client"   target="_blank">dev8 &mdash; Juneau</a></li>
      <li><a href="http://dev9-db:52104/filelist/client"   target="_blank">dev9 &mdash; Rock</a></li>
      <li><a href="http://dev9-db:52204/filelist/client"   target="_blank">dev9 &mdash; Waukesha</a></li>
      <li><a href="http://dev13-db:52104/filelist/client"  target="_blank">dev13 &mdash; Pepin</a></li>
      <li><a href="http://dev13-db:52204/filelist/client"  target="_blank">dev13 &mdash; Sauk</a></li>
      <li><a href="http://dev14-db:52104/filelist/client"  target="_blank">dev14 &mdash; Eau Claire</a></li>
      <li><a href="http://dev14-db:52204/filelist/client"  target="_blank">dev14 &mdash; Walworth</a></li>
      <li><a href="http://dev15-db:52104/filelist/client"  target="_blank">dev15 &mdash; Portage</a></li>
      <li><a href="http://dev15-db:52204/filelist/client"  target="_blank">dev15 &mdash; Richland</a></li>
    </ul>
    <ul class="in-house">
      <li><a href="http://step-db:50204/filelist/scam_19.2"  target="_blank">scam_19.2 &mdash; PROD</a></li>
      <li><a href="http://dev11-db:51904/filelist/scam_19.2" target="_blank">scam_19.2 &mdash; DEV</a></li>
      <!-- Tue 21 May 2019 03:22:44 PM CDT - add 19.3 SCAM profiles -->
      <li><a href="http://step-db:50204/filelist/scam_19.3"  target="_blank">scam_19.3 &mdash; PROD</a></li>
      <li><a href="http://dev11-db:51904/filelist/scam_19.3" target="_blank">scam_19.3 &mdash; DEV</a></li>
    </ul>
  </body>
  <script>
    function goBack() {
      window.history.back();
    }
  </script>
</html>
