package gov.wicourts.cc.reports.snippet

import net.liftweb.util.CssSel
import net.liftweb.util.Helpers._
import org.joda.time.LocalDate
import org.joda.time.LocalDateTime
import scala.xml.NodeSeq
import scalaz.syntax.std.option.ToOptionIdOps

import gov.wicourts.cc.model.CompleteParty
import gov.wicourts.cc.model.County
import gov.wicourts.webcommon.snippet._
import gov.wicourts.cc.reports.snippet.RmcReport.FormStatutes
import gov.wicourts.common.syntax.dates._

case class Gf121Args(
  county: County,
  caption: String,
  caseNo: String,
  dateOfJudgment: LocalDate,
  debtor: CompleteParty,
  creditor: CompleteParty,
  jdgmtAmount: Double,
  creditorAtty: String,
  dateDkted: LocalDate,
  costs: Double,
  otherJdgmtDebtors: CompleteParty,
  timeDkted: LocalDateTime,
  totAmt: Double,
  satisfiedDate: LocalDate,
  satisfiedBy: Option[String],
  propertyDescr: String,
  isFullCheckbox: Option[Boolean],
  isPartCheckbox: Option[Boolean],
  seeAttachments: Boolean,
  currDateTime: LocalDateTime
)

object Gf121 extends SimpleReportGenerator[Gf121Args]{

  override val reportId: String = "gf121"
  override val reportDesc: String = "Certificate of Satisfaction of Judgment"
  override val cssFiles: List[String] = {
    StandardReportHeader.cssFiles :::
      RmcReportFooter.cssFiles :::
      super.cssFiles
  }

  override def render[RType <: ReportType](
    a: Gf121Args,
    reportType: RType
  ): Option[RType#RetType] = {
    val footer = RmcReportFooter.render(
      report = this,
      meeting = RmcReport.RmcMeeting._200006,
      formStatutes = FormStatutes("806.22").some
    )
    val generatable = ReportGeneratableImpl(
      reportId = reportId,
      cssFiles = cssFiles,
      header = NodeSeq.Empty,
      subHeader = NodeSeq.Empty,
      content = cssSel(a).apply(template(reportType)),
      footer = footer
    )
    ReportGenerator.generate(generatable, reportType)
  }

  private def cssSel(args: Gf121Args): CssSel = {
    StandardReportHeader.render(
      reportDesc = reportDesc,
      caption = args.caption.some,
      caseNo = args.caseNo.some,
      None,  // for: externalCaseNo
      countyTitle = s"${args.county.countyName} County",
      requiresSigningHeader = true
    ) &
    ".debtor *" #> partyCss(args.debtor) &
    ".creditor *" #> partyCss(args.creditor) &
    ".dateOfJudgment *" #> args.dateOfJudgment.inSimpleDateFormat  &
    ".jdgmtAmount *" #> args.jdgmtAmount &
    ".creditorAtty *" #> args.creditorAtty &
    ".dateDkted *" #> args.dateDkted.inSimpleDateFormat &
    ".costs *" #> args.costs &
    ".otherJdgmtDebtors *" #> partyCss(args.otherJdgmtDebtors) &
    ".timeDkted *" #> args.timeDkted.inSimpleTimeFormat &
    ".totAmt *" #> args.totAmt &
    ".satisfiedDate *" #> args.satisfiedDate.inSimpleDateFormat &
    ".satisfiedBy *" #> args.satisfiedBy &
    ".propertyDescr *" #> args.propertyDescr &
    setChecked(".isFull", args.isFullCheckbox.getOrElse(false)) &
    setChecked(".isPart", args.isPartCheckbox.getOrElse(false)) &
    setChecked(".seeAttachments", args.seeAttachments) &
    ".currDateTime *" #> args.currDateTime.inRfc822Format
  }

  private def partyCss(party: CompleteParty): CssSel = {
    ".fullName *" #> party.party.fullNameFirstNameFirst &
    ".primAddr *" #> party.partyAddr.flatMap(_.primAddr) &
    ".secAddr *" #> party.partyAddr.flatMap(_.secAddr) &
    ".city *" #> party.partyAddr.flatMap(_.city) &
    ".state *" #> party.partyAddr.flatMap(_.state) &
    ".zip *" #> party.partyAddr.flatMap(_.zip)
  }

  private def setChecked(selector: String, checked: Boolean): CssSel = {
    (selector + " [class+]") #> (if (checked) "checkbox-x" else "checkbox")
  }

}
