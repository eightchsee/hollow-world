List(
 CompleteJdgmtParty(
  JdgmtParty(
   70,                         // countyNo
   2016CV000608,               // caseNo
   -1,                         // civilJdgmtSeqNo
   2,                          // jdgmtPartyNo
   false,                      // isReleased
   A,                          // jdgmtPartyStatus
   DB,                         // jdgmtPartyType
   Anderson,                   // nameL
   None,                       // attyAddrNo
   None,                       // attyNo
   Some(Stevens Point),        // city
   None,                       // country
   None,                       // dob
   None,                       // fromJdgmtPartyNo
   Some(Amanda),               // nameF
   Some(M),                    // nameM
   Some(1),                    // partyNo
   Some(715-496-0715),         // phone
   Some(2023 Illinois Avenue), // primAddr
   Some(),                     // secAddr
   None,                       // ssn
   Some(WI),                   // state
   Some(),                     // suffix
   Some(54481),                // zip
   ,                           // searchName
   None,                       // searchNameF
   ,                           // searchNameL
   Amanda M Anderson ,         // fullNameFirstNameFirst
   Anderson, Amanda M ,        // fullNameLastNameFirst
   ,                           // soundexNameF
                               // soundexNameL
  ),
  None,
  Hidden(
   JdgmtParty(70,2016CV000608,-1,2,false,A,DB,Anderson,None,None,Some(Stevens Point),None,None,None,Some(Amanda),Some(M),Some(1),Some(715-496-0715),Some(2023 Illinois Avenue),Some(),None,Some(WI),Some(),Some(54481),,None,,Amanda M Anderson ,Anderson, Amanda M ,,)
  ),
  Some(
   CentralAtty(
    -1,              // attySeqNo
    1083461,         // attyNo
    Drengler,        // nameL
    true,            // isActiveLic
    None,            // admissionDate
    None,            // oldAttyNo
    None,            // ctofcNo
    false,           // isDeceased
    false,           // proHacVice
    None,            // barEffStatus
    None,            // barSchoolCode
    None,            // barServiceClass
    None,            // attyTitleCode
    None,            // dob
    None,            // docAccessCode
    None,            // eAccountStatus
    None,            // eFileRegCaseNo
    None,            // homeCounty
    None,            // stateBarNo
    None,            // emailAddr
    None,            // gradYear
    None,            // sccaAttyNo
    None,            // sex
    Some(Ryan),      // nameF
    Some(W),         // nameM
    None,            // prefix
    None,            // suffix
    ,                // searchName
    Ryan W Drengler, // fullNameFirstNameFirst
                     // fullNameLastNameFirst
   )
  ),
  None,
  Some(
   CentralAttyAddr(
    -1,                      // attySeqNo
    -1,                      // attyAddrSeqNo
    None,                    // attyFirmId
    None,                    // firm
    None,                    // jobTitle
    None,                    // comments
    None,                    // attyFirmName
    None,                    // emailAddr
    None,                    // cellPhone
    Some(715-345-7305),      // phone
    None,                    // ext
    Some(1025 Clark Street), // primAddr
    Some(Room 302),          // secAddr
    Some(Stevens Point),     // city
    Some(WI),                // state
    Some(54481),             // zip
    None,                    // country
    None,                    // faxNo
    None,                    // otherPhone
    None,                    // otherPhoneExt
    None,                    // nickname
    false,                   // defaultAllAddresses
    None                     // information
   )
  ),
  None
 ), 
 CompleteJdgmtParty(
  JdgmtParty(
   70,                         // countyNo
   2016CV000608,               // caseNo
   -1,                         // civilJdgmtSeqNo
   3,                          // jdgmtPartyNo
   false,                      // isReleased
   A,                          // jdgmtPartyStatus
   DB,                         // jdgmtPartyType
   Moen,                       // nameL
   None,                       // attyAddrNo
   None,                       // attyNo
   Some(Fort Atkinson),        // city
   None,                       // country
   None,                       // dob
   None,                       // fromJdgmtPartyNo
   Some(Ariel),                // nameF
   Some(Lynn),                 // nameM
   Some(1),                    // partyNo
   None,                       // phone
   Some(320 Blackhawk Dr #07), // primAddr
   Some(),                     // secAddr
   None,                       // ssn
   Some(WI),                   // state
   Some(),                     // suffix
   Some(53538),                // zip
   ,                           // searchName
   None,                       // searchNameF
   ,                           // searchNameL
   Ariel Lynn Moen ,           // fullNameFirstNameFirst
   Moen, Ariel Lynn ,          // fullNameLastNameFirst
   ,                           // soundexNameF
                               // soundexNameL
  ),
  None,
  Hidden(
   JdgmtParty(70,2016CV000608,-1,3,false,A,DB,Moen,None,None,Some(Fort Atkinson),None,None,None,Some(Ariel),Some(Lynn),Some(1),None,Some(320 Blackhawk Dr #07),Some(),None,Some(WI),Some(),Some(53538),,None,,Ariel Lynn Moen ,Moen, Ariel Lynn ,,)
  ),
  None,
  None,
  None,
  None
 )
)

