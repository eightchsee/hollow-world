11:58 AM 8/20/2019 - Untitled Document 3 [workspace 3]
  private def buildGf121[RType <: ReportType](
    params: Map[String, List[String]],
    reportType: RType
  ): Option[RType#RetType] = {
    val satisfiedBy = params.get("satisfiedBy").flatMap(_.headOption)
    val seeAttachments = params.get("seeAttachments").flatMap(_.headOption).exists(asBoolean(_).openOr(false))
    Gf121.render(
      Gf121Args(
        county = ccSamples.countySample2,
        caption = ccSamples.captionSample,
        caseNo = ccSamples.caseSample.caseNo,
        dateOfJudgment = LocalDate.parse("2017-09-04"),
        debtor = ccSamples.completePartySample,
        creditor = ccSamples.completePartySample,
        jdgmtAmount = 45530.40,
        creditorAtty = "Kevin Eric Skogg",
        dateDkted = LocalDate.now(),
        costs = 651.50,
        otherJdgmtDebtors = ccSamples.completePartySample,
        timeDkted = LocalDateTime.now(),
        totAmt = 45553.40 + 651.50,
        satisfiedDate = LocalDate.parse("2018-02-15"),
        satisfiedBy = satisfiedBy,
        propertyDescr = "06/27/2017 Judgment amended to include $96.00 for Contempt Service.",
        isFullCheckbox = Option(true),
        isPartCheckbox = Option(false),
        seeAttachments = seeAttachments,
        currDateTime = LocalDateTime.now()
      ),
      reportType
    )
  }

...

  def lookup[RType <: ReportType](formNo: String, ctofcType: String, params: Map[String, List[String]], reportType: RType): Option[RType#RetType] = {
    formNo match {
      case CitnDotReport.reportId =>
        buildCitnDot(reportType, params)
...
      case Gf121.reportId =>
        buildGf121(params, reportType)
...

