12:01 PM 8/20/2019 - Untitled Document 15 [workspace 3]
// Mon 12 Aug 2019 11:04:10 AM CDT 

// https://docs.scala-lang.org/tour/case-classes.html
// You can create a (shallow) copy of an instance of a case class simply by using the
// copy method. You can optionally change the constructor arguments.

case class     Message      (sender: String,              recipient: String,                body: String                 )
val message4 = Message      ("julien@bretagne.fr",        "travis@washington.us",           "Me zo o komz gant ma amezeg")
val message5 = message4.copy(sender = message4.recipient, recipient = "claire@bourgogne.fr"                              )
message5.sender  // travis@washington.us
message5.recipient // claire@bourgogne.fr
message5.body  // "Me zo o komz gant ma amezeg"


