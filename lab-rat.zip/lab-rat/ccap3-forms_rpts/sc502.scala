package gov.wicourts.cc.reports.snippet

import net.liftweb.util.CssSel
import net.liftweb.util.Helpers._
import org.joda.time.LocalDate
import org.joda.time.LocalDateTime
import scala.xml.NodeSeq
import scalaz.syntax.std.option.ToOptionIdOps

import gov.wicourts.cc.model.CivilJdgmt
import gov.wicourts.cc.model.CvJdgmtMoney

// import gov.wicourts.cc.model.CentralAtty
// import gov.wicourts.cc.model.CentralAttyAddr
import gov.wicourts.cc.model.CompleteCivilJdgmt
import gov.wicourts.cc.model.CompleteJdgmtParty
import gov.wicourts.cc.model.County
import gov.wicourts.cc.model.CvJdgmtPartyType
import gov.wicourts.cc.reports.snippet.RmcReport.FormStatutes
import gov.wicourts.common.syntax.bigDecimal.ToBigDecimalOpsFromBigDecimal
import gov.wicourts.webcommon.snippet._
import gov.wicourts.webcommon.snippet.ReportType
import gov.wicourts.webcommon.snippet.SimpleReportGenerator
import gov.wicourts.common.syntax.dates._
import gov.wicourts.webcommon.web.StaticReport

case class Sc502Args(
  county: County,
  caption: Option[String],
  caseNo: String,
  amended: Boolean,
  completeCivilJdgmt: CompleteCivilJdgmt,
  noticeMailedDate: LocalDate,
  currDateTime: LocalDateTime
)

object Sc502 extends SimpleReportGenerator[Sc502Args]{

  override val reportId: String = "sc502"
  override val reportDesc: String = "Judgment/Notice of Entry of Judgment"
  override val cssFiles: List[String] = {
    StandardReportHeader.cssFiles :::
      RmcReportFooter.cssFiles :::
      super.cssFiles
  }

  override def render[RType <: ReportType](
    a: Sc502Args,
    reportType: RType
  ): Option[RType#RetType] = {
    val footer = RmcReportFooter.render(
      report = this,
      meeting = RmcReport.RmcMeeting._201711,
      formStatutes = FormStatutes("Chapter 799.24").some
    )
    val generatable = ReportGeneratableImpl(
      reportId = reportId,
      cssFiles = cssFiles,
      header = NodeSeq.Empty,
      subHeader = NodeSeq.Empty,
      content = cssSel(a).apply(template(reportType)),
      footer = footer
    )
    ReportGenerator.generate(generatable, reportType)
  }

  private def headerCssSel(args: Sc502Args): CssSel = {
    StandardReportHeader.render(
      reportDesc = reportDesc,
      caption = args.caption,
      caseNo = args.caseNo.some,
      externalCaseNo = None,
      countyTitle = StaticReport.countyTitle(args.county),
      requiresSigningHeader = true,
      amended = args.amended.some
    )
  }
  private def cssSel(args: Sc502Args): CssSel = {
    val creditors = args.completeCivilJdgmt.parties
      .filter(c => c.jdgmtParty.jdgmtPartyType.equals(CvJdgmtPartyType.creditor))
    val debtors = args.completeCivilJdgmt.parties
      .filter(d => d.jdgmtParty.jdgmtPartyType.equals(CvJdgmtPartyType.debtor))
    val creditor = creditors.headOption
    println("creditors: " + creditors)
    val debtor = debtors.headOption
    println("debtor: " + debtor)
    val otherDebtors = debtors.tail
    println("otherDebtors: " + otherDebtors)
    headerCssSel(args) &
      ".jdgmtLienType *" #> args.completeCivilJdgmt.civilJdgmt.jdgmtLienType &
      ".jdgmtDate *" #> args.completeCivilJdgmt.civilJdgmt.jdgmtDate.inWordDateFormat &
      ".cr .creditor *" #> creditor.map(prtyCss) &
      ".cr .creditorAtty *" #> creditor.map(attyCss) &
      ".db .debtor *" #> debtor.map(prtyCss) &
      ".db .debtorAtty *" #> debtor.map(attyCss) &
      // ".db *" #> otherDebtors.flatMap(partyCss) &
      ".other-db .debtor *" #> otherDebtors.map(prtyCss) &
      ".other-db .debtorAtty *" #> otherDebtors.map(attyCss) &
      ".amounts-comments *" #> cvJdgmtCss(args.completeCivilJdgmt.civilJdgmt, args.completeCivilJdgmt.monies, args.noticeMailedDate) &
      ".currDateTime *" #> args.currDateTime.inRfc822Format
  }

  // private def partyCss(party: CompleteJdgmtParty): List[CssSel] = {
  //   println("party: " + party.jdgmtParty.nameToJson + " atty; " + party.centralAtty.map(ca => ca.nameToJson))
  //   List(
  //     Some(
  //       ".debtor .fullName *" #> party.jdgmtParty.fullNameFirstNameFirst &
  //         ".debtor .primAddr *" #> party.jdgmtParty.primAddr &
  //         ".debtor .secAddr *" #> party.jdgmtParty.secAddr &
  //         ".debtor .city *" #> party.jdgmtParty.city &
  //         ".debtor .state *" #> party.jdgmtParty.state &
  //         ".debtor .zip *" #> party.jdgmtParty.zip
  //     ),
  //     party.centralAtty.map(ca =>
  //       ".debtorAtty .fullName *" #> ca.fullNameFirstNameFirst &
  //         ".debtorAtty .primAddr *" #> party.centralAttyAddr.flatMap(_.primAddr) &
  //         ".debtorAtty .secAddr *" #> party.centralAttyAddr.flatMap(_.secAddr) &
  //         ".debtorAtty .city *" #> party.centralAttyAddr.flatMap(_.city) &
  //         ".debtorAtty .state *" #> party.centralAttyAddr.flatMap(_.state) &
  //         ".debtorAtty .zip *" #> party.centralAttyAddr.flatMap(_.zip)
  //     )
  //   ).flatten
  // }

  private def attyCss(party: CompleteJdgmtParty): CssSel = {
    println("atty: " + party.centralAtty.map(a => a.nameToJson))
    ".fullName *" #> party.centralAtty.map(p => p.fullNameFirstNameFirst) &
      ".primAddr *" #> party.centralAttyAddr.flatMap(_.primAddr) &
      ".secAddr *" #> party.centralAttyAddr.flatMap(_.secAddr) &
      ".city *" #> party.centralAttyAddr.flatMap(_.city) &
      ".state *" #> party.centralAttyAddr.flatMap(_.state) &
      ".zip *" #> party.centralAttyAddr.flatMap(_.zip)
  }

  private def prtyCss(party: CompleteJdgmtParty): CssSel = {
    ".fullName *" #> party.jdgmtParty.fullNameFirstNameFirst &
      ".primAddr *" #> party.jdgmtParty.primAddr &
      ".secAddr *" #> party.jdgmtParty.secAddr &
      ".city *" #> party.jdgmtParty.city &
      ".state *" #> party.jdgmtParty.state &
      ".zip *" #> party.jdgmtParty.zip
  }

  private def cvJdgmtCss(civilJdgmt: CivilJdgmt, monies: List[CvJdgmtMoney], currDate: LocalDate): CssSel = {
    val bigText = "Now is the time for all good people to come to the aid of their county\n"
    val biggerText = bigText + "I've seen all good people turn their heads each day so satisfied I'm on my way"
    val amountCodes = Set("JA","TAX","BOC")
    val interestNEJCodes = Set("PJI","IOV","INT")
    val attyFeeCodes = Set("AF")
    val filingFeeCodes = Set("CFF","SCFF")
    val serviceCodes = Set("SE")
    val docketingFeeCodes = Set("DF")
    val witnessFeeCodes = Set("WF")
    val preJdgmtIntCodes = Set("PRJI")
//    val notCosts = amountCodes.union(interestNEJCodes)
    val cvMoneyCodes = Set("JA","TAX","BOC","PRJI","PJI","IOV","INT","WF","AF","SE","DF","CFF","SCFF")
    val allDemCodes = amountCodes
      .union(interestNEJCodes)
      .union(attyFeeCodes)
      .union(filingFeeCodes)
      .union(serviceCodes)
      .union(docketingFeeCodes)
      .union(witnessFeeCodes)
      .union(preJdgmtIntCodes)
    println("allDemCodes: " + allDemCodes.toSeq.sorted)
    val amount = monies.filter(m => amountCodes.contains(m.civilMoneyCode)).map(_.amt).sum
    val amtString = "$ " + s"$amount"
    val interest = monies.filter(m => interestNEJCodes.contains(m.civilMoneyCode)).map(_.amt).sum
    val attorneyFee = monies.filter(m => attyFeeCodes.contains(m.civilMoneyCode)).map(_.amt).sum
    val filingFee = monies.filter(m => filingFeeCodes.contains(m.civilMoneyCode)).map(_.amt).sum
    val service = monies.filter(m => serviceCodes.contains(m.civilMoneyCode)).map(_.amt).sum
    val docketingFee = monies.filter(m => docketingFeeCodes.contains(m.civilMoneyCode)).map(_.amt).sum
    val witnessFee = monies.filter(m => witnessFeeCodes.contains(m.civilMoneyCode)).map(_.amt).sum
    val preJdgmtIntNEJ = monies.filter(m => preJdgmtIntCodes.contains(m.civilMoneyCode)).map(_.amt).sum
    val other = monies.filterNot(m => cvMoneyCodes.contains(m.civilMoneyCode)).map(_.amt).sum
    val totAmt = "$ " + s"${(amount + interest + attorneyFee + filingFee +
                             service + docketingFee + witnessFee + preJdgmtIntNEJ + other)
      .noDollarSignNoCommaFormat}"
    ".jdgmtAmount *" #> amtString &
      ".interestNEJ *" #> interest.noDollarSignNoCommaFormat &
      ".attorneyFee *" #> attorneyFee.noDollarSignNoCommaFormat &
      ".filingFee *" #> filingFee.noDollarSignNoCommaFormat &
      ".service *" #> service.noDollarSignNoCommaFormat &
      ".docketingFee *" #> docketingFee.noDollarSignNoCommaFormat &
      ".witnessFee *" #> witnessFee.noDollarSignNoCommaFormat &
      ".preJdgmtIntNEJ *" #> preJdgmtIntNEJ.noDollarSignNoCommaFormat &
      ".other *" #> other.noDollarSignNoCommaFormat &
      ".totAmt *" #> totAmt &
      ".propertyDescr *" #> civilJdgmt.propertyDescr.map(_.concat(" " + biggerText)) &
      ".dateDkted *" #> civilJdgmt.dateDkted.map(_.inSimpleDateFormat) &
      ".noticeMailedDate *" #> currDate.inSimpleDateFormat &
      ".timeDkted *" #> civilJdgmt.timeDkted.map(_.inSimpleTimeFormat)
  }
}