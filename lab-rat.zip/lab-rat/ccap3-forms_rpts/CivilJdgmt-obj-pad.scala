
args.completeCivilJdgmt.parties
  .filter(f => f.jdgmtParty.jdgmtPartyType.equals(CvJdgmtPartyType.debtor))
    .map(partyCss) &


[error] /home/theiber/workspace/ccap3/cc-reports/src/main/scala/gov/wicourts/cc/reports/snippet/gf121.scala:107:81:
 AnyRef{type Tag = gov.wicourts.cc.model.CivilJdgmt.Satisfaction.CodeT; type Self = String} and gov.wicourts.cc.model.CivilJdgmt.Satisfaction.Full.type
  are unrelated: they will most likely never compare equal
[error]       setChecked(".isFull", args.completeCivilJdgmt.civilJdgmt.satisfactionCode == CivilJdgmt.Satisfaction.Full) &



civilJdgmt:
 CivilJdgmt(
  70,                         // countyNo
  2016CV000608,               // caseNo
  -1,                         // civilJdgmtSeqNo
  false,                      // hasMultipleDbtrs
  true,                       // isElectronicFile
  true,                       // isVerifiedTax
  2018-07-10,                 // jdgmtDate
  JU,                         // jdgmtLienType
  0,                          // lastCvJEventSeqNo
  0,                          // lastCvJMoneySeqNo
  0,                          // lastJdgmtPartyNo
  F,                          // satisfactionCode
  4612.14,                    // totAmt
  2018-04-10,                 // interestEffDate
  Some(2018-07-06),           // dateDkted
  None,                       // dbtrNameF
  None,                       // dbtrNameL
  None,                       // dbtrNameM
  None,                       // dbtrSuffix
  None,                       // dorAcctNo
  None,                       // dorCountyNo
  None,                       // dorWarrantNo
  Some(2019-07-24),           // fullSatisDate
  None,                       // interestCalcTo
  None,                       // pdOfYear
  Some(04/23/2018 - Ashley N. Barton was released from Judgment based on Stipulation and Order /s/ TTF 04/20/2018

07/03/2018 - Judgment amended to add Ashley Barton as Debtor based on Affidavit of Noncompliance and Order for Money Judgment /s/ RJS 07/03/2018.), // propertyDescr
  Some(2018-01-17),           // svcDateFrom
  Some(2018-01-31),           // svcDateTo
  Some(13:48:00.000),         // timeDkted
  Some(Delinquent WC Assess), // typeOfTax
  ,                           // wccaRestKey
  None,                       // dbtrFullNameFirstNameFirst
  None                        // dbtrFullNameLastNameFirst
 )


// CcSamples

  def civilJdgmt(countyNo: Int, caseNo: String): CivilJdgmt = 
    CivilJdtmt.createDefault.copy(
    ...
      satisfactionCode = SatisfactionCode(CivilJdgmt.Satisfaction.Code("F"), "Full", true).satisfaction,
    )

...

// gf121
  private def cssSel(args: Gf121Args): CssSel = {
    ...
    
      setChecked(".isFull", args.completeCivilJdgmt.civilJdgmt.satisfactionCode == CivilJdgmt.Satisfaction.Full) &
      ...



[error] /home/theiber/workspace/ccap3/cc-reports/src/main/scala/gov/wicourts/cc/reports/snippet/gf121.scala:107:81: AnyRef{type Tag = gov.wicourts.cc.model.CivilJdgmt.Satisfaction.CodeT; type Self = String} and gov.wicourts.cc.model.CivilJdgmt.Satisfaction.Full.type are unrelated: they will most likely never compare equal
[error]       setChecked(".isFull", args.completeCivilJdgmt.civilJdgmt.satisfactionCode == CivilJdgmt.Satisfaction.Full) &

