-- Wed 26 Feb 2020 03:17:30 PM CST 
-- Judgment party entry query.  Used to add judgment parties to a civil judgment.
SELECT cr."countyNo" AS county_no FROM "ControlRecord" AS cr;
\gset
SELECT jp."jdgmtPartyType",
       jp."fullNameFirstNameFirst" AS "fullName",
       jp."jdgmtPartyStatus",
       jp."caseNo",
       jp."civilJdgmtSeqNo",
       jp."jdgmtPartyNo",
       jp."countyNo",
       jp."isReleased"::VARCHAR(5),
       ( COALESCE(jp."primAddr" || ' ', '') || COALESCE(jp."secAddr" || ' ', '') || jp.city || COALESCE(' ' || jp.state, '') || COALESCE(' ' || jp.zip, '') || COALESCE(' ' || jp.country, '') ) AS "_fullAddr",
       jp.ssn,
       to_char(jp.dob, 'MM-DD-YYYY') AS _dob,
       jp.phone,
       jp."attyNo",
       jp."attyAddrNo",
       jp."partyNo",
       jp."fromJdgmtPartyNo",
       COALESCE(c."isElectronicFiling", false) AS "isElectronicFiling",
       p."isAddrSealed",
       CASE WHEN (p."isENotice" = true OR ap."isENotice" = false) THEN false ELSE false END AS "isENotice"
FROM   "JdgmtParty" AS jp
  LEFT OUTER JOIN "Case" AS c ON (
       c."caseNo"   = jp."caseNo"
   AND c."countyNo" = jp."countyNo"
  )
  LEFT OUTER JOIN "Party" AS p ON (
       p."caseNo"   = jp."caseNo"
   AND p."countyNo" = jp."countyNo"
   AND p."partyNo"  = jp."partyNo"
  )
  LEFT OUTER JOIN "AttyParty" AS ap ON (
       ap."countyNo" = jp."countyNo"
   AND ap."caseNo"   = jp."caseNo"
   AND ap."partyNo"  = jp."partyNo"
   AND ap."attyNo"   = jp."attyNo"
  )
WHERE  jp."countyNo" = :county_no
  AND  jp."caseNo"   IN ( :case_no )
ORDER BY "jdgmtPartyType";

 jdgmtPartyType |               fullName                | jdgmtPartyStatus |    caseNo    | civilJdgmtSeqNo | jdgmtPartyNo | countyNo | isReleased |                           _fullAddr                           |     ssn     |    _dob    |    phone     | attyNo  | attyAddrNo | partyNo | fromJdgmtPartyNo | isElectronicFiling | isAddrSealed | isENotice 
----------------+---------------------------------------+------------------+--------------+-----------------+--------------+----------+------------+---------------------------------------------------------------+-------------+------------+--------------+---------+------------+---------+------------------+--------------------+--------------+-----------
 CR             | Portage County Clerk of Circuit Court | A                | 2018CF000159 |               3 |            2 |       49 | false      | 1516 Church Street Register in Probate Stevens Point WI 54481 |             |            |              |         |            |         |                  | t                  |              | f
 CR             | Firkus Masonry, Inc.                  | A                | 2018CF000159 |               2 |            2 |       49 | false      | 554 Brilowski Rd N Stevens Point WI 54481 United States       |             |            |              |         |            |         |                  | t                  |              | f
 DB             | Amanda M Anderson                     | A                | 2018CF000159 |               3 |            1 |       49 | false      | 2023 Illinois Avenue Stevens Point WI 54481                   | 399-80-7113 | 03-21-1977 | 715-496-0715 |         |            |       1 |                  | t                  | f            | f
 DB             | Amanda M Anderson                     | A                | 2018CF000159 |               2 |            1 |       49 | false      | 2023 Illinois Avenue Stevens Point WI 54481                   | 399-80-7113 | 03-21-1977 | 715-496-0715 | 1083461 |          5 |       1 |                  | t                  | f            | f
(4 rows)


